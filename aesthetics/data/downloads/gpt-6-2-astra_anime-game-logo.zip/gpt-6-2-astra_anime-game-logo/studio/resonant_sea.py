from worlds import *
def tides():
    n=fbm(5,6,1.68,2.05);m=fbm(12,5,1.78,1.55)
    sky=mix(rgb('10303e'),rgb('8dc3b8'),clamp(V*1.77+.10+.20*U))
    sky=glaze(sky,'b5ded1',np.exp(-((U-.72)/.32)**2-((V-.24)/.27)**2)*.56)
    # A translucent moving curtain in a marine cloud deck.
    warp=np.sin(3.8*U+1.5*np.sin(U*8))*.047+.013*n
    edge=.275-.19*U+warp
    sheet=np.exp(-((V-edge)/.044)**2)
    sky=glaze(sky,'c2ffe3',sheet*(.19+.11*np.sin(U*63+V*5)+.05*m))
    sky=glaze(sky,'9fdbcc',np.exp(-((V-edge+.047)/.085)**2)*clamp(noise(53,2)*.15+.24))
    cloud=clamp((n+.35*m-.05)*.33)
    sky=glaze(sky,'345e66',cloud*(.60-.20*V))
    sky=glaze(sky,'d1e7d0',clamp((m*.57+n*.24-.28)*.42)*np.exp(-((V-.34)/.21)**2))
    sky=stars(sky,240,.46,'#b7dace',78)
    im=np.uint8(np.clip(sky,0,255));d=Draft(im);rnd=random.Random(302)
    horizon=.525*1000
    def crag(x,y,w,h,depth=0,hang=False):
        x0=x-w/2
        shade=['628a88','416c6e','2c575b','234b50'][depth]
        light=['89a9a0','679389','537c72','54796a'][depth]
        dark=['547c7e','3e6469','2a4d55','204047'][depth]
        outline=[(-.51,-.05),(-.44,-.27),(-.35,-.38),(-.32,-.62),(-.16,-.64),(-.12,-.87),(.06,-1),(.17,-.91),(.18,-.70),(.31,-.51),(.30,-.3),(.50,-.06)]
        if hang:outline=[(-.50,-.68),(-.43,-.93),(-.1,-1),(.26,-.95),(.5,-.78),(.37,-.52),(.22,-.50),(.10,-.18),(-.08,0),(-.27,-.39)]
        def lh(a,b):return (x+a*w,y+b*h)
        corners=np.array([lh(a,b) for a,b in outline]);pts=[]
        for start,end in zip(corners,np.roll(corners,-1,axis=0)):
            diff=end-start;length=np.linalg.norm(diff)
            normal=np.array([-diff[1],diff[0]])/max(1,length)
            count=max(1,int(length/5))
            for q in range(count):
                k=q/count
                pts.append(tuple(start+diff*k+normal*(rnd.uniform(-1.8,1.8)+1.5*math.sin(k*13))*math.sin(k*math.pi)))
        d.poly(pts,shade)
        # Clip faceted fractures to the rock's silhouette before building strata.
        mask=np.zeros((H,W),np.uint8);cv2.fillPoly(mask,[d.pts(pts)],255)
        tile=im.copy();pa=Draft(tile)
        for j in range(65):
            a=rnd.uniform(-.52,.48);b=rnd.uniform(-1.07,-.02);k=rnd.uniform(.03,.17);z=rnd.uniform(.12,.48)
            face=[lh(a,b),lh(a+k,b-.03),lh(a+k*.72,b+z*.74),lh(a-.04,b+z)]
            pa.poly(face,rnd.choice([light,shade,shade,dark,dark]))
        for j in range(340):
            a=rnd.uniform(-.53,.54);b=rnd.uniform(-1.03,0);k=rnd.uniform(.005,.037)
            pa.line([lh(a,b),lh(a+k,b-.007)],rnd.choice([light,shade,dark]),rnd.uniform(.32,1))
        im[mask>0]=tile[mask>0]
        if depth>0:
            # Weathered vertical basalt grain, registered to the surface itself.
            ix,iy,bw,bh=cv2.boundingRect(d.pts(pts))
            ix0=max(0,ix);ix1=min(W,ix+bw);iy0=max(0,iy);iy1=min(H,iy+bh)
            if ix1>ix0 and iy1>iy0:
                xx=X[iy0:iy1,ix0:ix1];yy=Y[iy0:iy1,ix0:ix1]
                patina=mapnoise(xx+yy*.09,yy*.55,5.5)*3.7+mapnoise(xx,yy,1.6)*1.7+mapnoise(xx,yy,31)*4
                crop=im[iy0:iy1,ix0:ix1]
                filled=mask[iy0:iy1,ix0:ix1]>0
                corrected=np.uint8(np.clip(crop+patina[:,:,None],0,255))
                crop[filled]=corrected[filled]
        if hang:
            for i in range(4):
                a=rnd.uniform(-.3,.37);b=rnd.uniform(.02,.17)
                d.poly([lh(a,b),lh(a+.06,b-.04),lh(a+.02,b+.095)],dark)
    for x,w,h in [(-58,277,136),(129,130,89),(259,350,64),(362,145,102),(483,335,47),(742,320,37),(1003,177,85),(1184,194,124),(1435,532,149),(1601,320,243)]:
        crag(x,horizon+11,w,h,0)
    crag(84,535,312,168,1);crag(1240,540,236,142,1);crag(1446,542,254,225,2)
    crag(1385,564,103,154,2);crag(1540,565,126,215,3)
    # Suspended basalt clusters and their fine falls of inverted rain.
    for x,y,w,h in [(1188,309,111,107),(1280,254,42,62),(1153,208,26,32),(1048,358,31,44),(292,347,40,34),(340,318,16,22)]:
        crag(x,y,w,h,2 if w>90 else 1,True)
        for j in range(round(w*.16)):
            ax=x+rnd.uniform(-.24,.24)*w;top=y-rnd.uniform(.05,.28)*h
            d.line([(ax,top),(ax-1.4,top+rnd.uniform(12,40))],rnd.choice(['96bdb1','90b4ad','84a9a4']),.58)
    # A broken arc records the resonance above the drowned rock. Three thin rings share a plane.
    for j in range(3):
        center=(1203,231);rx=179-j*7;ry=38+j*4;rot=math.radians(-25)
        pts=[]
        for t in np.linspace(-2.0,1.63,146):
            x=rx*math.cos(t);y=ry*math.sin(t)
            pts.append((center[0]+x*math.cos(rot)-y*math.sin(rot),center[1]+x*math.sin(rot)+y*math.cos(rot)))
        d.line(pts,['a7d3c1','a2c7b8','83b6b1'][j],.64 if j else 1.2)
    # The sea is a projectively sampled height field with wind, cross-swells and dispersion.
    sky=im.astype('float32')
    focal=W*.71; horizon=H*.526; cam=9.3
    z0=np.geomspace(3,1290,850).astype('float32')[:,None]
    x0=(np.arange(W,dtype='float32')[None,:]-W*.5)*z0/focal
    def water(x,z):
        px=mapnoise(x+22,z,19);pz=mapnoise(x,z-43,26)
        wave= .72*np.sin(z*.34+x*.125+1.3*px)+.43*np.sin(z*.61-x*.16+.8*px)
        wave+=.24*np.sin(z*1.29+x*.25+1.7*pz)+.14*np.sin(z*2.7-x*.84+1.3*px)
        wave+=.11*mapnoise(x*1.2,z,1.4)+.06*mapnoise(x*.8,z,.5)
        return wave*(1+.17*px)
    e=water(x0,z0);py=horizon+(cam-e)*focal/z0
    envelope=np.minimum.accumulate(py,axis=0);idx=np.empty((H,W),np.int32);yy=np.arange(H-1,-1,-1,dtype='float32')
    for k in range(W):idx[:,k]=np.searchsorted(-envelope[:,k],-yy)[::-1]
    visible=idx<len(z0);idx=np.minimum(idx,len(z0)-1);prev=np.maximum(0,idx-1)
    cols=np.arange(W);y0=py[prev,cols];y1=py[idx,cols]
    f=clamp((y0-Y)/np.maximum(.001,y0-y1))
    z=z0[prev,0]*(1-f)+z0[idx,0]*f;x=(X-W*.5)*z/focal
    h=water(x,z);eps=.04+z*.00055
    dx=(water(x+eps,z)-h)/eps;dz=(water(x,z+eps)-h)/eps
    inv=1/np.sqrt(1+dx**2+dz**2)
    nx=-dx*inv;ny=inv;nz=-dz*inv
    flat=clamp((cam-h)/np.sqrt(x*x+z*z+(cam-h)**2))
    wind=mapnoise(x*1.5,z*2.9,.61)+.36*mapnoise(x,z*1.4,.23)
    reflect=clamp(.53-flat*.66+dz*1.49+dx*.42+wind*.145)
    sea=mix(rgb('093241'),rgb('3f817e'),clamp(.13+(h+1.2)*.22+.49*dx))
    sea=mix(sea,rgb('a4cbbb'),reflect**2*.83)
    light=(np.maximum(0,ny*.79+nx*.29+nz*.49))**27
    sea+=light[:,:,None]*rgb('4b7371')
    # Veined marine foam is trapped on the forward side of a crest.
    flow=mapnoise(x+.4*np.sin(z),z*.7,.72)+.35*mapnoise(x,z,.33)
    foam=clamp((h-.51)*1.5+dz*.75+flow*.72-.16)
    nets=np.exp(-np.abs(flow+.4*mapnoise(x,z,3.1))*9)
    sea=mix(sea,rgb('c8dfca'),foam*(.25+.67*nets))
    curl=clamp((h-.85)*1.8-dz*.16)*clamp((flow+.3)*1.6)
    sea=mix(sea,rgb('bdeada'),curl*.67)
    shadow=clamp((-h+.32)*.42-dz*.48)*clamp((V-.55)*2.9)
    sea=mix(sea,rgb('0d4352'),shadow*.49)
    sea=mix(sea,rgb('92b7ad'),1-np.exp(-z/319))
    im=np.where(visible[:,:,None],sea,sky)
    # Spray flakes and wind-blown birds stay at atmospheric scale.
    d=Draft(im)
    for x,y,s in [(309,195,5.6),(332,187,4),(348,206,2.8),(1048,341,3.4),(1007,354,2.5),(1104,347,2.7)]:
        d.poly([(x-2.2*s,y-s*.73),(x-s*.64,y-s*.47),(x,y),(x+s*1.2,y-s*.43),(x+s*2,y-s*.2),(x+s*.35,y+s*.2),(x,y+s*.7),(x-s*.77,y+s*.03)],'467276')
    finish(im,'tides',2.0)
if __name__=='__main__':tides()

