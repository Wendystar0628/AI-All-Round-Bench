from fontTools import subset
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from common import *
dest=ASSETS/'fonts'
dest.mkdir(exist_ok=True)
for filename,source,chars,weight in [
    ('atlas-serif','SourceHanSerifCN-SemiBold.otf','异世字形图鉴明日方舟：终末地崩坏星穹铁道鸣潮馆藏索引构造展映',None),
    ('atlas-grotesk','SpaceGrotesk[wght].ttf',''.join(chr(i) for i in range(32,127))+'·×—–↗',580),
    ('atlas-mono','SourceCodePro[wght].ttf',''.join(chr(i) for i in range(32,127))+'·×—–',450)
]:
    font=TTFont(FONTS/source)
    if weight is not None:font=instantiateVariableFont(font,{'wght':weight},inplace=True)
    cfg=subset.Options()
    sub=subset.Subsetter(options=cfg)
    sub.populate(text=chars);sub.subset(font)
    # Native OTF/TTF needs no platform-specific webfont codec.
    font.save(dest/(filename+('.otf' if source.endswith('.otf') else '.ttf')))

