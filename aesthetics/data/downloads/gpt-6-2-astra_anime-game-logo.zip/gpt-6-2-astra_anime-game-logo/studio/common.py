from __future__ import annotations
import io, json, math, os, random, sys, tempfile
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / '素材' / '字形底座'))
sys.path.insert(0, str(Path(tempfile.gettempdir()) / 'orbital-atlas-tools'))
from glyphbase import Font, Char, S, geom as G, Canvas, latin
import pathops
import resvg_py
FONTS = Path('C:/Windows/Fonts')
ASSETS = ROOT / 'assets'
PROOFS = ROOT / 'proofs'
for folder in [ASSETS, PROOFS]:
    folder.mkdir(exist_ok=True)
FACES = ['SourceHanSansCN-Heavy.otf', 'SourceHanSerifCN-Bold.otf', '汉仪尚巍手书简（非商）.ttf']
CHARS = ['终末地明日方舟', '星穹铁道崩坏', '鸣潮']
SLUGS = ['endfield','astral','tides']
NAMES = ['终末地','星穹铁道','鸣潮']
W,H = 1000,520
def normalized(font,ch):
    p=font.outline(ch)
    x0,y0,x1,y1=p.bounds
    sx,sy=100/(x1-x0),100/(y1-y0)
    return G.affine(p,sx,0,0,-sy,-x0*sx,y1*sy)
def svg_image(layers,defs='',w=W,h=H,scale=1):
    doc=f'<svg xmlns="http://www.w3.org/2000/svg" width="{round(w*scale)}" height="{round(h*scale)}" viewBox="0 0 {w} {h}"><defs>{defs}</defs>{layers}</svg>'
    return Image.open(io.BytesIO(resvg_py.svg_to_bytes(svg_string=doc))).convert('RGBA')
def tagpath(p,fill,attrs=''):
    d=G.to_svg_d(p) if not isinstance(p,str) else p
    return f'<path d="{d}" fill="{fill}" {attrs}/>'
def line(d,color,width=1,opacity=1,attrs=''):
    return f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}" opacity="{opacity}" {attrs}/>'
def fmt(x): return format(float(x),'.2f').rstrip('0').rstrip('.') or '0'
def dline(pts,close=False):
    return 'M'+' '.join(f'{fmt(x)},{fmt(y)}' for x,y in pts)+('Z' if close else '')
def circle(x,y,r,fill,more=''):
    return f'<circle cx="{fmt(x)}" cy="{fmt(y)}" r="{fmt(r)}" fill="{fill}" {more}/>'
def rect(x,y,w,h,fill,more=''):
    return f'<rect x="{fmt(x)}" y="{fmt(y)}" width="{fmt(w)}" height="{fmt(h)}" fill="{fill}" {more}/>'
def spark(x,y,r,color,wide=.66):
    pts=[]
    for i in range(8):
        a=i*math.pi/4
        rad=r*(.14 if i%2 else 1)
        pts.append((x+math.cos(a)*rad*wide,y+math.sin(a)*rad))
    return tagpath(dline(pts,True),color)
def font_grid():
    grid=Image.new('RGB',(1100,570),'#dce0e3')
    draw=ImageDraw.Draw(grid)
    for i,letters in enumerate(CHARS):
        f=Font(str(FONTS/FACES[i]))
        for k,ch in enumerate(letters):
            p=normalized(f,ch)
            im=svg_image(tagpath(p,'#18232c'),w=100,h=100,scale=1.35)
            x,y=k*154+10,i*187+26
            grid.paste(im,(x,y),im)
            for j in range(11):
                at=j*13.5
                draw.line((x+at,y,x+at,y+135),fill='#8e9c9e')
                draw.line((x,y+at,x+135,y+at),fill='#8e9c9e')
                if j%2==0:
                    draw.text((x+at-3,y-14),str(j*10),fill='#374755')
                    draw.text((x+1,y+at),str(j*10),fill='#9c6a65')
    grid.save(Path(tempfile.gettempdir())/'atlas-coords.png')
if __name__=='__main__':font_grid()

