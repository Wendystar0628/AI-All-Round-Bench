from atelier import *
FONT='BarlowCondensed-SemiBold.ttf'
def beam(ch,i,ty,part,pts,w,p):
    pts=pts.copy()
    # Segmented billets cut to constant thickness, except the tips of sloping struts.
    if ty=='横':
        start,end=pts[0],pts[-1]
        left,right=start[0]-1,end[0]+1
        y=start[1];a=w*.48
        return G.polygon([(left+a*.67,y-a),(right+1.8,y-a),(right+.4,y+a*.12),(right-a*.75,y+a),(left-1.8,y+a),(left-1.8,y-a*.18)])
    if ty=='点':
        a,b=pts[0],pts[-1]
        d=b-a;d/=np.linalg.norm(d);n=np.array([-d[1],d[0]])
        return G.polygon([a-n*w*.65,b-n*w*.48,b+d*w*.25+n*w*.08,b+n*w*.62,a+n*w*.37])
    return G.sweep(pts,w*[.96,1.05][ty=='竖'],join='bevel',cap0=G.cap_square(.5),cap1=G.cap_point(w*.23) if ty in ('提','撇','捺') else G.cap_square(.7))
def auger(ch,i,p):
    if ch!='末' or i!=2:return None
    drill=G.polygon([(42,-2),(56,-2),(57,3),(57,85),(60,85),(60,88),(56,101),(50,118),(43,103),(40,92),(40,85),(42,85)])
    for y in [85,92,99,106]:
        drill=G.diff(drill,G.polygon([(36,y+2),(62,y-7),(62,y-4.3),(36,y+4.9)]))
    return drill,(50,97),G.inter(drill,G.rect(32,76,65,122))
def milling(ch,i,ty,part,pts,w,shape):
    if ty!='横' or np.linalg.norm(pts[0]-pts[-1])<30:return None
    # A small corner relief open to the milled edge.
    x,y=pts[-1];a=w*.47
    return G.diff(shape,G.polygon([(x-a*1.8,y-a-.7),(x-a*.85,y-a-.7),(x-a*1.45,y-a*.06),(x-a*2.45,y-a*.06)]))
def derrick():
    s=''
    # Crown wheel, access ladder, travelling block and the platform at the two bearings.
    def seg(d,col,width):return line(d,col,width,attrs='stroke-linecap="square" stroke-linejoin="bevel"')
    s+=tagpath('M744 233L804 39H832L879 230 856 228 824 69 813 69 765 232Z','#254446')
    s+=seg('M751 228L806 40H830L870 228','#9cb3aa',4)
    s+=seg('M765 226L812 65M857 226L825 65','#638388',3)
    s+=tagpath('M797 39L804 30H836L841 41 839 51H795Z','#abc1b5')
    s+=tagpath('M805 27V15H826L831 21V30Z','#385356')
    s+=seg('M815 15V7M827 20L832 12','#b5c9b7',2.2)
    s+=rect(814,6,4,6,'#edcd71')
    for i in range(5):
        y=62+i*31
        a=802-i*9;b=833+i*6
        s+=seg(dline([(a-9,y+31),(b,y),(a,y),(b+6,y+31)]),'#728f8c',2.7)
        s+=seg(dline([(a,y),(b,y)]),'#bfd2c2',2.3)
    s+=seg('M815 48V132M821 48V132','#c2cbb2',1.8)
    s+=tagpath('M810 121H825V136L819 144 810 136Z','#d4b566')
    s+=seg('M818 140V178','#bac7b4',4)
    for y in range(79,224,8):
        x=828+(y-60)*.22
        s+=seg(f'M{x} {y}h5.5','#829b94',1.2)
    for x,y,w in [(791,85,53),(779,132,77),(761,189,112)]:
        s+=rect(x,y,w,4.1,'#7e958e')+seg(f'M{x} {y}v-8h{w}v8','#a4b6a8',1.4)
        for k in range(6):s+=rect(x+k*w/5,y-8,1.2,8,'#9bad9c')
    s+=seg('M747 230L715 238M869 229H909','#83a19c',3)
    return s
def build():
    layout={'终':(68,152,248,218,.105),'末':(341,132,257,237,.105),'地':(623,147,263,221,.105)}
    for i,ch in enumerate('明日方舟'):layout[ch]=(93+i*48,92,39,38,.105)
    glyph,base,strokeset,tip,focus,echo,proof=make_glyphs(0,layout,beam,auger,milling)
    main=G.union([p for ch,p in glyph.items() if ch!='末']);sign=glyph['末']
    defs=pigment(0)+grad('gold',[(0,'#fff0a4'),(.33,'#efd070'),(.62,'#d29b3c'),(1,'#f2d278')])
    plates=brush_plate(37,['#142b2d','#203539','#22393d','#1a3034','#2c4142'],(30,966,130,396,-8))
    plates+=tagpath('M65 171L141 105H306L327 124H606L626 145H867L923 169 881 344 842 383H157L87 353Z','#193032','opacity=".76"')
    plates+=tagpath('M106 382H442L453 393H520L534 382H864L849 447 835 457H125L137 442H94Z','#23393a')
    rng=random.Random(44)
    # Scribe marks, stock edges and a restrained engraved identifier.
    plate_marks=''
    for j in range(165):
        x=rng.uniform(98,874);y=rng.uniform(160,374)
        plate_marks+=line(f'M{x:.1f} {y:.1f}h{rng.uniform(2,32):.1f}','#9eb5aa',rng.uniform(.25,.9),rng.uniform(.06,.22))
    giant=ink('EF','Robson-Extrabold.otf',305,480,342,.01,'#344949','center')
    lines=seg=''
    lines+=line('M39 177H63L81 154H145M292 114H385L405 93H573M561 93H629L641 81H748M47 355H68L83 367H145','#92aaa0',2)+line('M552 102H615L627 90H730M749 88H768','#73958c',1)
    lines+=line('M126 390H387L402 403H423M568 398H787L808 378H892','#8a9c89',2)
    lines+=line('M62 175L87 151M82 136H249M659 449H780L787 442H864','#6f8982',1)
    for i in range(12):lines+=line(f'M{583+i*10} 99l4 -5','#b6c7ac',1.1)
    for i in range(5):
        lines+=tagpath(f'M{81+i*10} 393h5l-7 11h-5Z','#96aa94')
    for x,y in [(38,177),(571,93),(47,355),(894,378)]:lines+=rect(x-2.4,y-2.4,4.8,4.8,'#c0cbb0')
    for x,y in [(97,142),(902,165),(869,399)]:lines+=line(f'M{x-5} {y}h10m-5 -5v10','#80998d',1.3)
    # Microtype is confined to the mechanical register, off the readable faces.
    lines+=ink('TALOS–II',FONT,11,635,125,.16,'#a9b7a7')
    letters=baseline_lettering('ARKNIGHTS: ENDFIELD',FONT,32,490,445,.37,'#ced6c0','#263b3b')
    letters+=line('M145 435H213M768 435H837','#acb8a0',2.1)
    fx=tagpath(tip,'url(#gold)')+spark(focus[0]+13,focus[1]+12,7,'#fff0b1')
    # Left-hand corner catches from the same light as the machined faces.
    fx+=line('M102 147h39M653 139h57','#e8ebd4',1.35,.9)
    layers=[plates+plate_marks,giant,derrick(),lines,cast(main,0),cast(sign,0),letters,fx]
    props=dict(focus=focus,echoes=echo,guide=[146,262,370,445],mainName='终末地',signature='末',subject='取芯井架',finish='切削钢面',detail='螺旋排屑槽',accent='#eac573',monoMain=tagpath(main,'#e6e6e6'),monoSign=tagpath(sign,'#f2f2f2'))
    write_edition(0,defs,layers,strokeset,props,proof)
if __name__=='__main__':build()

