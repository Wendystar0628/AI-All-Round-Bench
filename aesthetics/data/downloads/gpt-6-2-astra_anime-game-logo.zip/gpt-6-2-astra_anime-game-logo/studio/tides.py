from atelier import *
def gesture(ch,i,ty,part,pts,w,p):
    # Bend the whole nib impression with a continuous shear, then pull out its dry tip.
    p=G.map_points(p,lambda x,y:(x+1.8*math.sin(y*.04)-.7*math.sin(x*.06),y-1.15*math.sin(x*.041)))
    a=pts[0];b=pts[-1];d=b-pts[-2];d/=np.linalg.norm(d)
    if ty in ('横','提'):
        a0=b-d*5;end=b+d*(8.8 if ch=='鸣' and i==7 else 4.6)
        return G.union(p,G.taper(a0,end,w*.63,.13))
    if ty=='点':
        d=b-a;d/=np.linalg.norm(d)
        return G.union(p,G.taper(tuple(a+d*2.4),tuple(a-d*4),w*.45,.1))
    if ty in ('折','竖','钩'):
        # A narrower lip on the last third, like pigment flowing to a low point.
        return G.map_points(p,lambda x,y:(x-.52*math.sin(y*.087),y+.42*math.sin(x*.05)))
    return p
def crest(ch,i,p):
    if (ch,i)!=('潮',12):return None
    wave=G.from_svg_d('M82.3 84.7C86.3 90.6 88.4 94.4 94.6 92.8C107.5 89.2 109.4 73.8 128 67C118.4 73.6 118.8 81.7 119 85C116 80.3 113.5 88.8 110.9 94.5C106.1 104.1 97.9 108 90.4 102.1C84.8 98.2 83 90.5 82.3 84.7Z M93.6 100.1C108 104.7 116 91.7 124.8 85.6C119.4 92.2 119.9 94.2 114.5 100C109.8 105 100.6 107.3 93.6 100.1Z')
    return G.union(p,wave),(104,95),wave
def backwash(ch,i,ty,part,pts,w,p):
    if not((ch=='鸣' and i==6) or (ch=='潮' and i in (0,1,2))):return None
    a,b=pts[0],pts[-1]
    if ch=='鸣':return G.union(p,G.from_svg_d('M73 84Q62 79 57 71Q64 85 79 92Z'))
    d=b-a;d/=np.linalg.norm(d);n=np.array([-d[1],d[0]])
    return G.union(p,G.polygon([a+n*w*.3,a-d*6-n*w*.05,a+d*4-n*w*.31]))
def spray(x,y,s,rot,col):
    return tagpath('M0 0C-4 -8 -3 -14 0 -22C0 -14 7 -6 0 0Z',col,f'transform="translate({x:.2f} {y:.2f}) rotate({rot:.1f}) scale({s:.2f})"')
def rising_wave():
    # The outside contour is drawn first; every line inside belongs to the same curling sheet.
    outer='M505 357C622 338 686 314 696 245C710 151 742 83 813 66C879 50 925 83 930 131C928 119 918 119 918 140C915 124 906 119 896 129C907 108 895 103 884 119C893 99 875 98 858 115C872 92 846 99 830 119C793 167 822 217 798 275C765 357 643 375 505 357Z'
    s=tagpath(outer,'url(#water)')
    s+=tagpath('M525 355C657 342 711 301 721 228C738 112 785 62 861 66C772 70 764 160 756 223C749 302 689 368 525 355Z','#387b80')
    s+=tagpath('M626 343C712 319 744 267 752 181C767 97 800 77 849 68C785 93 781 146 773 224C761 287 730 325 626 343Z','#79b8ac')
    # Etched flow follows the tangent of the body; there is no stroked outer border.
    rng=random.Random(821)
    for i in range(43):
        k=i/42;sh=rng.uniform(-3,3)
        d=f'M{552+75*k:.1f} {355-6*k:.1f} C{672+30*k:.1f} {346-8*k:.1f} {710+50*k:.1f} {302-12*k:.1f} {716+57*k:.1f} {225+17*k:.1f} C{727+47*k:.1f} {116+23*k:.1f} {789+33*k:.1f} {65+14*k+sh:.1f} {855+38*k:.1f} {68+17*k:.1f}'
        s+=line(d,rng.choice(['#c1e8d9','#76bcb2','#2b696e','#26777a','#d0f0df']),rng.uniform(.5,1.7),rng.uniform(.35,.83))
    s+=tagpath('M711 167C735 90 795 49 858 57C887 61 908 73 923 94C908 82 902 86 907 96C892 82 888 84 887 91C869 78 855 80 836 94C848 77 828 81 807 91C770 105 734 131 711 167Z','url(#foam)')
    s+=tagpath('M803 82C856 35 926 59 940 115C913 68 864 54 803 82Z','#9bdaca','opacity=".86"')
    s+=tagpath('M858 82C898 64 930 97 924 132C919 101 902 85 878 86L889 94Q870 87 858 93Z','#d2eddd','opacity=".93"')
    for x,y,sc,rot in [(936,108,.82,-31),(908,60,.65,-52),(881,48,.37,-68),(792,65,.53,62),(779,75,.32,47),(944,134,.31,-15),(852,48,.27,71)]:
        s+=spray(x,y,sc,rot,'#a7dfce')
    for i in range(106):
        a=rng.uniform(-2.42,.03);r=rng.uniform(.91,1.35)
        x=850+math.cos(a)*91*r;y=154+math.sin(a)*98*r
        s+=circle(x,y,rng.uniform(.37,1.75),'#a7dbca',f'opacity="{rng.uniform(.36,.83):.2f}"')
    return s
def build():
    layout={'鸣':(85,152,320,224,.085),'潮':(410,115,339,260,.085)}
    glyph,base,strokeset,tip,focus,echo,proof=make_glyphs(2,layout,gesture,crest,backwash)
    defs=pigment(2)+grad('water',[(0,'#234b56'),(.36,'#77b4a9'),(.50,'#558d8b'),(.75,'#316969'),(1,'#173f49')],.8,0,.25,1)
    defs+=grad('foam',[(0,'#4e9895'),(.51,'#d5f2dc'),(1,'#9ad8c8')])
    defs+=grad('jade',[(0,'#f2ffe6'),(.28,'#bce9cf'),(.5,'#69c9b4'),(.78,'#80d9c6'),(1,'#bcf2d9')])
    # Split washes bend with the current. Endpoints grow sparse at the two banks.
    rng=random.Random(155);swaths=[]
    for _ in range(410):
        k=rng.uniform(-1,1);span=max(0,1-k*k)**.49
        left=465-432*span+rng.uniform(-15,40);right=465+432*span+rng.uniform(-35,17)
        y=282+k*118
        lw=rng.uniform(1,8)*(.5+.5*span)
        path=f'M{left:.2f} {y+20:.2f}C{left+135:.2f} {y-50:.2f} {right-170:.2f} {y+54:.2f} {right:.2f} {y-31:.2f}C{right-144:.2f} {y+56+lw*2:.2f} {left+125:.2f} {y-41+lw:.2f} {left:.2f} {y+20:.2f}Z'
        swaths.append(tagpath(path,rng.choice(['#13363b','#153a3d','#193e41','#103235','#193b3e']),f'opacity="{rng.uniform(.62,1):.2f}"'))
    for _ in range(510):
        a=rng.uniform(0,math.tau)
        xx,yy=468+426*math.cos(a),280+119*math.sin(a)-17*math.cos(a)
        swaths.append(circle(xx+rng.uniform(-11,11),yy+rng.uniform(-9,9),rng.uniform(.45,1.65),'#193e41',f'opacity="{rng.uniform(.19,.71):.2f}"'))
    plate=''.join(swaths)
    plate+=tagpath('M60 321C172 384 352 345 499 365C629 380 766 373 860 310C779 396 646 423 481 408C314 394 158 417 83 387L134 381Q87 361 60 321Z','#15393b')
    plate+=tagpath('M122 381C297 421 405 384 544 400Q694 419 782 390Q689 432 526 423Q301 407 185 422Z','#194143')
    giant=ink('W','GARAIT.TTF',318,414,371,0,'#244a4d','center')
    lines=''
    curves=[('M22 361C133 400 235 387 315 368','#6ca89c',2.5),('M39 373C158 405 253 387 290 379','#accabd',.85),
            ('M62 315C31 298 62 274 127 265','#78a99d',1.2),('M84 318C29 303 59 282 105 278','#3f7874',1.3),
            ('M759 379C859 353 897 300 906 247C889 291 862 325 829 339','#a0cfc0',1.7),
            ('M122 413C238 442 426 412 537 430C627 440 680 427 726 414','#79aea2',1.5),
            ('M602 102C673 89 701 99 740 108','#55938d',.9)]
    for d,col,w in curves:lines+=line(d,col,w)
    rnd=random.Random(57)
    # Drops disperse in the same direction as the recurved pen.
    for j in range(35):
        x=rnd.uniform(31,202); y=315+math.sin(x*.013)*36+rnd.uniform(-16,25)
        lines+=spray(x,y,rnd.uniform(.085,.245),rnd.uniform(-85,-54),rnd.choice(['#78a9a1','#a5c3ab','#6a9892']))
    lower=baseline_lettering('WUTHERING WAVES','CormorantGaramond-SemiBold.ttf',37,456,415,.29,'#d2e4cd','#18383b')
    lower+=line('M131 407Q164 413 194 408M715 408Q753 404 778 393','#82b6a6',1.5)
    accents=tagpath(tip,'url(#jade)')
    fx,fy=focus
    accents+=line(f'M{fx-42:.1f} {fy+7:.1f}Q{fx-13:.1f} {fy+33:.1f} {fx+18:.1f} {fy-5:.1f}','#d5f9df',1.45)
    for x,y,r in [(fx+52,fy-59,2.3),(fx+62,fy-66,1.4),(908,87,2)]:accents+=circle(x,y,r,'#b8e8d2')
    layers=[plate,giant,rising_wave(),lines,cast(glyph['鸣'],2),cast(glyph['潮'],2),lower,accents]
    write_edition(2,defs,layers,strokeset,dict(focus=focus,echoes=echo,guide=[150,260,375,415],mainName='鸣潮',signature='潮',subject='回卷潮峰',finish='矿物水墨',detail='双股回浪',accent='#9ddfca',monoMain=tagpath(glyph['鸣'],'#eee'),monoSign=tagpath(glyph['潮'],'#f4f4f4')),proof)
if __name__=='__main__':build()

