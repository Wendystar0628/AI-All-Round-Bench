"""Three original environment plates. All surface, atmosphere and depth are computed here."""
import math, random, sys
from pathlib import Path
import cv2, numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent
W,H=2400,1500
Y,X=np.mgrid[0:H,0:W].astype('float32')
U,V=X/W,Y/H
rng=np.random.default_rng(712)
def rgb(h):return np.array(tuple(bytes.fromhex(h.lstrip('#'))),dtype='float32')
def mix(a,b,t):
    return a+(b-a)*(t[:,:,None] if isinstance(t,np.ndarray) and t.ndim==2 else t)
def noise(cx,cy=None):
    if cy is None:cy=int(cx*H/W)+1
    return cv2.resize(rng.normal(0,1,(max(2,int(cy)),max(2,int(cx)))).astype('float32'),(W,H),interpolation=cv2.INTER_CUBIC)
def fbm(start=6,octaves=5,ratio=1.65,stretch=1):
    out=np.zeros_like(X);amp=1
    for k in range(octaves):
        out+=noise(start*2**k,int(start*H/W*stretch*2**k))*amp;amp/=ratio
    return out
def clamp(v):return np.clip(v,0,1)
def glaze(im,col,amt):return mix(im,rgb(col),clamp(amt))
def sphere(sky,cx,cy,r,colors,light,banded=False,halo=.5):
    nx=(X-cx)/r;ny=(Y-cy)/r
    rho=nx*nx+ny*ny;nz=np.sqrt(clamp(1-rho))
    l=np.array(light)/np.linalg.norm(light)
    dp=nx*l[0]+ny*l[1]+nz*l[2]
    atm=np.exp(-np.abs(np.sqrt(rho)-1)*21)
    sky=glaze(sky,colors[2],atm*halo*.14)
    patterns=fbm(27,5,1.64,1.5 if not banded else 3)
    if banded:
        lat=ny*.85+nx*.27+.22*nz
        wisps=fbm(14,4,1.8,2.3)
        patterns=.55*patterns+np.sin(lat*34+wisps*.9)*1.1+np.sin(lat*83+wisps*.8)*.40
    base=mix(rgb(colors[0]),rgb(colors[1]),clamp((dp+.08)*1.13))
    relief=(patterns*9+(np.maximum(patterns-.55,0))*7)*(.3+.7*np.maximum(dp,0))
    base+=relief[:,:,None]
    glow=np.power(1-nz,3)*clamp((dp+.58)*1.5)
    base=mix(base,rgb(colors[2]),glow*.65)
    return mix(sky,base,clamp((1-np.sqrt(rho))*r+.5))
def stars(sky,n,hs=.75,bright='#e2f1ea',seed=31):
    rr=random.Random(seed)
    for i in range(n):
        x,y=rr.randrange(W),rr.randrange(max(1,int(H*hs)))
        lum=rr.uniform(.12,.64)
        if i%32==0:lum=.83
        col=tuple(float(v) for v in mix(sky[y,x],rgb(bright),lum))
        r=.3+rr.random()**4*1.7
        cv2.circle(sky,(x,y),max(1,round(r)),col,-1,cv2.LINE_AA)
        if i%127==0:
            size=rr.randint(4,11);bg=sky[y-1,x-1].copy()
            cv2.line(sky,(x-size,y),(x+size,y),tuple(map(float,mix(bg,rgb(bright),.42))),1,cv2.LINE_AA)
            cv2.line(sky,(x,y-size-2),(x,y+size+2),tuple(map(float,mix(bg,rgb(bright),.46))),1,cv2.LINE_AA)
    return sky
def finish(im,slug,grain=2.3):
    im=np.asarray(im,dtype='float32')
    vignette=1-clamp((np.hypot((U-.5)*1.1,(V-.5)*.8)-.32)*.55)
    im=im*vignette[:,:,None]+rng.normal(0,grain,(H,W,1)).astype('float32')
    out=ROOT/'assets'/slug;out.mkdir(exist_ok=True,parents=True)
    Image.fromarray(np.uint8(np.clip(im,0,255))).save(out/'world.jpg',quality=94,subsampling=0)
def hash2(x,z):
    with np.errstate(over='ignore'):
        n=x.astype(np.uint32)*np.uint32(374761393)+z.astype(np.uint32)*np.uint32(668265263)
        n=(n^(n>>13))*np.uint32(1274126177)
        return ((n^(n>>16)).astype('float32')/np.float32(4294967295))*2-1
def mapnoise(x,z,sc):
    x=x/sc;z=z/sc;i=np.floor(x).astype('int32');j=np.floor(z).astype('int32')
    a=(x-i).astype('float32');b=(z-j).astype('float32')
    a=a*a*(3-2*a);b=b*b*(3-2*b)
    v=hash2(i,j)*(1-a)+hash2(i+1,j)*a
    w=hash2(i,j+1)*(1-a)+hash2(i+1,j+1)*a
    return v*(1-b)+w*b
def landscape(sky,teal=True):
    focal=W*.77;horizon=H*.56;cam=151 if teal else 123
    Z=np.geomspace(8,4200,1100).astype('float32')[:,None]
    XX=(np.arange(W,dtype='float32')[None,:]-W*.50)*Z/focal
    def elevation(x,z):
        nx=x+mapnoise(x+853,z-552,335)*62
        nz=z+mapnoise(x-999,z+290,419)*86
        large=mapnoise(nx+115,nz+127,489)
        hills=(1-np.abs(mapnoise(nx+71,nz-421,265)))**2*111
        strength=clamp((z-70)/600)
        relief=164+126*large+hills+mapnoise(nx,nz,86)*28+mapnoise(x,z,39)*15+mapnoise(x,z,17)*6+mapnoise(x,z,7)*2.7+mapnoise(x,z,2.2)*1.1
        valley=np.exp(-((x-60-np.sin(z/198)*99)/(142+.027*z))**2)
        if teal:return (relief-98*valley)*(0.13+.87*strength)+32+48*np.exp(-((x-43)/83)**2-((z-180)/110)**2)
        return (relief-99*valley)*(.4+.48*strength)+4
    E=elevation(XX,Z);py=horizon+(cam-E)*focal/Z
    miny=np.minimum.accumulate(py,axis=0)
    idx=np.empty((H,W),np.int32);yy=np.arange(H-1,-1,-1,dtype='float32')
    for col in range(W):idx[:,col]=np.searchsorted(-miny[:,col],-yy)[::-1]
    mask=idx<len(Z);idx=np.minimum(idx,len(Z)-1)
    cols=np.arange(W);prev=np.maximum(idx-1,0)
    y0,y1=py[prev,cols],py[idx,cols]
    frac=clamp((y0-Y)/np.maximum(.001,y0-y1))
    z=Z[prev,0]*(1-frac)+Z[idx,0]*frac;x=(X-W*.5)*z/focal
    e=elevation(x,z)
    dx=(elevation(x+1.25,z)-e)/1.25;dz=(elevation(x,z+1.25)-e)/1.25
    norm=np.sqrt(1+dx*dx+dz*dz)
    light=(dx*.69+.65-dz*.34)/norm
    ridge=mapnoise(x*.9+z*.2,z*.8,13)+mapnoise(x,z,4)*.45
    n=mapnoise(x,z,48)+mapnoise(x,z,1.4)*.55+mapnoise(x,z,.45)*.22
    snow=clamp((e-120)/(135 if teal else 190)+(light-.63)*1.4+n*.21)*clamp((1/norm-.33)*2)
    if teal:
        rock=mix(rgb('23333d'),rgb('a8957a'),clamp(light*.85+.12+ridge*.12))
        rock=mix(rock,rgb('d6c6a9'),snow*.91)
        cast=clamp((elevation(x-24,z+9)-e-18)*.075)
        rock=mix(rock,rgb('313e44'),cast*.56)
        air=rgb('b49e85')
    else:
        rock=mix(rgb('183d42'),rgb('407074'),clamp(light*.8+.10+ridge*.14))
        rock=mix(rock,rgb('81a9a0'),snow*.7)
        air=rgb('8ab0ad')
    strata=np.sin(e*.73+x*.081+n*.9)
    rock+=((n*3+strata*2.3)*(1.3-np.exp(-z/400)))[:,:,None]
    rock=mix(rock,air,1-np.exp(-z/(1310 if teal else 850)))
    return np.where(mask[:,:,None],rock,sky)
class Draft:
    # Construction coordinates are on a 1600 x 1000 drawing table.
    def __init__(self,image):self.im=image;self.k=W/1600
    def pts(self,pts):return np.rint(np.array(pts)*self.k).astype(np.int32)
    def line(self,pts,col,w=1):
        cv2.polylines(self.im,[self.pts(pts)],False,tuple(map(float,rgb(col))),max(1,round(w*self.k)),cv2.LINE_AA)
    def poly(self,pts,col):cv2.fillPoly(self.im,[self.pts(pts)],tuple(map(float,rgb(col))),cv2.LINE_AA)
    def circ(self,x,y,r,col):
        cv2.circle(self.im,(round(x*self.k),round(y*self.k)),max(1,round(r*self.k)),tuple(map(float,rgb(col))),-1,cv2.LINE_AA)
    def rect(self,x,y,w,h,col):self.poly([(x,y),(x+w,y),(x+w,y+h),(x,y+h)],col)
def station(im,x,y,s,seed):
    d=Draft(im);rnd=random.Random(seed)
    def pts(q):return [(x+a*s,y+b*s) for a,b in q]
    def line(q,c,w=1):d.line(pts(q),c,w*s)
    def poly(q,c):d.poly(pts(q),c)
    def rect(a,b,w,h,c):d.rect(x+a*s,y+b*s,w*s,h*s,c)
    colors=['182e31','203639','2a3c3c','304444','334646']
    # Terraced footing, pylons and a gravel approach join each plant to its hillside.
    shade=im.copy();ds=Draft(shade)
    ds.poly(pts([(-178,-1),(-146,-23),(119,-27),(185,-1),(143,20),(-91,24),(-174,12)]),'373c3b')
    cv2.addWeighted(shade,.56,im,.44,0,dst=im)
    poly([(-168,-5),(134,-12),(160,-4),(141,3),(-134,9),(-168,4)],'69695e')
    poly([(-168,4),(-134,9),(141,3),(142,7),(-136,14),(-167,8)],'3b4544')
    for a in range(-133,142,19):
        line([(a,6),(a+3,13)],'6a695d',.8)
    line([(-123,10),(-167,25),(-215,30),(-260,45)],'76776b',3.0)
    def block(a,b,w,h,t=10):
        poly([(a,b),(a+w,b),(a+w,b+h),(a,b+h)],rnd.choice(colors))
        poly([(a,b),(a+t,b-t*.45),(a+w+t,b-t*.45),(a+w,b)],'76837a')
        poly([(a+w,b),(a+w+t,b-t*.45),(a+w+t,b+h-t*.45),(a+w,b+h)],'152a2c')
        for j in range(int(w/7)):
            v=a+3+j*7
            rect(v,b+3+rnd.uniform(0,1),rnd.uniform(1.5,3.4),rnd.uniform(.6,2.2),rnd.choice(['a39e7a','60706a','4c605b','eac47f']))
            if j%3==0:line([(v,b+9),(v,b+h-1)],'435651',.7)
    for j in range(27):
        a=rnd.uniform(-167,156);b=rnd.uniform(-23,5);w=rnd.uniform(10,34);h=rnd.uniform(12,42)
        block(a,b-h,w,h)
        if j%4==0:rect(a+2,b-h-10,3,10,'3b504c')
    for a,ht in [(-97,56),(78,77),(94,93)]:
        poly([(a,-4),(a+2,-ht),(a+8,-ht),(a+11,-4)],'263c3b')
        for b in range(16,ht,12):rect(a+3,-b,5,1,'89928a')
    def tower(a,h,wide):
        for side in [-1,1]:
            line([(a+wide*.5*side,0),(a+wide*.13*side,-h)],'1c3032',4)
            line([(a+(wide*.5*side)-1,0),(a+wide*.13*side-1,-h)],'8a958b',.8)
        for k in range(10):
            b=-h*k/10
            w0=wide*(.5-.37*k/10);w1=wide*(.5-.37*(k+1)/10)
            line([(a-w0,b),(a+w1,b-h/10),(a-w1,b-h/10),(a+w0,b)],'344b48',1.6)
            if k%3==0:
                rect(a-w0-4,b-2,w0*2+8,2.6,'99a096')
                line([(a-w0-4,b),(a-w0-4,b-5),(a+w0+4,b-5),(a+w0+4,b)],'6b7a72',.9)
        block(a-8,-h-9,15,10,3)
        line([(a-3,-h-10),(a-3,-h-25)],'546961',1.1)
        d.circ(x+(a-3)*s,y-(h+25)*s,1.4*s,'e8cb8d')
    tower(-31,165,37);tower(46,108,22)
    # Gantry crane, boxed cross-members and suspended cables.
    line([(-125,-79),(60,-67)],'304440',4)
    line([(-125,-88),(60,-74)],'445750',2)
    for j in range(18):
        a=-125+j*10;by=-79+j*.65
        line([(a,by),(a+5,by-8),(a+10,by+.7)],'52625a',1.4)
    line([(-30,-158),(-113,-88),(-113,-29)],'435752',1.3)
    line([(-30,-153),(52,-76)],'435752',1.1)
    for a in [-172,-111,140]:
        line([(a,9),(a,-48)],'31433f',1.6);line([(a-7,-44),(a+8,-44)],'31433f',1.2)
    for shift in [0,2.1]:
        q=[(-172+61*j/24,-41+8*math.sin(math.pi*j/24)+shift) for j in range(25)]
        line(q,'475952',.65)
def endfield():
    sky=mix(rgb('23333e'),rgb('c1ac8d'),clamp(V*1.65+.11*(1-U)))
    mist=fbm(5,5,1.9,2.4)
    sky+=mist[:,:,None]*3.3
    sky=stars(sky,530,.6,'#cfdfce')
    sky=sphere(sky,W*.245,H*.205,H*.142,('526169','d6c9ad','f0e3c5'),(-.69,-.52,.21),False,.62)
    sky=sphere(sky,W*.371,H*.098,H*.016,('61696b','cbc5b0','ded9c5'),(-.8,-.5,.1),False,.22)
    # Wind-stretched cloud banks veil the lower limb of the moon.
    clouds=fbm(6,6,1.68,4)
    sky=glaze(sky,'dbc9a9',clamp((clouds+.2)*.31)*np.exp(-((V-.32)/.24)**2)*.65)
    sky=glaze(sky,'e2c09c',np.exp(-((V-.52)/.115)**2)*.49)
    im=landscape(sky)
    # Installed structures inhabit ledges at different depths.
    station(im,1090,649,.31,31)
    station(im,353,710,.53,52)
    station(im,1309,790,1.15,26)
    # Foreground access road with horizontal service lights.
    d=Draft(im);rr=random.Random(456)
    rim=[(x,905+26*math.sin(x/155)+.081*(x-700)+rr.uniform(-10,9)) for x in range(-10,1624,12)]
    d.poly(rim+[(1630,1010),(-10,1010)],'233238')
    for i in range(560):
        xx=rr.uniform(0,1600);yy=rr.uniform(0,92)+918+26*math.sin(xx/155)+.081*(xx-700)
        le=rr.uniform(2,18)
        d.line([(xx,yy),(xx+le,yy-1.2)],rr.choice(['2d403c','354842','253836','41534c']),rr.uniform(.35,1.7))
    finish(im,'endfield',2.65)
if __name__=='__main__':
    globals()[sys.argv[1] if len(sys.argv)>1 else 'endfield']()

