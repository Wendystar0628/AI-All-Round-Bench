"""Render the published frame interface in Chrome and encode its three full-length chapters."""
import base64
import hashlib
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

import cv2
import numpy as np

from check_screen import Browser, ROOT
import imageio_ffmpeg


FPS = 60
WIDTH, HEIGHT = 1920, 1080
CHAPTERS = ('终末地', '星穹铁道', '鸣潮')
CHAPTER_FRAMES = 30 * FPS
FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()


def encode_chapter(browser, directory, chapter, references):
    dest = directory / f'chapter_{chapter + 1}.mp4'
    command = [
        FFMPEG, '-hide_banner', '-loglevel', 'error', '-y',
        '-f', 'image2pipe', '-framerate', str(FPS), '-c:v', 'mjpeg', '-i', 'pipe:0',
        '-map', '0:v:0', '-an', '-vf', 'scale=in_range=full:out_range=tv:out_color_matrix=bt709,format=yuv420p',
        '-c:v', 'libx264', '-preset', 'fast', '-crf', '17', '-profile:v', 'high',
        '-level:v', '4.2', '-g', '120', '-sc_threshold', '0', '-colorspace', 'bt709',
        '-color_trc', 'bt709', '-color_primaries', 'bt709', str(dest)
    ]
    encoder = subprocess.Popen(command, stdin=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
    started = time.perf_counter()
    try:
        for local_frame in range(CHAPTER_FRAMES):
            index = chapter * CHAPTER_FRAMES + local_frame
            browser.js(f'window.videoExport.frame({index})')
            shot = browser.call('Page.captureScreenshot', {
                'format': 'jpeg', 'quality': 94, 'fromSurface': True, 'optimizeForSpeed': True
            })
            pixels = base64.b64decode(shot['data'])
            encoder.stdin.write(pixels)
            if local_frame in (0, 180, 875, 1248, 1586, CHAPTER_FRAMES - 1):
                references[index] = pixels
            if (local_frame + 1) % 300 == 0:
                elapsed = time.perf_counter() - started
                print(f'{CHAPTERS[chapter]}  {local_frame + 1}/{CHAPTER_FRAMES}  {elapsed:.0f}s', flush=True)
        encoder.stdin.close()
        if encoder.wait():
            raise RuntimeError(f'Encoding failed for chapter {chapter + 1}')
    finally:
        if encoder.poll() is None:
            encoder.terminate()
            encoder.wait()
    return dest


def assemble(directory, segments):
    playlist = directory / 'segments.txt'
    playlist.write_text(''.join(f"file {segment.name}\n" for segment in segments), encoding='ascii')
    meta = directory / 'chapters.ffmeta'
    meta.write_text(';FFMETADATA1\ntitle=异世字形图鉴 · 字形构造展映\n' + ''.join(
        f'[CHAPTER]\nTIMEBASE=1/1000\nSTART={i*30000}\nEND={(i+1)*30000}\ntitle={name}\n'
        for i, name in enumerate(CHAPTERS)), encoding='utf-8')
    dest = directory / 'show.mp4'
    subprocess.run([
        FFMPEG, '-hide_banner', '-loglevel', 'error', '-y',
        '-f', 'concat', '-safe', '1', '-i', str(playlist), '-f', 'ffmetadata', '-i', str(meta),
        '-map', '0:v:0', '-map_metadata', '1', '-map_chapters', '1', '-c:v', 'copy',
        '-movflags', '+faststart', str(dest)
    ], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
    return dest


def verify_video(path, references):
    # Decode the entire video and reject truncated or malformed bitstreams.
    subprocess.run([FFMPEG, '-v', 'error', '-xerror', '-i', str(path), '-map', '0:v:0',
                    '-f', 'null', '-'], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
    video = cv2.VideoCapture(str(path))
    try:
        assert video.isOpened()
        assert round(video.get(cv2.CAP_PROP_FRAME_COUNT)) == 3 * CHAPTER_FRAMES
        assert abs(video.get(cv2.CAP_PROP_FPS) - FPS) < .0001
        assert int(video.get(cv2.CAP_PROP_FRAME_WIDTH)) == WIDTH
        assert int(video.get(cv2.CAP_PROP_FRAME_HEIGHT)) == HEIGHT
        errors = []
        for index, source in sorted(references.items()):
            video.set(cv2.CAP_PROP_POS_FRAMES, index)
            ok, actual = video.read()
            assert ok, index
            expected = cv2.imdecode(np.frombuffer(source, dtype=np.uint8), cv2.IMREAD_COLOR)
            error = float(cv2.absdiff(expected, actual).mean())
            assert error < 5, (index, error)
            errors.append(error)
        print(f'Verified 5400 decoded frames and {len(errors)} image comparisons; '
              f'largest mean channel difference {max(errors):.2f}/255.', flush=True)
    finally:
        video.release()


def main():
    with tempfile.TemporaryDirectory(prefix='glyph-atlas-movie-') as scratch:
        directory = Path(scratch)
        browser = Browser()
        references = {}
        try:
            browser.resize(WIDTH, HEIGHT)
            browser.open()
            assert browser.js("window.videoExport.begin('show',{fps:60})") == {'frames': 5400}
            assert browser.js("getComputedStyle(document.querySelector('.theater-tools')).display") == 'none'
            segments = [encode_chapter(browser, directory, i, references) for i in range(3)]
            browser.js('window.videoExport.end()')
            assert not browser.errors, browser.errors
        finally:
            browser.close()
        movie = assemble(directory, segments)
        verify_video(movie, references)
        pending = ROOT / 'show.partial.mp4'
        shutil.copyfile(movie, pending)
        with movie.open('rb') as src, pending.open('rb') as dst:
            assert hashlib.file_digest(src,'sha256').digest() == hashlib.file_digest(dst,'sha256').digest()
        pending.replace(ROOT / 'show.mp4')
        print('show.mp4 ready', flush=True)


if __name__ == '__main__':
    main()
