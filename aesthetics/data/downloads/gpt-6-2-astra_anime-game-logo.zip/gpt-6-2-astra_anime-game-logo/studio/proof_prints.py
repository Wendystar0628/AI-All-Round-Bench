"""Check print registration against the delivery, then prepare a labelled exploded proof."""
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from common import ROOT,PROOFS,FONTS,NAMES
def check_and_print(name):
    folder=ROOT/'logos'/name
    filenames=sorted((folder/'layers').glob('*.png'))
    assert len(filenames)==8,name
    final=Image.open(folder/'final.png').convert('RGBA')
    bw=Image.open(folder/'mono.png').convert('RGBA')
    assert final.size==bw.size==(4200,2184)
    assert final.getchannel('A').getextrema()==(0,255)
    xy=np.array(bw)
    assert np.array_equal(xy[:,:,0],xy[:,:,1]) and np.array_equal(xy[:,:,0],xy[:,:,2])
    assert np.array_equal(xy[:,:,3],np.asarray(final.getchannel('A')))
    joined=Image.new('RGBA',final.size);slices=[]
    for p in filenames:
        layer=Image.open(p)
        assert layer.mode=='RGBA' and layer.size==joined.size and layer.getbbox(),p
        joined.alpha_composite(layer);slices.append(layer.resize((850,151),Image.Resampling.LANCZOS))
    assert np.array_equal(np.asarray(joined),np.asarray(final)),name+' registration error'
    proof=Image.new('RGB',(1440,1050),'#181a25')
    draw=ImageDraw.Draw(proof)
    for x in range(0,1441,32):draw.line((x,0,x,1050),fill='#1e202c')
    for y in range(0,1051,32):draw.line((0,y,1440,y),fill='#1e202c')
    cfont=lambda size:ImageFont.truetype(str(FONTS/'msyh.ttc'),size)
    mfont=lambda size:ImageFont.truetype(str(FONTS/'consola.ttf'),size)
    draw.text((58,37),'GLYPH ATLAS    /    SEPARATION PROOF',font=mfont(17),fill='#c8b4dc')
    draw.text((56,69),name+'  ／  分层展开',font=cfont(34),fill='#ebe7ef')
    draw.text((1383,96),'4200 × 2184 PX',font=mfont(17),fill='#a6a0b7',anchor='rm')
    draw.line((57,132,1383,132),fill='#53495d')
    for k,layer in enumerate(slices):
        # Project the entire shared canvas before placing it on its depth plane.
        layer=layer.transform((915,151),Image.Transform.AFFINE,(1,.4,-62,0,1,0),Image.Resampling.BICUBIC)
        layer=layer.rotate(3.1,resample=Image.Resampling.BICUBIC,expand=True)
        x=63+k*13;y=819-k*88
        proof.paste(layer,(x,y),layer)
        left,top,right,bottom=layer.getbbox()
        line_y=y+(top+bottom)//2
        xe=x+right+8
        draw.line([(xe,line_y),(1048,line_y),(1063,line_y-10),(1106,line_y-10)],fill='#9687a4',width=1)
        draw.ellipse((1104,line_y-12,1109,line_y-7),fill='#d3b7e6')
        draw.text((1120,line_y-10),str(k+1).zfill(2),font=mfont(16),fill='#b29bc9',anchor='lm')
        draw.text((1162,line_y-11),filenames[k].stem[3:],font=cfont(20),fill='#ede5f3',anchor='lm')
    proof.save(PROOFS/name/'分层展开.png')
    print(f'{name}  8/8 layers, RGBA and registration exact, mono neutral')
if __name__=='__main__':
    for name in NAMES:check_and_print(name)

