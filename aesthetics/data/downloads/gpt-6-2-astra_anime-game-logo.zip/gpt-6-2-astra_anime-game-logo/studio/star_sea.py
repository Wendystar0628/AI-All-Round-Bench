from worlds import *
def astral():
    # A warped density field separates violet emission, rose gas and obscuring dust.
    n=fbm(5,7,1.87);m=fbm(10,5,1.78)
    warpX=(X+109*n+48*np.sin(V*7.1+U*3)).astype('float32')
    warpY=(Y+77*m-80*np.sin(U*5.6)).astype('float32')
    fine=cv2.remap(fbm(9,6,1.68),warpX,warpY,cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT)
    spine=.84-.70*U+.10*np.sin(U*4.7+1)
    band=np.exp(-((V-spine+.037*n)/(.13+.021*m))**2)
    broad=np.exp(-((V-spine+.06*n)/.37)**2)
    sky=mix(rgb('12132a'),rgb('393259'),broad*.78)
    sky=glaze(sky,'6c528c',clamp((n*.17+.38)*broad))
    gas=clamp((fine*.32+.63)*band)
    sky=glaze(sky,'a17b9e',gas*.82)
    ridge=np.exp(-np.abs(fine+.35*n+.3)*3)*band
    sky=glaze(sky,'d8afc3',ridge*.27)
    dust=clamp((m+fine*.52-.52)*.75)*band
    sky=glaze(sky,'222136',dust*.8)
    sky+=fbm(78,4,1.8)[:,:,None]*broad[:,:,None]*2.8
    sky=stars(sky,3000,1,'#eae2ff',76)
    cx=W*.702;cy=H*.183;r=H*.166
    # Inclined circular ring system projected into the image plane. Front half occults the disk.
    a=math.radians(-25);u=(X-cx)*math.cos(a)+(Y-cy)*math.sin(a);v=-(X-cx)*math.sin(a)+(Y-cy)*math.cos(a)
    rr=np.hypot(u,v/.225)/r
    extent=clamp((rr-1.21)*42)*clamp((2.19-rr)*45)
    bands=.50+.22*np.sin(rr*127)+.12*np.sin(rr*332)+.18*np.sin(rr*39)
    bands*=1-np.exp(-((rr-1.76)/.043)**2)*.97
    bands*=1-np.exp(-((rr-1.92)/.012)**2)*.96
    broad_light=np.cos(rr*9.2)*.23+.53
    ring=mix(rgb('a086a3'),rgb('f2d8c0'),clamp(broad_light+.3*bands))
    alpha=extent*clamp(bands*.78+.11)
    sky=mix(sky,ring,alpha)
    sky=sphere(sky,cx,cy,r,('302a47','c8aac3','fbe0ce'),(-.68,-.63,.38),True,.92)
    shadow=clamp((u/r+.22)*1.8)*clamp(1.07-rr*.19)
    sky=mix(sky,ring,(v>0)*alpha*(1-.48*shadow))
    sky=sphere(sky,W*.17,H*.29,H*.037,('28283d','b4a8bc','e0d2cd'),(-.66,-.7,.1),False,.36)
    # Luminous dust close to the rails; two grade-separated tracks meet at a vanishing point.
    t=U
    rail=.923-.093*t-.132*t*t
    glow=np.exp(-((V-rail)/(.009+.012*(1-t)))**2)
    sky=glaze(sky,'ba9eaf',glow*.34)
    im=np.uint8(np.clip(sky,0,255))
    d=Draft(im)
    fn=lambda x: 923-93*(x/1600)-132*(x/1600)**2
    for offset,col,sw in [(1,'c7bcc8',1.1),(7,'787498',2.5),(14,'49455e',4.0),(24,'99849e',1.0)]:
        d.line([(x,fn(x)+offset*(1.25-x/1750)) for x in range(-4,1610,8)],col,sw)
    for j in range(150):
        x=1600*(1-(1-j/150)**1.5);k=1.3-x/1550
        d.line([(x,fn(x)),(x-8*k,fn(x)+25*k)],'797287',max(.4,k*2))
    def carriage(x,s,head=False):
        y=fn(x)-4;h=31*s
        def pts(coords): return [(x+a*s, y+b*s+(fn(x+a*s)-fn(x))) for a,b in coords]
        def poly(q,c): d.poly(pts(q),c)
        def ln(q,c,w):d.line(pts(q),c,w*s)
        if not head:
            poly([(0,-29),(8,-33),(95,-33),(100,-28),(100,-8),(94,-4),(3,-4)],'25283e')
            ln([(1,-29),(8,-33),(94,-33),(100,-29)],'cbb4ab',1.6)
            ln([(2,-12),(97,-12)],'8c7890',1.2)
            for j in range(8):
                a=7+j*11.7
                poly([(a,-25),(a+6,-25),(a+6,-18),(a,-18)],['c6a88e','b7a496','d2bcac'][j%3])
                ln([(a+3,-25),(a+3,-18)],'7e7180',.6)
            for q in [12,22,76,86]:
                px,py=pts([(q,-3)])[0];d.circ(px,py,s*3,'211f31')
            ln([(0,-6),(100,-6)],'6e6578',1.5)
        else:
            poly([(0,-32),(18,-32),(22,-25),(57,-25),(83,-20),(104,-8),(100,-4),(3,-4)],'27273c')
            ln([(0,-31),(17,-32),(22,-25),(59,-25),(84,-19),(104,-8)],'d3b49a',1.5)
            poly([(44,-25),(43,-36),(50,-36),(51,-24)],'34344a')
            ln([(38,-14),(84,-14),(96,-9)],'bc988a',1.7)
            for j in [3,11]:poly([(j,-26),(j+5,-26),(j+5,-19),(j,-19)],'d2b591')
            px,py=pts([(98,-10)])[0];d.circ(px,py,s*2.2,'fff1cd')
    for j in range(4):carriage(254+144*j,1.37)
    carriage(830,1.38,True)
    # A sparse, hand-selected set of cross-shaped highlights.
    for x,y,r in [(202,125,7),(520,224,6),(1332,469,8.5),(218,664,5),(1044,731,4),(479,478,3)]:
        d.poly([(x-r*1.6,y),(x-1,y-1),(x,y-r),(x+1,y-1),(x+r*1.6,y),(x+1,y+1),(x,y+r),(x-1,y+1)],'e4d6d8')
    finish(im,'astral',1.8)
if __name__=='__main__':astral()

