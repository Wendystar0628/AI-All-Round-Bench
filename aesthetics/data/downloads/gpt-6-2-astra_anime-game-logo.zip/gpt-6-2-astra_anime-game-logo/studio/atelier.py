"""版画压制、笔形对应、材质及分版输出。坐标均为本作的 1000 × 520 母版。"""
from common import *
from stroke_data import strokes
from functools import lru_cache
import base64, cv2
class OutlineFont(Font):
    def outline(self,ch):
        if ch not in self._outlines:
            from fontTools.pens.recordingPen import DecomposingRecordingPen
            pen=DecomposingRecordingPen(self.gs)
            self.gs[self.gname(ch)].draw(pen)
            p=pathops.Path()
            pen.replay(p.getPen())
            self._outlines[ch]=G.simplify(G.scale(p,self.k))
        return pathops.Path(self._outlines[ch])
@lru_cache(maxsize=None)
def face(name): return OutlineFont(str(FONTS/name))
def words(s,f,size,x,y,track=0,align='left'):
    return latin.text_line(face(f),s,size,x,y,tracking=track,align=align)[0]
def ink(s,f,size,x,y,track,fill,align='left'):
    return tagpath(words(s,f,size,x,y,track,align),fill)
def baseline_lettering(s,f,size,x,y,track,fill,edge):
    p=words(s,f,size,x,y,track,'center')
    return tagpath(p,fill,f'stroke="{edge}" stroke-width="1.9" stroke-linejoin="round" paint-order="stroke"')
def points(p):return list(G.flatten(p,.17))
def outlines(p):
    cs=[]
    for cc in points(p):
        if len(cc)<3:continue
        ar=cv2.contourArea(cc.astype('float32'),oriented=True)
        if abs(ar)>.016:cs.append((abs(ar),ar<0,cc))
    return sorted(cs,key=lambda e:-e[0])
def sampled(v,n):
    v=np.concatenate([v,v[:1]])
    t=np.r_[0,np.cumsum(np.linalg.norm(np.diff(v,axis=0),axis=1))]
    s=np.arange(n)*t[-1]/n
    return np.array([np.interp(s,t,v[:,k]) for k in (0,1)]).T
def morph_pair(a,b):
    # Match by winding, centroid and area; new holes grow from a point.
    A=outlines(a)
    B=outlines(b)
    pairs=[]
    for area,wind,bb in B:
        matches=[(np.linalg.norm(cc.mean(0)-bb.mean(0))+.35*abs(np.sqrt(area)-np.sqrt(ar)),i) for i,(ar,wi,cc) in enumerate(A) if wi==wind]
        aa=A.pop(min(matches)[1])[2] if matches else bb.mean(0)[None,:]
        pairs.append((aa,bb))
    for ar,wi,aa in A:pairs.append((aa,aa.mean(0)[None,:]))
    result=[]
    for aa,bb in pairs:
        n=min(132,max(12,int(max(len(aa),len(bb))*1.7)))
        a,b=sampled(aa,n),sampled(bb,n)
        score=[np.sum((np.roll(a,i,axis=0)-b)**2) for i in range(n)]
        a=np.roll(a,int(np.argmin(score)),axis=0)
        result.append([np.round(a.reshape(-1),2).tolist(),np.round(b.reshape(-1),2).tolist()])
    return result

def field(w,h,cell,rng):
    cols=max(2,round(w/cell)+1)
    rows=max(2,round(h/cell)+1)
    return cv2.resize(rng.normal(0,1,(rows,cols)).astype('float32'),(w,h),interpolation=cv2.INTER_CUBIC)
def pigment(kind):
    w,h=1800,936
    y,x=np.mgrid[0:h,0:w].astype('float32')
    x*=W/w;y*=H/h
    rng=np.random.default_rng(114+kind)
    n=field(w,h,86,rng)*.55+field(w,h,24,rng)*.24+field(w,h,4,rng)*.12
    grain=rng.normal(0,1,(h,w)).astype('float32')
    if kind==0:
        ramp=[(0,'a3bcc2'),(.21,'e7eddf'),(.309,'fffdea'),(.311,'bfd1cb'),(.47,'f4f6e8'),(.547,'e2e8d9'),(.549,'9aaeb0'),(.63,'d6e0d2'),(.76,'fbf1ca'),(.89,'91acaf'),(1,'7f969d')]
        t=(y+.025*x+n*3)/H
        v=grain*3.3+rng.normal(0,1,(h,1))*2.0+n*3+np.sin(y*4.5+x*.03)*2.2
    elif kind==1:
        ramp=[(0,'e3ba80'),(.22,'fff0c7'),(.35,'f5dfba'),(.47,'fff9e6'),(.56,'f0dfce'),(.617,'c5b7c5'),(.635,'ecdcde'),(.72,'fff0ce'),(.91,'d2b38f'),(1,'edc9a0')]
        t=(y-.039*x+20+n*10)/H
        v=grain*2.8+n*7+np.sin(1.2*y+.008*x)*1.1
    else:
        ramp=[(0,'a1d6ca'),(.21,'d7f0db'),(.4,'ffffed'),(.56,'d2f3dd'),(.64,'add8c9'),(.76,'76d4c6'),(.83,'c4f8dd'),(1,'4eaaa8')]
        t=(y-.052*x+26+n*17)/H
        v=grain*3+n*6+np.maximum(0,np.sin(x*.038+y*.087+n*3.5)-.77)*30
    c=np.array([tuple(bytes.fromhex(k)) for _,k in ramp])
    rgb=np.stack([np.interp(t,[s for s,_ in ramp],c[:,k]) for k in range(3)],-1)
    # Pigment is deposited in the actual reflective surface. A local stain is
    # strongest at the tool mark and peters out towards the other characters.
    if kind==0:
        near=np.exp(-((x-472)/116)**2-((y-344)/74)**2)
        stain=np.clip((.16+n*.32)*near,0,.38)
        pigment_color=np.array([226,190,118])
    elif kind==1:
        near=np.exp(-((x-378)/167)**2-((y-182)/129)**2)
        stain=np.clip((.24+n*.43)*near,0,.57)
        pigment_color=np.array([229,186,112])
        nightband=np.exp(-((y-311+.061*x+7*n)/25)**2)
        rgb+=(np.array([-25,-23,4])*nightband[:,:,None])
    else:
        near=np.exp(-((x-694)/246)**2-((y-319)/122)**2)
        stain=np.clip((.26+n*.45)*near,0,.6)
        pigment_color=np.array([76,186,166])
        caustic=np.exp(-abs(n+.51*np.sin(x*.041+y*.063))*11)
        rgb+=caustic[:,:,None]*np.array([8,14,6])
    rgb=rgb*(1-stain[:,:,None])+pigment_color*stain[:,:,None]
    img=Image.fromarray(np.uint8(np.clip(rgb+v[:,:,None],0,255)))
    buf=io.BytesIO();img.save(buf,format='JPEG',quality=88,subsampling=0)
    data=base64.b64encode(buf.getvalue()).decode()
    return f'<pattern id="face" width="1000" height="520" patternUnits="userSpaceOnUse"><image width="1000" height="520" href="data:image/jpeg;base64,{data}"/></pattern>'

def grad(name,colors,x1=0,y1=0,x2=1,y2=1):
    return f'<linearGradient id="{name}" x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}">'+''.join(f'<stop offset="{stop}" stop-color="{col}"/>' for stop,col in colors)+'</linearGradient>'
def dashed_lozenge(x,y,r,color):
    return tagpath(dline([(x,y-r),(x+r*.58,y),(x,y+r),(x-r*.58,y)],True),color)
def brush_plate(seed,colors,shape):
    # Broken selvage: rows travel along parallel curves; their tips lie on a rough oval envelope.
    rng=random.Random(seed);pieces=[]
    x0,x1,y0,y1,bend=shape
    for _ in range(350):
        y=rng.uniform(y0,y1)
        k=(y-(y0+y1)/2)/((y1-y0)/2)
        fade=max(0,1-abs(k)**2.1)**.47
        half=(x1-x0)*.5*fade
        mid=(x0+x1)*.5
        l=mid-half+rng.uniform(-18,45);r=mid+half+rng.uniform(-40,15)
        thick=rng.uniform(1.1,8)*(.3+.7*fade)
        b=bend*(1-abs(k)*.25);j=rng.uniform(-2,2)
        p=f'M{l:.1f} {y+thick:.1f} Q{mid:.1f} {y+b:.1f} {r:.1f} {y+j:.1f} Q{mid:.1f} {y+b+thick*2:.1f} {l:.1f} {y+thick:.1f}Z'
        pieces.append(tagpath(p,rng.choice(colors),f'opacity="{.42+fade*.47:.2f}"'))
    for _ in range(600):
        a=rng.random()*math.tau; z=rng.uniform(.75,1.02)
        x=(x0+x1)*.5+(x1-x0)*.5*math.cos(a)*z;y=(y0+y1)*.5+(y1-y0)*.5*math.sin(a)*z
        pieces.append(circle(x,y,rng.uniform(.22,1.5),rng.choice(colors),'opacity=".6"'))
    return ''.join(pieces)

def make_glyphs(kind,layout,redraw,special,echo):
    font=face(FACES[kind]);batch=[];whole={};bases={};echoes=[];focuspoint=None;specialp=None;proof=[]
    for ch,(x,y,w,h,shear) in layout.items():
        original=G.scale(normalized(font,ch),10)
        data=strokes(ch)
        specs=[S(ty,part,*[(a*10,b*10) for a,b in pts],w=wd*10,pad=wd*1.5) for ty,part,pts,wd in data]
        char=Char(font,ch,specs,src=original)
        gl=[];mark=[]
        def place(p,slant):
            return G.affine(p,w/100,0,-slant*h/100,h/100,x+slant*h*.6,y)
        x_min,y_min,x_max,y_max=font.outline(ch).bounds
        source_width=h*(x_max-x_min)/(y_max-y_min)
        def place_source(p):
            return G.affine(p,source_width/100,0,0,h/100,x+(w-source_width)/2,y)
        bases[ch]=place_source(G.scale(original,.1))
        for i,(ty,part,pts,wd) in enumerate(data):
            p=G.scale(G.inter(char.strokes[i].piece,original),.1)
            sty=redraw(ch,i,ty,part,np.array(pts),wd,p)
            replacement=special(ch,i,sty)
            q=echo(ch,i,ty,part,np.array(pts),wd,sty)
            accent=None;label=None
            if replacement:
                q,focus,accent=replacement
                focuspoint=[x+w*focus[0]/100+shear*h*(.6-focus[1]/100),y+h*focus[1]/100]
                specialp=place(accent,shear)
                label='focus'
            elif q is not None:
                label='echo'
                ep=pts[-1]
                echoes.append([x+w*ep[0]/100+shear*h*(.6-ep[1]/100),y+h*ep[1]/100])
            else:q=sty
            src,dialect,target=place_source(p),place(sty,shear),place(q,shear)
            rec={'glyph':ch,'n':i+1,'type':ty,'part':part,'phase':0 if ty in ('横','提') else 1 if ty in ('竖','折','钩') else 2,'a':G.to_svg_d(src),'b':G.to_svg_d(dialect),'m':morph_pair(src,dialect)}
            if label:
                rec.update(c=G.to_svg_d(target),special=label,ext=morph_pair(dialect,target))
            batch.append(rec);gl.append(target)
            mark.append((p,pts,ty,i+1))
        whole[ch]=G.union(gl)
        proof.append((ch,mark))
    return whole,bases,batch,specialp,focuspoint,echoes,proof

LAYER_NAMES=['底板','背景巨字','主体元素','细线与刻度','主字与系列名','签名字','英文','星芒与高光']
INK_TONES=[
    (17,24,32,42), (47,47,47,47), (33,85,146,190), (58,105,151,180),
    (24,75,215,244), (24,75,221,249), (26,78,192,218), (47,130,202,250)
]
def monochrome_separation(image,plane):
    values=INK_TONES[plane]
    mono=ImageOps.grayscale(image).point([values[i//64] for i in range(256)]).convert('RGBA')
    mono.putalpha(image.getchannel('A'))
    return mono
SHADOW=['#17292d','#21182e','#092d32']
RIMS=['#849b9d','#887560','#539c98']
def cast(p,kind,size=1):
    d=G.to_svg_d(p)
    # Edges are offsets of the finished outline; interruptions in the glyph remain open.
    return (tagpath(d,SHADOW[kind],f'transform="translate({1.7*size} {3.6*size})" stroke="{SHADOW[kind]}" stroke-width="{3.0*size}" stroke-linejoin="round"')+
            tagpath(d,'url(#face)',f'stroke="{RIMS[kind]}" stroke-width="{1.35*size}" stroke-linejoin="round" paint-order="stroke"')+
            tagpath(G.diff(p,G.move(p,.53*size,1.0*size)),['#ffffeb','#fffae6','#edfff3'][kind],'opacity=".85"'))
def stroke_proof(proof,path):
    cell=275;im=Image.new('RGB',(min(4,len(proof))*cell,math.ceil(len(proof)/4)*(cell+50)),'#e9e7dc')
    draw=ImageDraw.Draw(im);ft=ImageFont.truetype(str(FONTS/'msyh.ttc'),18)
    palette=['#368a99','#a45c51','#795698','#b2843c','#407674','#a2577f','#586faa','#76924d']
    for n,(ch,records) in enumerate(proof):
        x=(n%4)*cell+18;y=(n//4)*(cell+50)+18
        body=''
        for p,pts,ty,i in records:
            body+=tagpath(p,palette[(i-1)%len(palette)],'opacity=".83"')+line(dline(pts),'#17232a',.48)
        tile=svg_image(body,w=100,h=100,scale=2.35)
        im.paste(tile,(x,y+25),tile)
        draw.text((x,y-4),f'{ch}  /  {len(records)} 笔',fill='#1f3840',font=ft)
        for _,pts,_,i in records:
            ax,ay=pts[0];tx=x+ax*2.35;ty=y+25+ay*2.35
            draw.ellipse((tx-8,ty-8,tx+8,ty+8),fill='#26323a')
            draw.text((tx,ty),str(i),fill='#fffde7',anchor='mm',font=ImageFont.truetype(str(FONTS/'consola.ttf'),11))
    im.save(path)
def write_edition(kind,defs,layers,strokeset,props,proof):
    slug,name=SLUGS[kind],NAMES[kind]
    target=ROOT/'logos'/name
    (target/'layers').mkdir(exist_ok=True,parents=True)
    pd=PROOFS/name;pd.mkdir(exist_ok=True)
    stroke_proof(proof,pd/'笔画标注.png')
    # Establish the tonal proof before printing material separations.
    bare=layers.copy()
    bare[4]=props['monoMain'];bare[5]=props['monoSign']
    gray=svg_image(''.join(bare),defs,scale=1)
    alpha=gray.getchannel('A');gray=ImageOps.grayscale(gray).point(lambda a: 21 if a<55 else 82 if a<120 else 166 if a<180 else 240).convert('RGBA');gray.putalpha(alpha)
    del props['monoMain'],props['monoSign']
    data=dict(defs=defs,layers=layers,strokes=strokeset,inkTones=INK_TONES,**props)
    asset_dir=ASSETS/slug;asset_dir.mkdir(exist_ok=True)
    (asset_dir/'edition.js').write_text('window.editions.push('+json.dumps(data,ensure_ascii=False,separators=(',',':'))+');',encoding='utf-8')
    doc='<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="520" viewBox="0 0 1000 520"><defs>'+defs+'</defs>'+''.join(layers)+'</svg>'
    (asset_dir/'logo.svg').write_text(doc,encoding='utf-8')
    size=(4200,2184)
    total=Image.new('RGBA',size)
    mono=Image.new('RGBA',size)
    only=Image.new('RGBA',(800,416))
    thumbs=[]
    for i,part in enumerate(layers):
        # Each separation is independently rasterized on the final grid.
        img=svg_image(part,defs,scale=4.2)
        img.save(target/'layers'/f'{i+1:02d}_{LAYER_NAMES[i]}.png',compress_level=6)
        mono.alpha_composite(monochrome_separation(img,i))
        total.alpha_composite(img)
        small=img.resize((800,416),Image.Resampling.LANCZOS)
        if i in (4,5):only.alpha_composite(small)
        thumbs.append(small)
    total.save(target/'final.png',compress_level=6)
    downs=total.resize((800,416),Image.Resampling.LANCZOS)
    mono.save(target/'mono.png')
    sample=Image.new('RGB',(1200,880),'#dcdedc');draw=ImageDraw.Draw(sample)
    font=ImageFont.truetype(str(FONTS/'msyh.ttc'),16)
    items=[('彩稿',downs,'#253941'),('黑白',mono,'#b2b5b2'),('去色',ImageOps.grayscale(downs).convert('RGBA'),'#626767'),('独字',only,'#273238'),('白底',downs,'#ffffff'),('黑底',downs,'#000000')]
    items[2][1].putalpha(downs.getchannel('A'))
    for j,(title,im,bg) in enumerate(items):
        tile=Image.new('RGB',(400,208),bg);v=im.resize(tile.size,Image.Resampling.LANCZOS);tile.paste(v,(0,0),v)
        x=(j%3)*400;y=(j//3)*245
        sample.paste(tile,(x,y));draw.text((x+10,y+211),title,fill='#28373c',font=font)
    draw.text((10,495),'64 px / 主名字形',fill='#25353a',font=font)
    v=downs.resize((123,64),Image.Resampling.LANCZOS);sample.paste(v,(205,478),v)
    draw.text((418,495),'上色前的明暗小稿',fill='#25353a',font=font)
    tonal=gray.resize((143,74),Image.Resampling.LANCZOS);sample.paste(tonal,(628,474),tonal)
    for j,v in enumerate(thumbs):
        small=v.resize((292,152),Image.Resampling.LANCZOS);x=(j%4)*300;y=(j//4)*165+555
        sample.paste(small,(x,y),small);draw.text((x+4,y+5),LAYER_NAMES[j],fill='#324753',font=font)
    sample.save(pd/'校样.jpg',quality=94)
    print(name,total.size,flush=True)

