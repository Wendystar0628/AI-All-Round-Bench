"""Open the delivered file in actual Chrome. Screenshots and the disposable profile stay in TEMP."""
import base64, json, os, subprocess, sys, tempfile, time, uuid
from pathlib import Path
from urllib.request import ProxyHandler, build_opener
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent
TMP=Path(tempfile.gettempdir())
sys.path.insert(0,str(TMP/'orbital-atlas-tools'))
import websocket
CAP=TMP/'glyph-atlas-inspection'
CAP.mkdir(exist_ok=True)
profile=tempfile.mkdtemp(prefix='glyph-atlas-chrome-')
chrome=Path(os.environ['ProgramFiles'])/'Google/Chrome/Application/chrome.exe'
port=18102
class Browser:
    def __init__(self):
        marker='atlas-inspection='+uuid.uuid4().hex
        initial=(ROOT/'index.html').as_uri()+'?'+marker
        self.proc=subprocess.Popen([str(chrome),'--headless=new','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--hide-scrollbars','--disable-sync','--remote-debugging-address=127.0.0.1',f'--remote-debugging-port={port}','--remote-allow-origins=*','--user-data-dir='+profile,'--window-size=1440,900',initial],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        self.address=f'http://127.0.0.1:{port}'; opener=build_opener(ProxyHandler({}))
        for _ in range(120):
            try:
                with opener.open(self.address+'/json/list',timeout=1) as r:tab=next(i for i in json.load(r) if i['type']=='page' and marker in i['url'])
                break
            except Exception:time.sleep(.1)
        else:
            self.proc.terminate();self.proc.wait()
            raise RuntimeError('Chrome did not expose its test tab on the assigned port')
        self.ws=websocket.create_connection(tab['webSocketDebuggerUrl'],timeout=60,suppress_origin=True);self.idx=0;self.errors=[]
        self.call('Page.enable');self.call('Runtime.enable');self.call('Log.enable')
    def call(self,name,params=None):
        self.idx+=1;n=self.idx
        self.ws.send(json.dumps(dict(id=n,method=name,params=params or {})))
        while True:
            m=json.loads(self.ws.recv())
            if m.get('method')=='Runtime.exceptionThrown':self.errors.append(m['params']['exceptionDetails'])
            if m.get('method')=='Log.entryAdded' and m['params']['entry']['level']=='error':self.errors.append(m['params']['entry'])
            if m.get('id')==n:
                if 'error' in m:raise RuntimeError(m['error'])
                return m.get('result',{})
    def js(self,expr):
        res=self.call('Runtime.evaluate',dict(expression=expr,awaitPromise=True,returnByValue=True))
        if 'exceptionDetails' in res:raise RuntimeError(res['exceptionDetails'])
        return res['result'].get('value')
    def resize(self,w,h):
        self.call('Emulation.setDeviceMetricsOverride',dict(width=w,height=h,deviceScaleFactor=1,mobile=False))
    def save(self,name,w=1050):
        cap=self.call('Page.captureScreenshot',dict(format='png',fromSurface=True))
        p=CAP/(name+'.png');p.write_bytes(base64.b64decode(cap['data']))
        im=Image.open(p);im.thumbnail((w,1050));im.save(CAP/(name+'-small.png'));return p
    def open(self):
        self.call('Page.navigate',{'url':(ROOT/'index.html').as_uri()})
        for _ in range(150):
            if self.js("document.readyState==='complete' && !!window.videoExport"):break
            time.sleep(.08)
        return self.js("(async()=>{await document.fonts.ready;await Promise.all(Array.from(document.querySelectorAll('#cards img'),im=>im.decode()));return document.title})()")
    def close(self):
        self.ws.close()
        if self.proc.poll() is None:
            self.proc.terminate()
            self.proc.wait()
if __name__=='__main__':
    b=Browser()
    try:
        b.resize(1440,900);print(b.open(),flush=True)
        b.save('home-1440',1440)
        print('home layout',b.js("({gallery:document.querySelector('.cards').getBoundingClientRect().toJSON(),banner:document.querySelector('.screening').getBoundingClientRect().toJSON(),overflow:document.body.scrollWidth>innerWidth})"))
        b.resize(1920,1080);time.sleep(.2);b.save('home-1920',1280)
        for i in [0,2]:
            b.js(f"document.querySelectorAll('.archive-card')[{i}].click()");time.sleep(.1)
            assert b.js("document.querySelector('.full-art').complete")
            b.js("location.hash='collection'");time.sleep(.1)
        b.js("document.querySelectorAll('.archive-card')[1].click()");time.sleep(.22);b.save('dossier')
        b.js("document.querySelector('[data-variant=planes]').click();document.querySelector('[data-layer=\"2\"]').click()")
        assert b.js("document.querySelector('[data-separation=\"2\"]').style.display")== 'none'
        b.js("document.querySelector('.plane-arrange').click()")
        assert b.js("document.querySelector('.detail-vector').getAttribute('viewBox')")=='0 0 1000 520'
        b.js("document.querySelector('.plane-arrange').click();document.querySelector('.layer-reset').click()")
        assert b.js("document.querySelector('.detail-vector').getBoundingClientRect().width>300")
        b.save('layer-spread')
        b.js("document.querySelector('.layer-reset').click();document.querySelector('[data-variant=mono]').click()");time.sleep(.1)
        assert b.js("document.querySelector('.full-art').src.endsWith('mono.png')")
        b.js("document.querySelector('.detail-caption a').click()");time.sleep(.5)
        print('player',b.js("({value:document.querySelector('#scrub').value,route:location.hash})"))
        b.js("document.querySelector('#toggle-play').click()")
        track=b.js("document.querySelector('#scrub').getBoundingClientRect().toJSON()")
        x0=track['x']+track['width']*.25
        x1=track['x']+track['width']*.75
        middle=track['y']+track['height']/2
        b.call('Input.dispatchMouseEvent',dict(type='mouseMoved',x=x0,y=middle))
        b.call('Input.dispatchMouseEvent',dict(type='mousePressed',x=x0,y=middle,button='left',buttons=1,clickCount=1))
        b.call('Input.dispatchMouseEvent',dict(type='mouseMoved',x=x1,y=middle,button='left',buttons=1))
        b.call('Input.dispatchMouseEvent',dict(type='mouseReleased',x=x1,y=middle,button='left',clickCount=1))
        assert 66 < b.js("Number(document.querySelector('#scrub').value)") < 69
        b.js("let slider=document.querySelector('#scrub');slider.value=46;slider.dispatchEvent(new Event('input'))")
        assert b.js("document.querySelector('#position').value")== '00:46'
        b.save('paused-player')
        b.js("location.hash='collection'");time.sleep(.1)
        assert b.js('window.videoExport.runs.join()')=='show'
        assert b.js("window.videoExport.begin('show',{fps:3})")['frames']==270
        for n in [5,20,28,43,49,63,70,79,88,119,134,169,205,224,257,269]:
            b.js(f'window.videoExport.frame({n})');b.save(f'frame-{n:03}',720)
        # Random access must reproduce the same composed pixels.
        b.js('window.videoExport.frame(43)');first=b.call('Page.captureScreenshot',{'format':'png'})['data']
        b.js('window.videoExport.frame(195)');b.js('window.videoExport.frame(43)');assert b.call('Page.captureScreenshot',{'format':'png'})['data']==first
        b.js('window.videoExport.end()')
        assert not b.js("document.querySelector('#collection').hidden||!document.querySelector('#theater').hidden")
        b.resize(1280,720)
        b.js("window.videoExport.begin('show',{fps:3})")
        result=b.js("(async()=>{for(let i=0;i<270;i++)await window.videoExport.frame(i);return getComputedStyle(document.querySelector('.theater-tools')).display})()")
        assert result=='none'
        b.js('window.videoExport.end()')
        b.resize(3840,2160)
        assert b.js("window.videoExport.begin('show',{fps:60})")['frames']==5400
        b.js('window.videoExport.frame(5399)');b.save('4k-final',960)
        b.js('window.videoExport.end()')
        if (ROOT/'show.mp4').is_file():
            media=b.js("""(async()=>{
              const link=document.querySelector('a[download][href="show.mp4"]');
              const video=document.createElement('video');
              video.muted=true;video.preload='metadata';document.body.append(video);
              try{
                const loaded=new Promise((ok,fail)=>{video.onloadedmetadata=ok;video.onerror=()=>fail(new Error('MP4 decode failed'));});
                video.src=link.href;await loaded;
                const sought=new Promise(ok=>video.onseeked=ok);
                video.currentTime=60.3;await sought;
                await video.play();await new Promise(ok=>setTimeout(ok,200));video.pause();
                return [video.duration,video.videoWidth,video.videoHeight,video.currentTime];
              }finally{video.removeAttribute('src');video.load();video.remove();}
            })()""")
            assert media[:3]==[90,1920,1080] and media[3]>60.3,media
            print('Packaged film playback',media,flush=True)
        print('browser errors',b.errors,flush=True)
        assert not b.errors
    finally:b.close()

