from atelier import *
ROMAN='TrajanPro3-Bold.otf'
def engrave(ch,i,ty,part,pts,w,p):
    a,b=pts[0],pts[-1]
    if ty=='横':
        # Cut each triangular serif down to a point, then draw out the rail.
        body=G.map_points(p,lambda x,y:(x+(max(0,x-b[0]+8)/10)**1.6*1.4,y+(y-b[1])*(-.09)))
        return G.union(body,G.polygon([(b[0]-7,b[1]-.7),(b[0]+4.2,b[1]-.45),(b[0]+7.6,b[1]+.05),(b[0]-7,b[1]+1.25)]))
    if ty in ('竖','钩','折'):
        return G.map_points(p,lambda x,y:(x+.8*(y/100)**1.6-.4, y+.55*math.sin(x*.04)))
    if ty=='点':
        d=b-a;d/=np.linalg.norm(d);n=np.array([-d[1],d[0]])
        mid=a*.45+b*.55
        return G.polygon([a-d*w*.22,mid-n*w*.54,b+d*w*.19,mid+n*w*.44])
    if ty in ('撇','捺','提'):
        d=pts[-1]-pts[-2];d/=np.linalg.norm(d)
        length=9.5 if (ch=='道' and ty=='捺') else 3.8
        return G.union(p,G.taper(tuple(b-d*6),tuple(b+d*length),w*.52,.16))
    return p
def needle(ch,i,p):
    if (ch,i)!=('穹',0):return None
    needle=G.polygon([(33.5,-11),(49,2.2),(52,6.8),(59.2,20),(45.5,11),(42,7)])
    return needle,(46.5,6),needle
def etch(ch,i,ty,part,pts,w,p):
    if ty!='点' or (ch=='穹' and i==0):return None
    b,a=pts[-1],pts[0];d=b-a;d/=np.linalg.norm(d)
    return G.union(p,G.taper(tuple(b-d*w*.35),tuple(b+d*w*.6),w*.49,.10))
def ellipse_arc(cx,cy,rx,ry,rot,lo,hi,n=160):
    a=np.linspace(math.radians(lo),math.radians(hi),n);rt=math.radians(rot)
    x=rx*np.cos(a);y=ry*np.sin(a)
    return dline(zip(cx+x*math.cos(rt)-y*math.sin(rt),cy+x*math.sin(rt)+y*math.cos(rt)))
def instrument(cx,cy):
    s='';brass='url(#brass)'
    def ring(r,col,w,more=''):
        return circle(cx,cy,r,'none',f'stroke="{col}" stroke-width="{w}" {more}')
    # Astrolabe mater with engraved limb and suspended crown.
    s+=circle(cx,cy-116,7,'none','stroke="#cab28c" stroke-width="2.4"')
    s+=tagpath(dline([(cx-11,cy-106),(cx-2,cy-117),(cx+2,cy-117),(cx+12,cy-105)],True),'#9e825c')
    s+=ring(106,'#403348',8)+ring(110,brass,2)+ring(103,brass,2.8)+ring(95,'#ad9579',.85)
    s+=ring(78,'#9a7f71',1.4)
    for j in range(120):
        a=math.radians(j*3-90);r0=102 if j%5 else 95
        if j%10==0:r0=91
        s+=line(dline([(cx+math.cos(a)*r0,cy+math.sin(a)*r0),(cx+math.cos(a)*106,cy+math.sin(a)*106)]),'#d0b992',1.7 if j%5==0 else .8,.9)
    for j,t in enumerate(['XII','III','VI','IX']):
        a=(j-1)*math.pi/2
        s+=ink(t,ROMAN,10,cx+math.cos(a)*85,cy+math.sin(a)*85+3,.025,'#d0bb98','center')
    s+=line(ellipse_arc(cx,cy,97,38,-39,0,360),'#927b6e',1.8)
    s+=line(ellipse_arc(cx,cy,87,44,51,0,360),'#bb9a76',1.4)
    s+=line(ellipse_arc(cx,cy,92,88,-35,193,337),'#ead2a8',2.8)
    s+=line(dline([(cx-92,cy+47),(cx+84,cy-43)]),'#a78d71',2.1)
    s+=line(dline([(cx-49,cy-94),(cx+50,cy+94)]),'#d6c19c',.9)
    for a,r in [(15,109),(136,109),(221,103),(282,78)]:
        ax=cx+math.cos(math.radians(a))*r;ay=cy+math.sin(math.radians(a))*r
        s+=circle(ax,ay,3.6,'#d7c39e')+circle(ax-.8,ay-.8,1.2,'#fbebc6')
    return s
def build():
    layout={'星':(55,177,195,188,.022),'穹':(281,141,213,222,.022),'铁':(512,173,191,181,.022),'道':(715,151,206,196,.022),
            '崩':(573,107,38,38,.022),'坏':(621,108,40,37,.022)}
    glyph,base,strokeset,tip,focus,echo,proof=make_glyphs(1,layout,engrave,needle,etch)
    main=G.union([p for ch,p in glyph.items() if ch!='穹']);sig=glyph['穹']
    defs=pigment(1)+grad('brass',[(0,'#84694d'),(.22,'#dac198'),(.36,'#fff3c7'),(.5,'#aa8654'),(.83,'#d8b781'),(1,'#967349')],0,.1,.9,1)
    # The backplate is a chipped piece of enamel. Its outline and its
    # engraved declination circles are generated in the same coordinate space.
    rng=random.Random(74);boundary=[]
    for j in range(550):
        a=math.tau*j/550
        grain=1+.022*math.sin(9*a)+.014*math.cos(17*a)+.008*math.sin(37*a)+rng.uniform(-.008,.008)
        xx=math.cos(a)*466*grain
        boundary.append((503+xx,274+math.sin(a)*133*grain-.046*xx))
    outline=dline(boundary,True)
    defs+='<clipPath id="enamel"><path d="'+outline+'"/></clipPath>'
    defs+=grad('glaze',[(0,'#3b3047'),(.36,'#312a43'),(.64,'#242136'),(1,'#382c41')],0,0,.88,1)
    plate=tagpath(outline,'url(#glaze)')
    inscribe=''
    for r in (150,197,275,355):
        inscribe+=circle(focus[0],focus[1],r,'none','stroke="#8b7790" stroke-width="0.9" opacity=".31"')
    for j in range(900):
        x,y=rng.uniform(30,970),rng.uniform(125,418)
        inscribe+=circle(x,y,rng.uniform(.22,1.35),'#bbabad',f'opacity="{rng.uniform(.06,.37):.2f}"')
    plate+='<g clip-path="url(#enamel)">'+inscribe+'</g>'
    for j in range(680):
        x,y=boundary[rng.randrange(len(boundary))];size=rng.uniform(.4,2)
        plate+=circle(x+rng.gauss(0,4.3),y+rng.gauss(0,2.7),size,rng.choice(['#332c42','#3e3149','#282135']),f'opacity="{rng.uniform(.25,.9):.2f}"')
    plate+=tagpath('M153 371Q375 394 546 370T882 345Q858 379 806 403Q625 423 341 416L218 419Z','#2e263e','opacity=".92"')
    # A route passes behind the dial, sweeps under the name and rises into open space.
    lines=line('M21 396C156 399 310 390 424 373M41 401Q218 402 340 385','#c4ad89',1.5)
    lines+=line('M536 373C755 379 898 340 943 281C971 241 940 202 891 196','#ba9c79',1.3)
    lines+=line('M540 377C767 384 910 335 945 288','#cbb194',.7)
    lines+=line('M514 125H561M676 128H774L818 100H869','#c3aa88',1.1)
    lines+=dashed_lozenge(875,100,5.1,'#cfb790')+dashed_lozenge(508,125,3,'#e5d6b4')
    for x,y,sz in [(66,155,9),(883,128,8),(962,245,6),(107,375,4.5),(237,123,4.7),(488,91,4)]:lines+=spark(x,y,sz,'#c7b697')
    # Small star positions speak the same pointed dialect as the engravings.
    rng=random.Random(135)
    for _ in range(65):
        x=rng.uniform(67,931);y=rng.uniform(133,388)
        lines+=circle(x,y,rng.uniform(.35,1.2),'#dfcba7','opacity=".62"')
    back=ink('R',ROMAN,348,352,374,-.02,'#42374c','center')
    lower=baseline_lettering('HONKAI: STAR RAIL','CormorantGaramond-SemiBold.ttf',37,524,410,.28,'#e3d3bb','#302638')
    lower+=line('M134 404H256M792 404H847','#bca187',1.6)+dashed_lozenge(131,404,3.4,'#d4ba94')+dashed_lozenge(851,404,3.4,'#d4ba94')
    # Half of the needle is dark brass: the facet stays attached to the point.
    cx,cy=focus
    highlights=tagpath(tip,'url(#brass)')
    highlights+=tagpath(G.inter(tip,G.polygon([(cx-80,cy-93),(cx-1,cy),(cx+76,cy+87),(cx+89,cy-99)])),'#f7da90')
    highlights+=circle(cx,cy,4.1,'#79674e')+circle(cx-1,cy-.9,2.8,'#ffedb6')+spark(cx-26,cy-31,7,'#fff0c4')
    highlights+=spark(660,127,4.3,'#e9d4aa')+spark(919,328,5,'#fff0d6')
    layers=[plate,back,instrument(cx,cy),lines,cast(main,1),cast(sig,1),lower,highlights]
    write_edition(1,defs,layers,strokeset,dict(focus=focus,echoes=echo,guide=[151,264,362,410],mainName='星穹铁道',signature='穹',subject='测星盘',finish='珐琅镀银',detail='双尖盘针',accent='#e7c583',monoMain=tagpath(main,'#eee'),monoSign=tagpath(sig,'#f4f4f4')),proof)
if __name__=='__main__':build()

