(() => {
  'use strict';
  const $=sel=>document.querySelector(sel);
  const icon=(name,cls='')=>'<svg class="'+cls+'" aria-hidden="true"><use href="#'+name+'"/></svg>';
  const works=[
    {name:'明日方舟：终末地',en:'Arknights: Endfield',world:'TALOS-II',genre:'工业拓荒',material:'切削钢面',mark:'industrial',colors:['#d9dfd1','#799291','#dbb463'],mood:'冷峻、坚实、进取',concept:'取芯钻切入塔卫二的地层，支撑钻头的每一块钢梁都成为一个笔画。'},
    {name:'崩坏：星穹铁道',en:'Honkai: Star Rail',world:'ASTRAL EXPRESS',genre:'星海远旅',material:'珐琅镀银',mark:'astrolabe',colors:['#e6d2b4','#89809a','#615372'],mood:'瑰丽、精密、悠远',concept:'用测星盘瞄准下一站，盘针在天穹上刻下列车经过的金轨。'},
    {name:'鸣潮',en:'Wuthering Waves',world:'SOLARIS-3',genre:'潮汐共振',material:'矿物水墨',mark:'wave',colors:['#d2eee0','#7bbdae','#2f6d70'],mood:'空灵、凌厉、流动',concept:'共鸣穿过水面，最后一笔翻起潮峰，振动在退潮处留下两股细流。'}
  ];
  const swatches=w=>'<span class="swatches" aria-hidden="true">'+w.colors.map(c=>'<i style="background:'+c+'"></i>').join('')+'</span>';
  const fileNo=i=>String(i+1).padStart(3,'0');
  const folder=i=>'assets/'+chapterSlugs[i]+'/';
  const printed=i=>'logos/'+window.editions[i].mainName+'/';
  $('#cards').innerHTML=works.map((w,i)=>
    '<a class="archive-card" data-n="'+i+'" href="#work/'+chapterSlugs[i]+'" style="--tint:'+w.colors[0]+'" aria-label="查看'+w.name+'的设计档案">'+
      '<div class="card-art"><img class="world-img" src="'+folder(i)+'world.jpg" alt=""><div class="art-wash"></div>'+
      '<div class="catalog-code">FILE '+fileNo(i)+'</div>'+icon(w.mark,'sigil')+
      '<img class="card-logo" src="'+folder(i)+'logo.svg" alt="'+w.name+'艺术字">'+
      '<div class="card-register" aria-hidden="true"><span>'+w.world+'</span><i></i></div></div>'+
      '<div class="card-info"><h3>'+w.name+'</h3><div class="game-english" lang="en">'+w.en+'</div><span class="round-arrow">'+icon('arrow-up')+'</span>'+
      '<div class="material-line">'+swatches(w)+'<span>'+w.genre+'</span><span class="divider">/</span><span>'+w.material+'</span></div></div></a>'
  ).join('');
  const ids=['底板','背景巨字','主体元素','细线与刻度','主字与系列名','签名字','英文','星芒与高光'];
  let route='collection',activeWork=0,variant='scene',filmReturn='#collection';
  let showing=Array(8).fill(true),separate=true;
  function setVariant(name){
    variant=name;
    const stage=$('.detail-canvas'),a=window.editions[activeWork];
    stage.className='detail-canvas '+({scene:'',mono:'proof',planes:'separated'}[name]);
    const image=stage.querySelector('.full-art'),vector=stage.querySelector('.detail-vector');
    image.hidden=name==='planes';vector.toggleAttribute('hidden',name!=='planes');
    image.src=name==='mono'?printed(activeWork)+'mono.png':folder(activeWork)+'logo.svg';
    image.alt=works[activeWork].name+(name==='mono'?'黑白校样':'场景字标');
    $('.separations').hidden=name!=='planes';
    if(name==='planes'){
      if(!vector.hasChildNodes()){
        const scoped=('<defs>'+a.defs+'</defs>'+a.layers.map((s,i)=>'<g data-separation="'+i+'">'+s+'</g>').join('')).replaceAll('id="','id="detail-').replaceAll('url(#','url(#detail-');
        vector.innerHTML=scoped;
        const labels=svgEl('g',{'data-plane-key':'','font-size':18,'font-family':'Microsoft YaHei, sans-serif',fill:'#d7d0df'});
        labels.innerHTML=ids.map((title,i)=>{
          const y=260-(i-3.5)*63;
          const label=i===2?a.subject:i===5?'签名 · '+a.signature:title;
          return '<g data-plane-label="'+i+'"><path d="M'+(815+(i-3.5)*10)+' '+y+'h70l12 -6H1008" stroke="#8b8196" stroke-width="1.2" fill="none"/><circle cx="1011" cy="'+(y-6)+'" r="2.9" fill="'+a.accent+'"/><text x="1024" y="'+y+'">'+label+'</text></g>';
        }).join('');
        vector.append(labels);
      }
      vector.setAttribute('viewBox',separate?'-45 -40 1230 615':'0 0 1000 520');
      vector.querySelector('[data-plane-key]').style.display=separate?'':'none';
      vector.querySelectorAll('[data-separation]').forEach((g,i)=>{
        g.style.display=showing[i]?'':'none';
        const k=i-3.5;
        g.setAttribute('transform',separate?'translate('+(k*14)+' '+(-k*63)+') translate(500 260) rotate(-4) scale(.92 .27) translate(-500 -260)':'translate(0 0)');
        vector.querySelector('[data-plane-label="'+i+'"]').setAttribute('opacity',showing[i]?1:.24);
      });
      $('.plane-arrange').textContent=separate?'叠合预览':'分层展开';
    }
    $('#dossier').querySelectorAll('[data-variant]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.variant===name)));
    $('#dossier').querySelectorAll('[data-layer]').forEach((b,i)=>{
      b.setAttribute('aria-pressed',String(showing[i]));
      b.querySelector('.tick').textContent=showing[i]?'✓':'';
    });
  }
  function dossier(i){
    activeWork=i; const w=works[i],a=window.editions[i];showing.fill(true);separate=true;
    $('#dossier').innerHTML=
      '<div class="detail-head"><a href="#collection" class="text-link">'+icon('arrow-left')+'返回馆藏</a><div class="nextprev"><a class="neighbor" href="#work/'+chapterSlugs[(i+2)%3]+'" aria-label="上一枚作品">'+icon('arrow-left')+'</a><span>FILE '+fileNo(i)+' / 003</span><a class="neighbor" href="#work/'+chapterSlugs[(i+1)%3]+'" aria-label="下一枚作品">'+icon('arrow-right')+'</a></div></div>'+
      '<section class="detail-viewer" style="--tint:'+w.colors[0]+'" aria-label="字标原件与校样">'+
      '<div class="detail-canvas"><img class="world-img" src="'+folder(i)+'world.jpg" alt=""><div class="art-wash"></div><img class="full-art" src="'+folder(i)+'logo.svg" alt="'+w.name+'"><svg class="detail-vector" viewBox="0 0 1000 520" role="img" aria-label="可分层的'+w.name+'字标" hidden></svg><span class="viewer-reg"></span><span class="catalog-code">FILE '+fileNo(i)+'</span></div>'+
      '<div class="detail-actionbar"><div class="view-tabs" role="group" aria-label="原件视图">'+[['scene','场景原画'],['mono','黑白校样'],['planes','图层拆解']].map(([v,l])=>'<button data-variant="'+v+'" aria-pressed="false">'+l+'</button>').join('')+'</div>'+
      '<a class="text-link" href="'+printed(i)+'final.png" download="'+a.mainName+'-透明原图.png">'+icon('download')+'下载透明原图</a></div>'+
      '<div class="separations" hidden role="group" aria-label="显示或隐藏图层">'+ids.map((l,k)=>'<button data-layer="'+k+'" aria-pressed="true"><span class="tick">✓</span>'+(k===2?a.subject:l)+'</button>').join('')+'<button class="layer-reset">全部显示</button><button class="plane-arrange">叠合预览</button></div></section>'+
      '<div class="detail-caption"><div><div class="detail-eyebrow" lang="en">'+w.en.toUpperCase()+'</div><h1>'+w.name+'</h1><p>'+w.concept+'</p></div><a class="primary" href="#show/'+chapterSlugs[i]+'">'+icon('play')+'播放本卷</a></div>'+
      '<div class="dossier-specs"><div><small>字面材质</small>'+w.material+'</div><div><small>母题落点</small>「'+a.signature+'」 · '+a.detail+'</div><div><small>主色谱</small>'+swatches(w)+'</div></div>';
    setVariant('scene');
  }
  $('#dossier').addEventListener('click',e=>{
    const b=e.target.closest('button');
    if(!b)return;
    if(b.dataset.variant)setVariant(b.dataset.variant);
    else if(b.dataset.layer!==undefined){const i=Number(b.dataset.layer);showing[i]=!showing[i];setVariant('planes');}
    else if(b.classList.contains('layer-reset')){showing.fill(true);setVariant('planes');}
    else if(b.classList.contains('plane-arrange')){separate=!separate;setVariant('planes');}
  });
  let projector=null,playing=false,playhead=0,epoch=0,request=0,quietTimer=0,exportMode=false,rate=60,saved=null;
  function stage(){if(!projector)projector=new FilmStage($('#projection'));return projector;}
  const stamp=t=>Math.floor(t/60).toString().padStart(2,'0')+':'+Math.floor(t%60).toString().padStart(2,'0');
  function frameAt(t){
    playhead=Math.min(90,Math.max(0,t));stage().render(playhead);
    if(exportMode)return;
    $('#scrub').value=playhead;
    $('#scrub').style.setProperty('--playhead',(playhead/90*100).toFixed(2)+'%');
    $('#position').value=stamp(playhead);
    document.querySelectorAll('[data-chapter]').forEach((el,i)=>el.classList.toggle('on',i===Math.min(2,Math.floor(playhead/30))));
  }
  function playIcon(){
    const b=$('#toggle-play');b.innerHTML=icon(playing?'pause':'play');
    b.setAttribute('aria-label',playing?'暂停':'播放');b.title=playing?'暂停（空格）':'播放（空格）';
  }
  function stop(){
    if(playing&&!exportMode)playhead=Math.min(90,(performance.now()-epoch)/1000);
    playing=false;cancelAnimationFrame(request);playIcon();
  }
  function step(now){
    if(!playing||exportMode)return;
    frameAt((now-epoch)/1000);
    if(playhead>=90){stop();revealControls();return;}
    request=requestAnimationFrame(step);
  }
  function start(){
    if(exportMode)return;
    if(playhead>=89.999)frameAt(0);
    cancelAnimationFrame(request);epoch=performance.now()-playhead*1000;playing=true;playIcon();request=requestAnimationFrame(step);revealControls();
  }
  function seek(t){frameAt(t);epoch=performance.now()-playhead*1000;revealControls();}
  function toggle(){if(playing){stop();frameAt(playhead);revealControls();}else start();}
  function revealControls(){
    if(exportMode)return;
    const tools=$('.theater-tools');tools.classList.remove('quiet');clearTimeout(quietTimer);
    if(playing)quietTimer=setTimeout(()=>tools.classList.add('quiet'),2400);
  }
  function handleRoute(autoPlay=true){
    if(exportMode)return;
    const parts=location.hash.slice(1).split('/'),selected=chapterSlugs.indexOf(parts[1]);
    const next=parts[0]==='work'&&selected!==-1?'work':parts[0]==='show'?'show':'collection';
    if(next==='show'&&route!=='show')filmReturn=route==='work'?'#work/'+chapterSlugs[activeWork]:'#collection';
    stop();route=next;
    $('#collection').hidden=route!=='collection';$('#dossier').hidden=route!=='work';$('#theater').hidden=route!=='show';
    document.body.classList.toggle('in-theater',route==='show');
    $('#nav-collection').classList.toggle('active',route!=='show');$('#nav-film').classList.toggle('active',route==='show');
    if(route==='work'){dossier(selected);document.title=works[selected].name+' · 字形档案馆';}
    else if(route==='show'){
      document.title='字形构造展映 · GLYPH ATLAS';
      $('.theater-back').innerHTML=icon('arrow-left')+(filmReturn==='#collection'?'返回馆藏':'返回作品');
      frameAt(Math.max(0,selected)*30);if(autoPlay)start();else revealControls();
    }else document.title='异世字形图鉴 · GLYPH ATLAS';
    window.scrollTo({top:0,behavior:'instant'});
  }
  window.addEventListener('hashchange',()=>handleRoute());
  $('.chapter-links').innerHTML=works.map((w,i)=>'<button data-chapter="'+i+'"><b>0'+(i+1)+'</b> '+window.editions[i].mainName+'</button>').join('');
  $('.chapter-links').addEventListener('click',e=>{const b=e.target.closest('button');if(b)seek(Number(b.dataset.chapter)*30);});
  $('#toggle-play').addEventListener('click',toggle);
  $('#projection').addEventListener('click',toggle);
  $('#theater').addEventListener('pointermove',revealControls);
  $('#scrub').addEventListener('input',e=>seek(Number(e.target.value)));
  $('.theater-back').addEventListener('click',()=>location.hash=filmReturn);
  document.querySelectorAll('.full-toggle').forEach(el=>el.addEventListener('click',async()=>{
    try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}
    catch{el.title='当前窗口已使用全部显示区域';}
  }));
  document.addEventListener('fullscreenchange',()=>{
    for(const b of document.querySelectorAll('.full-toggle')){
      b.innerHTML=icon(document.fullscreenElement?'collapse':'expand');
      b.title=document.fullscreenElement?'退出全屏':'进入全屏';b.setAttribute('aria-label',b.title);
    }
  });
  document.addEventListener('keydown',e=>{
    if(exportMode)return;
    if(e.key==='Escape'&&route!=='collection'){location.hash=route==='show'?filmReturn:'#collection';return;}
    if(route!=='show')return;
    if(e.code==='Space'){e.preventDefault();toggle();}
    if(e.code==='ArrowRight'||e.code==='ArrowLeft'){e.preventDefault();seek(playhead+(e.code==='ArrowRight'?5:-5));}
  });
  const painted=()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
  window.videoExport={
    runs:['show'],
    async begin(run,{fps=60}={}){
      if(run!=='show')throw new RangeError('未知展映');
      if(!(fps===3||fps===60))throw new RangeError('帧率应为 3 或 60');
      if(!exportMode){
        const wasPlaying=playing;stop();
        saved={route,playhead,playing:wasPlaying,scroll:window.scrollY,hash:location.hash};
      }
      exportMode=true;rate=fps;clearTimeout(quietTimer);document.body.classList.add('exporting','in-theater');$('#theater').hidden=false;
      await Promise.all([stage().ready(),document.fonts.ready]);
      frameAt(0);await painted();return {frames:90*rate};
    },
    async frame(i){
      if(!exportMode||!Number.isInteger(i)||i<0||i>=90*rate)throw new RangeError('帧号超出当前展映范围');
      frameAt(i/rate);await painted();
    },
    end(){
      if(!exportMode)return;
      exportMode=false;document.body.classList.remove('exporting');
      if(location.hash!==saved.hash){handleRoute(false);return;}
      $('#theater').hidden=saved.route!=='show';
      document.body.classList.toggle('in-theater',saved.route==='show');
      if(saved.route==='show'){frameAt(saved.playhead);if(saved.playing)start();else revealControls();}
      window.scrollTo({top:saved.scroll,behavior:'instant'});saved=null;
    }
  };
  handleRoute();
})();
