/* Every visual operation below is a function of the requested film time. */
const chapterSlugs = ['endfield','astral','tides'];
const motionText = [
  ['立起井架，让钢梁依次落位。','卸下钢面，显出原字骨架。','横梁端面铣成同向的斜口。','立柱加厚，折件接入同一条轴线。','把点与斜撑铸成短钢楔。','拉长「末」的中竖，切出钻头的排屑槽。','横梁端头依次切出浅槽。','将英文铭牌对准钻肩下方。','以石墨、冷银和硫黄分三次着色。','沿装配轴展开八层，再合拢。'],
  ['转动星盘，让月白的字面落到轨线上。','褪去镀层，复原宋体的骨架。','把横末延成星图上的细刻线。','收紧转角，让竖笔稳住刻线。','将点与撇捺的尖端磨薄。','把「穹」的穴头一点锻成双尖盘针。','同族点锋沿航路依次亮起。','令罗马大写贴住航迹的下缘。','先铺靛紫珐琅，再镀月白与暖金。','将星图的八层版片展开，再叠合。'],
  ['潮峰卷起，墨线沿波脊洇开。','收回余波，显出手书的提按。','顺着水势把横末牵成细锋。','让竖折轻弯，保持字内的透气。','把点尖凝成顺流的水滴。','从「潮」的月钩牵出两股回浪。','让水点和鸟钩带上微弱的回流。','把疏排英文托在退潮水线上。','沿波脊依次染入墨绿、银白与翡翠青。','沿波面展开八层水痕，再收拢。']
];
const SVGNS = 'http://www.w3.org/2000/svg';
const colorStarts=[21.3,21.55,21.35,21.72,21.95,22.1,22.25,24.15];
const colorEnds=[22.18,22.37,22.23,22.53,23.04,23.25,23.23,24.38];
const bounded = v => Math.max(0, Math.min(1, v));
function smooth(a,b,x) { const p = bounded((x-a)/(b-a)); return p*p*(3-2*p); }
function svgEl(tag, attrs={}) {
  const node=document.createElementNS(SVGNS,tag);
  for (const [key,value] of Object.entries(attrs)) node.setAttribute(key,value);
  return node;
}
function interpolateContours(pairs,t) {
  let d='';
  for(const [from,to] of pairs){
    for(let i=0;i<from.length;i+=2){
      const x=from[i]+(to[i]-from[i])*t, y=from[i+1]+(to[i+1]-from[i+1])*t;
      d+=(i?'L':'M')+x.toFixed(2)+' '+y.toFixed(2);
    }
    d+='Z';
  }
  return d;
}
class FilmStage {
  constructor(host) {
    this.host=host;
    this.scene=-1;
    this.sky=document.createElement('div');
    this.sky.className='projection-world';
    this.lab=document.createElement('div');
    this.lab.className='projection-lab';
    this.svg=svgEl('svg',{viewBox:'0 0 1600 900',class:'projection-art','aria-hidden':'true'});
    this.caption=document.createElement('div');
    this.caption.className='projection-caption';
    host.replaceChildren(this.sky,this.lab,this.svg,this.caption);
    this.backgrounds=chapterSlugs.map(slug=>{
      const img=new Image();
      img.alt='';
      img.src='assets/'+slug+'/world.jpg';
      this.sky.append(img);
      return img;
    });
    this.materials=window.editions.map(edition=>{
      const image=new Image();
      image.src=edition.defs.match(/href="(data:image\/jpeg;base64,[^"]+)"/)[1];
      return image;
    });
  }
  mount(n) {
    this.scene=n;this.data=window.editions[n];const a=this.data;
    this.backgrounds.forEach((im,i)=>im.hidden=i!==n);
    const inkFilters=a.inkTones.map((stops,i)=>{
      const values=stops.map(value=>(value/255).toFixed(6)).join(' ');
      const channels=['R','G','B'].map(channel=>'<feFunc'+channel+' type="discrete" tableValues="'+values+'"/>').join('');
      return '<filter id="ink-'+i+'" color-interpolation-filters="sRGB">'+
        '<feColorMatrix type="matrix" values=".299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 0 0 0 1 0"/>'+
        '<feComponentTransfer result="print">'+channels+'</feComponentTransfer>'+
        '<feComposite in="SourceGraphic" in2="print" operator="arithmetic" k2="0" k3="1"/></filter>';
    }).join('');
    this.svg.innerHTML='<defs>'+a.defs+inkFilters+
      '<linearGradient id="sweepLight"><stop stop-color="#fff" stop-opacity="0"/><stop offset=".48" stop-color="#fff" stop-opacity=".13"/><stop offset=".77" stop-color="#fff" stop-opacity=".75"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>'+
      '<clipPath id="scanClip"><path d="'+a.strokes.map(st=>st.c||st.b).join('')+'"/></clipPath>'+
      '<clipPath id="plateIn"><rect x="-35" y="-20" height="565" width="1110"/></clipPath>'+
      '<clipPath id="guideInk"><rect x="-100" y="-75" height="680" width="1230"/></clipPath>'+
      '<clipPath id="faceIn"><path/></clipPath>'+
      '<clipPath id="accentIn"><circle cx="'+a.focus[0]+'" cy="'+a.focus[1]+'" r="1300"/></clipPath></defs>';
    this.plateMask=this.svg.querySelector('#plateIn rect');
    this.accentMask=this.svg.querySelector('#accentIn circle');
    this.guideMask=this.svg.querySelector('#guideInk rect');
    this.typeMask=this.svg.querySelector('#faceIn path');
    this.inkBlends=Array.from(this.svg.querySelectorAll('feComposite'));
    this.root=svgEl('g');
    this.svg.append(this.root);
    this.guides=svgEl('g',{fill:'none',stroke:'#a7bac8','stroke-width':1,'clip-path':'url(#guideInk)'});
    this.root.append(this.guides);
    a.guide.forEach((y,i)=>{
      const path=svgEl('path',{d:'M-65 '+y+'H1065','stroke-dasharray':'5 7',opacity:i===3?.85:.5});
      this.guides.append(path);
      for(const x of [18,982])this.guides.append(svgEl('path',{d:'M'+x+' '+(y-6)+'v12m-6 -6h12'}));
    });
    for(const x of [54,350,626,910]){
      const p=svgEl('path',{d:'M'+x+' 462l'+(n===0?44:n===1?85:68)+' -418','stroke-dasharray':'3 8',opacity:'.42'});
      this.guides.append(p);
    }
    this.layers=a.layers.map((str,i)=>{
      const g=svgEl('g',{'data-plane':i});
      g.innerHTML=i===7?'<g id="motif-pigment">'+str+'</g>':str;
      this.root.append(g);return g;
    });
    this.layers[0].setAttribute('clip-path','url(#plateIn)');
    this.layers[4].setAttribute('clip-path','url(#faceIn)');
    this.layers[5].setAttribute('clip-path','url(#faceIn)');
    this.colorBloom=svgEl('use',{href:'#motif-pigment','clip-path':'url(#accentIn)'});
    this.root.append(this.colorBloom);
    this.morph=svgEl('g');
    this.root.insertBefore(this.morph,this.layers[4]);
    this.penPaths=a.strokes.map(s=>{
      const p=svgEl('path');this.morph.append(p);return p;
    });
    let echoIndex=0;
    this.echoIndices=a.strokes.map(s=>s.special==='echo'?echoIndex++:-1);
    this.scan=svgEl('g',{'clip-path':'url(#scanClip)'});
    this.ray=svgEl('path',{d:'M-90 -40H-12L220 560H142Z',fill:'url(#sweepLight)'});
    this.scan.append(this.ray);this.root.append(this.scan);
    this.callout=svgEl('g',{fill:'none',stroke:a.accent,'stroke-width':1.3});
    this.root.append(this.callout);
    this.notes=svgEl('g',{class:'plane-notes','font-size':15,fill:'#eae7f2','font-family':'Microsoft YaHei, sans-serif'});
    this.root.append(this.notes);
    this.layerLabels=['底板','背景巨字',a.subject,'细线与刻度','主字与系列名','签名 · '+a.signature,'英文','星芒与高光'];
    this.notes.innerHTML=this.layerLabels.map((l,i)=>{
      const y=260-(i-3.5)*62;
      return '<path d="M'+(860+(i-3.5)*10)+' '+y+'h60l12 -7H1068" stroke="#c4b8d9" fill="none" stroke-width=".9"/><circle cx="1070" cy="'+(y-7)+'" r="2.5"/><text x="1083" y="'+(y-1)+'">'+l+'</text>';
    }).join('');
  }
  render(totalTime) {
    const n=Math.min(2,Math.floor(Math.max(0,totalTime)/30)), t=Math.max(0,Math.min(30,totalTime-n*30));
    if(this.scene!==n)this.mount(n);
    const a=this.data;
    const echoStart=i=>15.65+1.13*i/Math.max(1,a.echoes.length-1);
    const off=smooth(4,5.65,t);
    const rebuild=smooth(17.7,20.1,t);
    const lab=off*(1-smooth(21.6,24.3,t))+.62*smooth(24.4,25.6,t)*(1-smooth(27.15,28.65,t));
    this.lab.style.opacity=lab;
    this.sky.style.transform='scale('+(1.015+.035*(t/30))+')';
    this.guides.setAttribute('opacity',.67*smooth(4.7,6.1,t)*(1-smooth(20.1,21.05,t)));
    this.guideMask.setAttribute('width',1220*smooth(4.66,6.75,t));
    const edge=-170+1440*smooth(.48,2.48,t);
    const nib=n===0?'L'+(edge-102)+' 550':n===1?'Q'+(edge+125)+' 221 '+(edge-35)+' 550':'C'+(edge-113)+' 161 '+(edge+85)+' 293 '+(edge-52)+' 550';
    this.typeMask.setAttribute('d','M-170 -40H'+edge+nib+'H-170Z');
    const near=smooth(12.8,14.15,t)*(1-smooth(15.5,17.2,t));
    const exp=smooth(24.4,25.8,t)*(1-smooth(27.1,28.55,t));
    const scale=1.10+near*.69-exp*.13;
    const cx=500+(a.focus[0]-500)*near,cy=260+(a.focus[1]-260)*near;
    this.root.setAttribute('transform','translate('+(800-exp*109)+' '+(438+exp*6)+') scale('+scale+') translate('+(-cx)+' '+(-cy)+')');
    const gray=smooth(3.8,5.5,t);
    const mVisible=t>4.65 && t<20.35;
    this.morph.style.display=mVisible?'':'none';
    this.morph.setAttribute('opacity',smooth(4.65,5.35,t)*(1-smooth(19.6,20.35,t)));
    for(let i=0;i<8;i++){
      const g=this.layers[i];
      let intro=smooth(i*.16-.22,i*.16+1.35,t);
      if(i===2)intro=smooth(.18,2.15,t);
      const back=smooth(17.45+i*.155,19.0+i*.19,t);
      let opacity=intro*(1-off)+back;
      if(i===4||i===5)opacity=intro*(1-smooth(4.7,5.35,t))+smooth(19.6,20.35,t);
      if(i===7)opacity=intro*(1-off)+smooth(19.65,20.35,t);
      if(i===0)this.plateMask.setAttribute('width',1120*Math.max(intro,rebuild));
      const mono=gray*(1-smooth(colorStarts[i],colorEnds[i],t));
      const mix=this.inkBlends[i];
      if(mono>.001&&opacity>.001){
        mix.setAttribute('k2',(1-mono).toFixed(4));mix.setAttribute('k3',mono.toFixed(4));
        g.setAttribute('filter','url(#ink-'+i+')');
      }else g.removeAttribute('filter');
      g.setAttribute('opacity',Math.min(1,opacity).toFixed(3));
      let x=(1-intro)*(i%2?35:-62),y=(1-intro)*(i===2?-58:i===5?-23:16);
      if(t<7&&i!==4&&i!==5){x+=off*(i%2?18:-26);y+=off*(i===2?-20:6);}
      if(t>16&&i!==4&&i!==5){x+=(1-back)*(i%2?43:-43);y+=(1-back)*(i===2?-35:9);}
      x+=(i-3.5)*15*exp;y-=(i-3.5)*62*exp;
      const rot=(!n||i!==2?0:n===1?-51:12)*(1-Math.max(intro,back));
      g.setAttribute('transform','translate('+x.toFixed(2)+' '+y.toFixed(2)+') translate(500 260) rotate('+(-5.2*exp).toFixed(2)+') scale(1 '+(1-.70*exp).toFixed(4)+') translate(-500 -260)'+(rot?' rotate('+rot+' '+a.focus.join(' ')+')':''));
    }
    this.accentMask.setAttribute('r',1300*smooth(23.15,24.28,t));
    this.colorBloom.setAttribute('opacity',smooth(23.15,23.32,t)*(1-smooth(24.38,24.45,t)));
    this.colorBloom.setAttribute('transform',this.layers[7].getAttribute('transform'));
    if(mVisible){
      for(let i=0;i<a.strokes.length;i++){
        const s=a.strokes[i],p=this.penPaths[i];
        let baseProgress=1-smooth(5.75,6.82,t);
        if(t>6.82)baseProgress=smooth(7.08+s.phase*1.86,8.60+s.phase*1.86,t);
        let extra=1-smooth(5.25,5.75,t);
        const echoAt=echoStart(this.echoIndices[i]);
        if(t>7)extra=s.special==='focus'?smooth(13.55,15.4,t):smooth(echoAt,echoAt+.62,t);
        let d;
        if(s.special&&extra>.001)d=extra>.999?s.c:interpolateContours(s.ext,extra);
        else d=baseProgress<.001?s.a:baseProgress>.999?s.b:interpolateContours(s.m,baseProgress);
        if(p.getAttribute('d')!==d)p.setAttribute('d',d);
        const changing=baseProgress>.002&&baseProgress<.998&&t>7;
        const echoLight=s.special==='echo'?smooth(echoAt,echoAt+.28,t)*(1-smooth(echoAt+.48,echoAt+.94,t)):0;
        const needleLight=s.special==='focus'?smooth(13.55,13.97,t)*(1-smooth(16.2,17.5,t)):0;
        const light=Math.max(echoLight,needleLight);
        const fill=light>.001?'color-mix(in srgb, '+a.accent+' '+(light*100).toFixed(2)+'%, #c7c9cf)':changing?'#f4edff':'#c7c9cf';
        p.setAttribute('fill',fill);
      }
    }
    this.scan.setAttribute('opacity',smooth(22.35,22.8,t)*(1-smooth(23.65,24.35,t))+.16*smooth(28.8,29.15,t));
    const sweep=t<27?(t-22.4)/1.9:(t-28.3)/2.2;
    this.ray.setAttribute('transform','translate('+(-210+1320*sweep)+' 0)');
    this.notes.setAttribute('opacity',smooth(.70,1,exp));
    this.callout.replaceChildren();
    const leader=(x,y,txt,amount,dx,dy)=>{
      if(amount<.005)return;
      const xx=x+dx,yy=y+dy,sgn=Math.sign(dx),g=svgEl('g',{opacity:amount});
      g.append(svgEl('circle',{cx:x,cy:y,r:4}),svgEl('path',{d:'M'+x+' '+y+'L'+xx+' '+yy+'h'+(sgn*(txt.length*11+13))}));
      const text=svgEl('text',{x:xx+sgn*7,y:yy-6,'text-anchor':sgn>0?'start':'end',fill:'#f1eadc',stroke:'#202532','stroke-width':3.2,'stroke-linejoin':'round','paint-order':'stroke','font-size':13,'font-family':'Microsoft YaHei, sans-serif'});
      text.textContent=txt;g.append(text);this.callout.append(g);
    };
    leader(...a.focus,a.detail,smooth(13.55,14.3,t)*(1-smooth(15.8,16.5,t)),63,-59);
    a.echoes.forEach((xy,i)=>{
      const start=echoStart(i);
      if(i===0||i===Math.floor(a.echoes.length/2)||i===a.echoes.length-1)
        leader(...xy,'呼应',smooth(start,start+.28,t)*(1-smooth(start+.58,start+.98,t)),i%2?42:-42,-31);
    });
    leader(850,a.guide[3],'英文基线',smooth(18.7,19.3,t)*(1-smooth(20.6,21.3,t)),44,23);
    const registration=smooth(18.65,19.4,t)*(1-smooth(20.6,21.3,t));
    if(registration>.001){
      const top=a.guide[3]-(n===0?22.7:24.2),bottom=a.guide[3];
      const g=svgEl('g',{opacity:registration,'stroke-width':.9});
      g.append(svgEl('path',{d:'M145 '+top+'H875M145 '+bottom+'H875','stroke-dasharray':'3 6'}));
      this.callout.append(g);
      leader(191,top,'大写字高',registration,-35,-17);
    }
    const segment=[0,4.28,7.04,8.90,10.76,13.0,15.8,17.95,21.2,24.7].reduce((v,start,i)=>t>=start?i:v,0);
    this.caption.textContent=motionText[n][segment];
    this.caption.style.opacity=String(smooth(.12,.6,t)*(1-smooth(28,28.7,t)));
    this.host.style.setProperty('--scene-accent',a.accent);
  }
  async ready(){await Promise.all([...this.backgrounds,...this.materials].map(im=>im.decode()));}
}

