(() => {
  const ns='http://www.w3.org/2000/svg';
  const node=(name,attributes)=>{
    const el=document.createElementNS(ns,name);
    for(const [key,value] of Object.entries(attributes))el.setAttribute(key,value);
    return el;
  };
  function seeded(value){
    let seed=value>>>0;
    return ()=>{seed=(Math.imul(1664525,seed)+1013904223)>>>0;return seed/4294967296;};
  }
  const sky=document.getElementById('night');
  function drawSky(){
    const w=window.innerWidth,h=window.innerHeight,dpr=Math.min(window.devicePixelRatio,1.75);
    sky.width=w*dpr;sky.height=h*dpr;
    const ctx=sky.getContext('2d');ctx.scale(dpr,dpr);
    const rand=seeded(160271);
    for(let i=0;i<w*h/3500;i++){
      const x=rand()*w,y=rand()*h,r=.25+rand()**3*.93;
      ctx.beginPath();ctx.fillStyle='rgba(200,195,230,'+(.15+rand()*.43)+')';ctx.arc(x,y,r,0,2*Math.PI);ctx.fill();
      if(r>1.11){
        ctx.fillStyle='#cfc5e554';ctx.fillRect(x-2.6,y-.35,5.2,.7);ctx.fillRect(x-.35,y-2.6,.7,5.2);
      }
    }
  }
  drawSky();
  window.addEventListener('resize',drawSky);
  const chart=document.getElementById('orrery'),rand=seeded(19347);
  const cx=422,cy=119,R=71;
  chart.innerHTML='<defs><radialGradient id="orbMist" cx=".27" cy=".19" r=".94"><stop stop-color="#a190b3" stop-opacity=".55"/><stop offset=".4" stop-color="#584c72" stop-opacity=".64"/><stop offset=".76" stop-color="#2d283f"/><stop offset="1" stop-color="#161722"/></radialGradient><clipPath id="globeClip"><circle cx="422" cy="119" r="71"/></clipPath><linearGradient id="orbitLine"><stop stop-color="#8f779f" stop-opacity=".03"/><stop offset=".3" stop-color="#ad93bd" stop-opacity=".55"/><stop offset=".70" stop-color="#a799bd" stop-opacity=".65"/><stop offset="1" stop-color="#b9a3c9" stop-opacity=".09"/></linearGradient></defs>';
  function curve(points,stroke,width,alpha=1,dash=''){
    const path=node('path',{d:'M'+points.map(p=>p.map(v=>v.toFixed(1)).join(',')).join(' '),fill:'none',stroke,'stroke-width':width,opacity:alpha});
    if(dash)path.setAttribute('stroke-dasharray',dash);return path;
  }
  function orbit(a,b,tilt,t0,t1,offsetX=0,offsetY=0){
    const points=[],s=Math.sin(tilt),c=Math.cos(tilt);
    for(let i=0;i<=180;i++){const t=t0+(t1-t0)*i/180,x=a*Math.cos(t),y=b*Math.sin(t);points.push([cx+offsetX+x*c-y*s,cy+offsetY+x*s+y*c]);}
    return points;
  }
  chart.append(curve(orbit(287,53,-.235,0,2*Math.PI,-29,10),'url(#orbitLine)',.83));
  chart.append(curve(orbit(271,59,-.29,-2.7,2.06,-27,9),'#9e90af',.66,.34,'1 6'));
  chart.append(curve(orbit(194,73,.43,-3.6,3.1), '#8b7899',.76,.48));
  chart.append(curve(orbit(151,88,-.32,-3.23,.12),'#9986a7',.83,.55));
  chart.append(curve(orbit(131,80,-.31,1.22,5.94),'#6a627c',.68,.75,'2 4'));
  const constellation=[[37,111],[85,77],[142,84],[170,50],[205,60]];
  chart.append(curve(constellation,'#8d809d',.7,.48));
  constellation.forEach(([x,y],i)=>chart.append(node('circle',{cx:x,cy:y,r:i===1?2.3:1.45,fill:'#c6b4d2',opacity:.8})));
  chart.append(node('circle',{cx,cy,r:R,fill:'url(#orbMist)',stroke:'#a798be','stroke-width':.8}));
  const face=node('g',{'clip-path':'url(#globeClip)'});
  chart.append(face);
  const tilt=.31,ct=Math.cos(tilt),st=Math.sin(tilt),latitude=.27;
  function globe(lon,lat){
    const x=Math.cos(lat)*Math.sin(lon),y0=-Math.sin(lat),z0=Math.cos(lat)*Math.cos(lon);
    const y=y0*Math.cos(latitude)+z0*Math.sin(latitude),z=z0*Math.cos(latitude)-y0*Math.sin(latitude);
    return [cx+R*(x*ct-y*st),cy+R*(x*st+y*ct),z];
  }
  // Stippled copperplate hemisphere. The globe's flecks follow longitudes and latitudes.
  let dots='';
  for(let i=0;i<4200;i++){
    const lon=(rand()-.5)*Math.PI*2,lat=Math.asin(rand()*2-1);
    const [x,y,z]=globe(lon,lat);if(z<0)continue;
    const land=Math.sin(lon*6+Math.sin(lat*9)*1.3)+Math.cos(lat*11-lon*5)+.46*Math.sin(lon*20+lat*16);
    const tone=(.85-(x-cx)/R*.48-(y-cy)/R*.44)*(.35+(land>.1?.55:.07));
    if(rand()<tone)dots+='M'+x.toFixed(2)+' '+y.toFixed(2)+'l'+(.55+rand()*.75).toFixed(2)+' -.36';
  }
  face.append(node('path',{d:dots,fill:'none',stroke:'#dbd0e8','stroke-width':.8,opacity:'.66'}));
  function graticule(cb,color,w,op){
    let points=[];
    for(let i=0;i<=180;i++){const p=cb(i/180);if(p[2]>=0){points.push(p.slice(0,2));}else if(points.length){if(points.length>1)face.append(curve(points,color,w,op));points=[];}}
    if(points.length>1)face.append(curve(points,color,w,op));
  }
  for(let lat=-75;lat<90;lat+=15)graticule(t=>globe((t-.5)*Math.PI*2,lat*Math.PI/180),'#c6b5d2',.63,lat%30===0?.52:.28);
  for(let lon=-150;lon<=180;lon+=20)graticule(t=>globe(lon*Math.PI/180,(t-.5)*Math.PI),'#bdaccb',.65,.41);
  chart.append(curve(orbit(177,31,-.32,.0,Math.PI+.08),'#bfadcc',1.2,.81));
  chart.append(curve(orbit(179,36,-.32,.05,3.33),'#9580a7',.7,.75));
  chart.append(curve([[cx-38,cy-98],[cx-31,cy-80],[cx-28,cy-72]],'#b6a7c1',1,.67));
  chart.append(curve([[cx+24,cy+67],[cx+36,cy+100]],'#b6a7c1',1,.68));
  chart.append(node('circle',{cx:cx-38,cy:cy-98,r:2.5,fill:'#c0aacd'}));
  function flare(x,y,r,c){
    chart.append(node('path',{d:'M'+x+' '+(y-r)+'q1.2 '+(r*.85)+' '+r+' '+r+'q-'+(r*.86)+' 1.3 -'+r+' '+r+'q-1.2 -'+(r*.85)+' -'+r+' -'+r+'q'+(r*.85)+' -1.2 '+r+' -'+r+'Z',fill:c}));
  }
  flare(253,174,6.4,'#cdb9dc');flare(612,80,7.7,'#d3c2df');flare(324,48,3.5,'#ada0c1');flare(538,201,4.2,'#ccbad5');
  for(let i=0;i<61;i++){const x=rand()*680,y=rand()*250; if(Math.hypot(x-cx,y-cy)>R+5)chart.append(node('circle',{cx:x,cy:y,r:.3+rand()*.78,fill:'#c4b7cd',opacity:.2+rand()*.55}));}
  chart.append(node('circle',{cx:293,cy:82,r:6.4,fill:'#736582',stroke:'#bba8c7','stroke-width':.95}));
  chart.append(curve(orbit(8.8,2.3,-.4,0,Math.PI*2,293-cx,82-cy),'#d2bddb',.8,.85));
  chart.append(node('circle',{cx:555,cy:151,r:3.2,fill:'#b19dbc'}));
  const signal=document.getElementById('signal');
  for(let n=0;n<7;n++){
    const ps=[];
    for(let i=0;i<=176;i++){
      const x=i*320/176,env=Math.sin(i*Math.PI/176)**1.15;
      const y=34+(Math.sin(x/31+n*.43)*19.2+Math.sin(x/14.7+n*.26)*3.6)*env;
      ps.push([x,y]);
    }
    signal.append(curve(ps,'#b99bce',n===0?1.05:.65,n===0?.85:.45));
  }
  signal.append(curve([[0,34],[320,34]],'#9d8cab',.6,.6,'2 5'));
})();
