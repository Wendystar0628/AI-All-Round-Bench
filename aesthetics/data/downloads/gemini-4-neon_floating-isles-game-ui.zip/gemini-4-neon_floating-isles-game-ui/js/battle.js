/* ==========================================================================
   《浮空群岛传说》 — Interactive & Choreographed ARPG Battle + Ougi Engine
   Handles Multi-layer Boss HP, Overdrive/Break, Link Time, Skills/CD,
   Damage Numbers (Normal / Crit / Weak / Ougi / Heal) & 4-Chain Full Burst
   ========================================================================== */

window.SkyUI = window.SkyUI || {};

window.SkyUI.Battle = (function () {
  const Data = window.SkyUI.Data;
  const State = window.SkyUI.State;
  const Backdrop = window.SkyUI.Backdrop;

  const LAYER_COLORS = [
    'linear-gradient(90deg, #b81d24, #ff5638)', // Layer 1 (Final crimson)
    'linear-gradient(90deg, #1b6fc9, #46c8ff)', // Layer 2 (Sapphire)
    'linear-gradient(90deg, #169c65, #3be09c)', // Layer 3 (Emerald)
    'linear-gradient(90deg, #c97b18, #ffbe42)', // Layer 4 (Amber)
    'linear-gradient(90deg, #992055, #e8487a)'  // Layer 5 (Ruby top)
  ];

  // Deterministic pseudo-random for damage variance & popup positions
  let rngSeed = 1337;
  function rand() {
    rngSeed = (rngSeed * 1664525 + 1013904223) >>> 0;
    return rngSeed / 4294967296;
  }

  let popIdSeq = 1;

  const b = {
    active: false,
    bTime: 0,
    startedAt: 0,
    defeated: false,
    defeatedAt: -1,
    clearTriggered: false,

    // Boss state
    bossMaxHp: 900000,
    bossHp: 900000,
    bossGhostHp: 900000,
    bossLayers: 5,
    bossMode: 'normal',       // 'normal' | 'overdrive' | 'break'
    bossModeGauge: 12,        // 0..100
    breakRemaining: 0,

    // Lock-on reticle coordinates
    lockX: 960,
    lockY: 405,

    // Team Link
    linkGauge: 24,            // 0..100
    linkTimeActive: false,

    // Combo
    combo: 0,
    comboDecayTimer: 0,

    // Party combat stats (indices 0..3 correspond to State.party.slots)
    members: [],

    // Leader's 4 skills cooldown state
    skills: [],               // { id, name, icon, cdMax, cdLeft, justReadyTimer, justCastTimer }

    // Floating damage popups
    popups: [],

    // Active cinematic banner
    banner: null,             // { kind, startT, duration, title, sub, kicker }

    // Ougi / Chain Burst sequence state
    ougiSeq: {
      active: false,
      startT: 0,
      phase: 'none',          // 'cutin' | 'fullburst'
      chainCount: 0,
      casterIdx: 0,
      casterCharId: 'aerin',
      ougiName: '',
      ougiEn: '',
      element: 'wind',
      totalChainDmg: 0,
      displayedTotalDmg: 0,
      triggeredStages: {}
    },

    // Choreography script cursor
    scriptFired: {}
  };

  function initBattle(startAtOugiShowcase) {
    rngSeed = 42026;
    popIdSeq = 1;
    popSlotCursor = 0;
    Backdrop.clearFx();

    const slots = State.state.party.slots;
    b.active = true;
    b.bTime = startAtOugiShowcase ? 19.6 : 0;
    b.startedAt = State.state.t;
    b.defeated = false;
    b.defeatedAt = -1;
    b.clearTriggered = false;

    b.bossLayers = Data.BOSS_IGNIS.maxLayers;
    b.bossMaxHp = b.bossLayers * Data.BOSS_IGNIS.hpPerLayer;
    b.bossHp = startAtOugiShowcase ? b.bossMaxHp * 0.44 : b.bossMaxHp;
    b.bossGhostHp = b.bossHp;
    b.bossMode = startAtOugiShowcase ? 'overdrive' : 'normal';
    b.bossModeGauge = startAtOugiShowcase ? 24 : 10;
    b.breakRemaining = 0;

    b.lockX = 960;
    b.lockY = 405;

    b.linkGauge = startAtOugiShowcase ? 38 : 22;
    b.linkTimeActive = false;
    b.combo = startAtOugiShowcase ? 48 : 0;
    b.comboDecayTimer = 0;

    b.members = slots.map((cid, idx) => {
      const stats = State.computeCharStats(cid);
      return {
        charId: cid,
        slotIdx: idx,
        maxHp: stats.hp,
        hp: startAtOugiShowcase ? Math.round(stats.hp * (0.86 + idx * 0.03)) : stats.hp,
        ougi: startAtOugiShowcase ? 100 : (28 + idx * 7)
      };
    });

    const leaderId = slots[0];
    const build = State.state.builds[leaderId];
    b.skills = build.skills.map((sid) => {
      const sk = State.getSkillById(leaderId, sid);
      // Compress demo cooldown slightly (~45% of nominal) so players watch full CD cycles & READY glow!
      const demoCd = Math.max(4.5, Math.round((sk.cd * 0.45) * 10) / 10);
      return {
        id: sk.id,
        name: sk.name,
        icon: sk.icon,
        cdMax: demoCd,
        cdLeft: 0,
        justReadyTimer: 0,
        justCastTimer: 0
      };
    });

    b.popups = [];
    b.banner = null;
    b.ougiSeq = {
      active: false,
      startT: 0,
      phase: 'none',
      chainCount: 0,
      casterIdx: 0,
      casterCharId: slots[0],
      ougiName: '',
      ougiEn: '',
      element: Data.CHARACTERS[slots[0]].element,
      totalChainDmg: 0,
      displayedTotalDmg: 0,
      triggeredStages: {}
    };

    b.scriptFired = {};
    if (startAtOugiShowcase) {
      // Mark earlier script beats as already passed so it fires 4-Chain Ougi immediately at 20.4s
      const earlyKeys = [
        'intro', 's1_a', 'hit_1', 's2_a', 'hit_2', 's3_a', 'hit_3',
        'link_start', 's4_a', 'link_flurry_1', 'link_flurry_2', 'link_flurry_3',
        'od_start', 'boss_slam', 'sia_heal', 'od_press_1', 'od_press_2', 'ougi_ready_all'
      ];
      earlyKeys.forEach(k => { b.scriptFired[k] = true; });
    }
  }

  // Clean non-overlapping spatial slots around lock-on reticle
  const POP_OFFSETS = [
    [-165, -75], [155, -85], [-190, 25], [175, 18],
    [-95, -125], [105, -120], [-145, 78], [140, 72]
  ];
  let popSlotCursor = 0;

  function spawnPopup(val, kind, offsetX, offsetY, tag) {
    const slot = POP_OFFSETS[popSlotCursor % POP_OFFSETS.length];
    popSlotCursor++;
    const jx = (rand() - 0.5) * 32;
    const jy = (rand() - 0.5) * 20;
    const x = b.lockX + (offsetX != null ? offsetX : (slot[0] + jx));
    const y = b.lockY + (offsetY != null ? offsetY : (slot[1] + jy));
    b.popups.push({
      id: popIdSeq++,
      val: kind === 'heal' ? ('+' + val.toLocaleString()) : val.toLocaleString(),
      kind, // 'normal' | 'crit' | 'weak' | 'ougi' | 'heal'
      tag: tag || (kind === 'crit' ? 'CRIT!' : kind === 'weak' ? 'WEAK · 水' : kind === 'ougi' ? 'OUGI!!' : ''),
      x,
      y,
      vx: (slot[0] >= 0 ? 1 : -1) * (14 + rand() * 18),
      vy: kind === 'ougi' ? -72 : -54,
      age: 0,
      duration: kind === 'ougi' ? 1.45 : 1.05
    });
    if (b.popups.length > 28) b.popups.shift();
  }

  function setBanner(kind, kicker, title, sub, duration) {
    b.banner = {
      kind,
      kicker,
      title,
      sub,
      age: 0,
      duration: duration || 2.1
    };
  }

  function dealBossDamage(amount, kind, slashColor, skipModeGain) {
    if (b.defeated) return;
    const mult = b.bossMode === 'break' ? 1.45 : (b.linkTimeActive ? 1.25 : 1.0);
    const dmg = Math.round(amount * mult);
    b.bossHp = Math.max(0, b.bossHp - dmg);
    b.combo += (kind === 'ougi' ? 6 : 1);
    b.comboDecayTimer = 4.2;

    spawnPopup(dmg, kind);

    Backdrop.spawnFx({
      type: 'slash',
      birthT: State.state.t,
      duration: 0.36,
      x: b.lockX + (rand() - 0.5) * 90,
      y: b.lockY + (rand() - 0.5) * 70,
      angle: -0.9 + rand() * 1.8,
      color: slashColor || (kind === 'weak' ? '#6ce5ff' : kind === 'crit' ? '#ffe074' : '#85ffd0')
    });

    if (!skipModeGain) {
      if (b.bossMode === 'normal') {
        b.bossModeGauge = Math.min(99, b.bossModeGauge + dmg / 7200);
      } else if (b.bossMode === 'overdrive') {
        b.bossModeGauge = Math.max(6, b.bossModeGauge - dmg / 6800);
      }
    }

    if (!b.linkTimeActive) {
      b.linkGauge = Math.min(99, b.linkGauge + (kind === 'weak' ? 3.2 : 2.1));
    }

    // Charge party Ougi gauges gently
    if (!b.ougiSeq.active) {
      for (let i = 0; i < b.members.length; i++) {
        b.members[i].ougi = Math.min(100, b.members[i].ougi + (i === 0 ? 3.6 : 2.8));
      }
    }

    if (b.bossHp <= 0 && !b.defeated) {
      triggerBossDefeated();
    }
  }

  function triggerBossDefeated() {
    b.defeated = true;
    b.defeatedAt = b.bTime;
    b.bossHp = 0;
    setBanner('clear', 'QUEST CLEAR', '讨伐成功', '天渊兽「焰冠龙 伊格瑞斯」已被击破！', 2.4);
    Backdrop.spawnFx({
      type: 'burst',
      birthT: State.state.t,
      duration: 1.2,
      x: b.lockX,
      y: b.lockY,
      maxR: 380,
      count: 34,
      color: '#ffe699',
      seed: 901
    });
  }

  // Player-triggered (or choreographed) Skill Cast
  function useSkill(slotIdx) {
    if (!b.active || b.defeated || b.ougiSeq.active) return false;
    const sk = b.skills[slotIdx];
    if (!sk || sk.cdLeft > 0) return false;

    sk.cdLeft = sk.cdMax;
    sk.justCastTimer = 0.28;
    sk.justReadyTimer = 0;

    const leaderEl = Data.CHARACTERS[b.members[0].charId].element;
    const color = window.SkyUI.Icons.ELEMENT_META[leaderEl].glow;

    const baseHit = 7800 + slotIdx * 2400;
    const kind = (slotIdx === 1 || slotIdx === 2) ? 'crit' : 'normal';
    dealBossDamage(baseHit, kind, color);
    if (slotIdx === 0 || slotIdx === 2) {
      // Multi-hit feel
      dealBossDamage(Math.round(baseHit * 0.62), 'crit', color);
    }
    b.members[0].ougi = Math.min(100, b.members[0].ougi + 11);
    Backdrop.spawnFx({
      type: 'ring',
      birthT: State.state.t,
      duration: 0.45,
      x: b.lockX,
      y: b.lockY,
      maxR: 180,
      color
    });
    return true;
  }

  function basicAttack() {
    if (!b.active || b.defeated || b.ougiSeq.active) return;
    const isCrit = rand() > 0.55;
    dealBossDamage(isCrit ? 6120 : 3480, isCrit ? 'crit' : 'normal', '#85ffd0');
  }

  function triggerOugiSequence() {
    if (!b.active || b.defeated || b.ougiSeq.active) return false;
    if (b.members[0].ougi < 100) return false;

    // Ensure all 4 teammates join the Full Chain Burst!
    for (let i = 0; i < b.members.length; i++) {
      b.members[i].ougi = 100;
    }

    b.ougiSeq = {
      active: true,
      startT: b.bTime,
      phase: 'cutin',
      chainCount: 1,
      casterIdx: 0,
      casterCharId: b.members[0].charId,
      ougiName: Data.CHARACTERS[b.members[0].charId].ougi.name,
      ougiEn: Data.CHARACTERS[b.members[0].charId].ougi.enName,
      element: Data.CHARACTERS[b.members[0].charId].element,
      totalChainDmg: 0,
      displayedTotalDmg: 0,
      triggeredStages: {}
    };
    return true;
  }

  function stepOugiSequence() {
    const seq = b.ougiSeq;
    const elapsed = b.bTime - seq.startT;
    const slots = b.members.map(m => m.charId);

    // Stage 0: 1st Ougi — 艾琳 (风) [0.0s .. 2.0s]
    if (!seq.triggeredStages.s0 && elapsed >= 0) {
      seq.triggeredStages.s0 = true;
      seq.phase = 'cutin';
      seq.chainCount = 1;
      seq.casterIdx = 0;
      const c = Data.CHARACTERS[slots[0]];
      seq.casterCharId = c.id;
      seq.ougiName = c.ougi.name;
      seq.ougiEn = c.ougi.enName;
      seq.element = c.element;
      b.members[0].ougi = 0;
      Backdrop.spawnFx({
        type: 'burst', birthT: State.state.t, duration: 0.75,
        x: 960, y: 460, maxR: 340, count: 24, color: '#85ffd0', seed: 101
      });
    }
    if (!seq.triggeredStages.s0_dmg && elapsed >= 0.85) {
      seq.triggeredStages.s0_dmg = true;
      const d = 48600;
      seq.totalChainDmg += d;
      dealBossDamage(d, 'ougi', '#85ffd0', true);
    }

    // Stage 1: 2nd Ougi — 罗克 (火) 2 CHAIN [2.0s .. 3.8s]
    if (!seq.triggeredStages.s1 && elapsed >= 2.0) {
      seq.triggeredStages.s1 = true;
      seq.phase = 'cutin';
      seq.chainCount = 2;
      seq.casterIdx = 1;
      const c = Data.CHARACTERS[slots[1]];
      seq.casterCharId = c.id;
      seq.ougiName = c.ougi.name;
      seq.ougiEn = c.ougi.enName;
      seq.element = c.element;
      b.members[1].ougi = 0;
      Backdrop.spawnFx({
        type: 'burst', birthT: State.state.t, duration: 0.75,
        x: 960, y: 460, maxR: 340, count: 24, color: '#ff8a5c', seed: 202
      });
    }
    if (!seq.triggeredStages.s1_dmg && elapsed >= 2.75) {
      seq.triggeredStages.s1_dmg = true;
      const d = 52400;
      seq.totalChainDmg += d;
      dealBossDamage(d, 'ougi', '#ff8a5c', true);
    }

    // Stage 2: 3rd Ougi — 希娅 (水 WEAK!) 3 CHAIN [3.8s .. 5.6s]
    if (!seq.triggeredStages.s2 && elapsed >= 3.8) {
      seq.triggeredStages.s2 = true;
      seq.phase = 'cutin';
      seq.chainCount = 3;
      seq.casterIdx = 2;
      const c = Data.CHARACTERS[slots[2]];
      seq.casterCharId = c.id;
      seq.ougiName = c.ougi.name;
      seq.ougiEn = c.ougi.enName;
      seq.element = c.element;
      b.members[2].ougi = 0;
      Backdrop.spawnFx({
        type: 'burst', birthT: State.state.t, duration: 0.75,
        x: 960, y: 460, maxR: 360, count: 26, color: '#6ce5ff', seed: 303
      });
    }
    if (!seq.triggeredStages.s2_dmg && elapsed >= 4.55) {
      seq.triggeredStages.s2_dmg = true;
      const d = 68900;
      seq.totalChainDmg += d;
      spawnPopup(d, 'weak', -40, -50, 'WEAK OUGI!');
      b.bossHp = Math.max(0, b.bossHp - d);
      b.combo += 6;
    }

    // Stage 3: 4th Ougi — 巴尔多 (土) 4 CHAIN [5.6s .. 7.4s]
    if (!seq.triggeredStages.s3 && elapsed >= 5.6) {
      seq.triggeredStages.s3 = true;
      seq.phase = 'cutin';
      seq.chainCount = 4;
      seq.casterIdx = 3;
      const c = Data.CHARACTERS[slots[3]];
      seq.casterCharId = c.id;
      seq.ougiName = c.ougi.name;
      seq.ougiEn = c.ougi.enName;
      seq.element = c.element;
      b.members[3].ougi = 0;
      Backdrop.spawnFx({
        type: 'burst', birthT: State.state.t, duration: 0.75,
        x: 960, y: 460, maxR: 350, count: 26, color: '#ffd485', seed: 404
      });
    }
    if (!seq.triggeredStages.s3_dmg && elapsed >= 6.35) {
      seq.triggeredStages.s3_dmg = true;
      const d = 56200;
      seq.totalChainDmg += d;
      dealBossDamage(d, 'ougi', '#ffd485', true);
    }

    // Stage 4: FULL BURST FINISHER (Dynamically keyed to 1st caster's element!) [7.4s .. 11.0s]
    if (!seq.triggeredStages.fb && elapsed >= 7.4) {
      seq.triggeredStages.fb = true;
      seq.phase = 'fullburst';
      const finisherDmg = 158820;
      const firstEl = Data.CHARACTERS[slots[0]].element;
      const fbGlow = window.SkyUI.Icons.ELEMENT_META[firstEl].glow;
      seq.totalChainDmg = 384920; // Exact grand total (48600+52400+68900+56200+158820)
      // Drop boss dramatically into final crimson layer (~14% total HP remaining) ready for Break finish!
      b.bossHp = Math.max(b.bossMaxHp * 0.08, Math.min(b.bossHp - finisherDmg, b.bossMaxHp * 0.14));
      b.combo += 18;
      Backdrop.spawnFx({
        type: 'fullburst_vortex', birthT: State.state.t, duration: 2.8,
        x: 960, y: 540, color: fbGlow, seed: 777
      });
      Backdrop.spawnFx({
        type: 'burst', birthT: State.state.t, duration: 1.4,
        x: 960, y: 480, maxR: 520, count: 42, color: fbGlow, seed: 778
      });
    }

    if (seq.phase === 'fullburst') {
      const fbAge = elapsed - 7.4;
      const rollP = Math.min(1, Math.max(0, (fbAge - 0.45) / 1.15));
      const easeOut = 1 - Math.pow(1 - rollP, 3);
      seq.displayedTotalDmg = Math.round(seq.totalChainDmg * easeOut);
    }

    // Stage 5: Sequence ends at 11.0s -> SHATTERS BOSS OVERDRIVE INTO BREAK!!
    if (elapsed >= 11.0) {
      seq.active = false;
      seq.phase = 'none';
      b.bossMode = 'break';
      b.bossModeGauge = 100;
      b.breakRemaining = 12.0;
      setBanner('break', 'OVERDRIVE SHATTERED', '首领破防 · BREAK!!', '伊格瑞斯陷入失衡状态 · 全队伤害大幅提升！', 2.2);
      Backdrop.spawnFx({
        type: 'burst', birthT: State.state.t, duration: 1.1,
        x: b.lockX, y: b.lockY, maxR: 440, count: 36, color: '#8cf4ff', seed: 888
      });
      Backdrop.spawnFx({
        type: 'ring', birthT: State.state.t, duration: 0.75,
        x: b.lockX, y: b.lockY, maxR: 380, color: '#ffffff'
      });
    }
  }

  function runChoreography() {
    const t = b.bTime;
    const once = (key, atTime, fn) => {
      if (!b.scriptFired[key] && t >= atTime) {
        b.scriptFired[key] = true;
        fn();
      }
    };

    // 1. Boss Intro (0.0s -> 3.4s)
    once('intro', 0.15, () => {
      setBanner('boss-intro', 'ABYSSAL BEAST APPEARANCE', '焰冠龙 伊格瑞斯', '天渊兽 · 熔炉之巅的炙热支配者', 3.1);
    });

    // 2. Active Combat Exchange (3.4s -> 9.4s)
    once('s1_a', 3.8, () => useSkill(0));
    once('hit_1', 4.6, () => {
      dealBossDamage(4620, 'normal', '#ffe699');
      dealBossDamage(12480, 'weak', '#6ce5ff'); // Sia water weakness strike!
      b.linkGauge = Math.max(b.linkGauge, 46);
    });
    once('s2_a', 5.4, () => useSkill(1));
    once('hit_2', 6.3, () => {
      dealBossDamage(11850, 'crit', '#ffaa66');
      dealBossDamage(13920, 'weak', '#6ce5ff');
      b.linkGauge = Math.max(b.linkGauge, 72);
    });
    once('s3_a', 7.3, () => useSkill(2));
    once('hit_3', 8.4, () => {
      dealBossDamage(9420, 'normal', '#ffd485');
      dealBossDamage(14260, 'weak', '#6ce5ff');
      b.linkGauge = Math.max(b.linkGauge, 94);
    });

    // 3. LINK TIME (9.5s -> 15.4s)
    once('link_start', 9.5, () => {
      b.linkGauge = 100;
      b.linkTimeActive = true;
      setBanner('link-time', 'PARTY RESONANCE 100%', '连携时刻 · LINK TIME', '敌人动作减缓 · 全队攻击 / 暴击 / 冷却加速！', 2.0);
      Backdrop.spawnFx({
        type: 'ring', birthT: State.state.t, duration: 0.9,
        x: 960, y: 540, maxR: 720, color: '#6ce5ff'
      });
    });

    once('s4_a', 10.7, () => useSkill(3));
    once('link_flurry_1', 11.6, () => {
      dealBossDamage(13400, 'crit', '#85ffd0');
      dealBossDamage(16840, 'weak', '#6ce5ff');
      b.bossModeGauge = Math.max(b.bossModeGauge, 64);
    });
    once('link_flurry_2', 12.9, () => {
      useSkill(0); // Skill 1 came off CD & flashed READY!
      dealBossDamage(15220, 'weak', '#6ce5ff');
      b.bossModeGauge = Math.max(b.bossModeGauge, 82);
    });
    once('link_flurry_3', 14.3, () => {
      dealBossDamage(12900, 'crit', '#ffe074');
      dealBossDamage(11400, 'normal', '#ffd485');
      b.bossModeGauge = Math.max(b.bossModeGauge, 96);
    });

    // 4. BOSS OVERDRIVE (15.5s -> 20.4s)
    once('od_start', 15.5, () => {
      b.linkTimeActive = false;
      b.linkGauge = 0;
      b.bossMode = 'overdrive';
      b.bossModeGauge = 100;
      setBanner('overdrive', 'WARNING // THERMAL SURGE', '首领超载 · OVERDRIVE', '焰冠龙 伊格瑞斯进入狂暴压迫状态！持续攻击将其破防！', 2.1);
      Backdrop.spawnFx({
        type: 'ring', birthT: State.state.t, duration: 0.85,
        x: b.lockX, y: b.lockY, maxR: 540, color: '#ff5238'
      });
    });

    once('boss_slam', 17.0, () => {
      // Boss flame shockwave dips party HP
      const ratios = [0.73, 0.65, 0.78, 0.82];
      for (let i = 0; i < b.members.length; i++) {
        b.members[i].hp = Math.round(b.members[i].maxHp * ratios[i]);
      }
      Backdrop.spawnFx({
        type: 'burst', birthT: State.state.t, duration: 0.7,
        x: b.lockX, y: b.lockY, maxR: 320, count: 20, color: '#ff5238', seed: 551
      });
    });

    once('od_press_1', 17.8, () => {
      useSkill(1);
      dealBossDamage(14200, 'weak', '#6ce5ff');
      b.bossModeGauge = Math.min(b.bossModeGauge, 62);
    });

    once('sia_heal', 18.4, () => {
      // Sia heals the squad!
      for (let i = 0; i < b.members.length; i++) {
        b.members[i].hp = Math.min(b.members[i].maxHp, b.members[i].hp + 7200);
      }
      spawnPopup(7200, 'heal', -320, 260, '潮汐圣愈');
    });

    once('od_press_2', 19.1, () => {
      dealBossDamage(13600, 'crit', '#ffd485');
      dealBossDamage(16200, 'weak', '#6ce5ff');
      b.bossModeGauge = Math.min(b.bossModeGauge, 26);
    });

    once('ougi_ready_all', 19.7, () => {
      for (let i = 0; i < b.members.length; i++) {
        b.members[i].ougi = 100;
      }
    });

    // 5. 4-CHAIN OUGI + WIND FULL BURST -> SHATTERS INTO BREAK! (20.4s -> 31.4s)
    once('fire_ougi_chain', 20.4, () => {
      triggerOugiSequence();
    });

    // 6. Post-BREAK Final Barrage -> Boss Defeated (31.4s -> 34.0s)
    once('break_hit_1', 32.1, () => {
      useSkill(2);
      dealBossDamage(24800, 'weak', '#6ce5ff', true);
    });
    once('break_hit_2', 32.9, () => {
      dealBossDamage(28400, 'crit', '#ffe699', true);
      dealBossDamage(26900, 'weak', '#6ce5ff', true);
    });
    once('break_finisher', 33.7, () => {
      dealBossDamage(Math.max(32000, b.bossHp + 5000), 'crit', '#85ffd0', true);
    });

    // 7. Auto-transition to Results (2.2s after Boss is defeated in interactive mode, whether manual or scripted!)
    if (!State.state.exportMode && b.defeated && !b.clearTriggered && b.defeatedAt >= 0 && b.bTime - b.defeatedAt >= 2.2) {
      b.clearTriggered = true;
      if (State.state.screen === 'battle') {
        State.startTransition('results', () => {
          State.jumpDirect('results');
          window.SkyUI.UI.enterResults();
        });
      }
    }
  }

  function step(dt) {
    if (!b.active) return;
    b.bTime += dt;

    // Gentle target hover motion for lock-on reticle
    const swaySpeed = b.linkTimeActive ? 0.5 : (b.bossMode === 'break' ? 0.35 : 1.45);
    const swayAmp = b.bossMode === 'break' ? 8 : 34;
    b.lockX = 960 + Math.sin(b.bTime * swaySpeed) * swayAmp;
    b.lockY = 402 + Math.cos(b.bTime * swaySpeed * 1.3) * (swayAmp * 0.42);

    // Smooth ghost HP catch-up
    if (b.bossGhostHp > b.bossHp) {
      b.bossGhostHp = Math.max(b.bossHp, b.bossGhostHp - (b.bossGhostHp - b.bossHp) * Math.min(1, dt * 4.5) - 6500 * dt);
    }

    // Link Time gradual drain
    if (b.linkTimeActive) {
      b.linkGauge = Math.max(0, b.linkGauge - dt * 16.9);
      if (b.linkGauge <= 0) {
        b.linkTimeActive = false;
      }
    }

    // Break countdown drain
    if (b.bossMode === 'break' && !b.defeated) {
      b.breakRemaining = Math.max(0, b.breakRemaining - dt);
      b.bossModeGauge = (b.breakRemaining / 12.0) * 100;
    }

    // Skill cooldown updates & READY pulse notification
    const cdSpeed = b.linkTimeActive ? 1.65 : 1.0;
    for (let i = 0; i < b.skills.length; i++) {
      const sk = b.skills[i];
      if (sk.cdLeft > 0) {
        sk.cdLeft = Math.max(0, sk.cdLeft - dt * cdSpeed);
        if (sk.cdLeft === 0) {
          sk.justReadyTimer = 0.72;
        }
      }
      if (sk.justReadyTimer > 0) sk.justReadyTimer = Math.max(0, sk.justReadyTimer - dt);
      if (sk.justCastTimer > 0) sk.justCastTimer = Math.max(0, sk.justCastTimer - dt);
    }

    // Combo decay
    if (b.comboDecayTimer > 0) {
      b.comboDecayTimer -= dt;
      if (b.comboDecayTimer <= 0) b.combo = 0;
    }

    // Damage popups physics
    for (let i = b.popups.length - 1; i >= 0; i--) {
      const p = b.popups[i];
      p.age += dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 45 * dt;
      if (p.age >= p.duration) {
        b.popups.splice(i, 1);
      }
    }

    // Banner timer
    if (b.banner) {
      b.banner.age += dt;
      if (b.banner.age >= b.banner.duration) {
        b.banner = null;
      }
    }

    // Run choreographed progression
    runChoreography();

    // Update Ougi / Chain Burst sequence if active
    if (b.ougiSeq.active) {
      stepOugiSequence();
    }
  }

  function getBossLayerInfo() {
    const hpPer = Data.BOSS_IGNIS.hpPerLayer;
    if (b.bossHp <= 0) {
      return { currentLayer: 0, pct: 0, ghostPct: 0, fillColor: LAYER_COLORS[0], underColor: 'transparent' };
    }
    const currentLayer = Math.min(b.bossLayers, Math.ceil(b.bossHp / hpPer));
    const layerBase = (currentLayer - 1) * hpPer;
    const inLayerHp = b.bossHp - layerBase;
    const pct = Math.max(0, Math.min(100, (inLayerHp / hpPer) * 100));
    const ghostInLayer = Math.min(hpPer, Math.max(inLayerHp, b.bossGhostHp - layerBase));
    const ghostPct = Math.max(0, Math.min(100, (ghostInLayer / hpPer) * 100));

    return {
      currentLayer,
      pct,
      ghostPct,
      fillColor: LAYER_COLORS[currentLayer - 1] || LAYER_COLORS[0],
      underColor: currentLayer > 1 ? LAYER_COLORS[currentLayer - 2] : 'transparent'
    };
  }

  return {
    state: b,
    initBattle,
    step,
    useSkill,
    basicAttack,
    triggerOugiSequence,
    getBossLayerInfo
  };
})();
