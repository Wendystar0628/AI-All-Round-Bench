/* ==========================================================================
   《浮空群岛传说》 — Bespoke Vector SVG Icon & Crest Library
   Unified Sky-Chart Filigree Geometry (Zero external assets, 100% file:// safe)
   ========================================================================== */

window.SkyUI = window.SkyUI || {};

window.SkyUI.Icons = (function () {
  const ELEMENT_META = {
    wind:  { zh: '风', en: 'WIND',  color: '#24d18e', glow: '#85ffd0', cls: 'el-wind' },
    fire:  { zh: '火', en: 'FIRE',  color: '#ff5638', glow: '#ffaa8c', cls: 'el-fire' },
    water: { zh: '水', en: 'WATER', color: '#2ea7ff', glow: '#92daff', cls: 'el-water' },
    earth: { zh: '土', en: 'EARTH', color: '#df9831', glow: '#ffd485', cls: 'el-earth' },
    light: { zh: '光', en: 'LIGHT', color: '#ffe066', glow: '#fff6c2', cls: 'el-light' },
    dark:  { zh: '暗', en: 'DARK',  color: '#a95cff', glow: '#dcadff', cls: 'el-dark' }
  };

  const RARITY_META = {
    bronze: { zh: '铜', en: 'BRONZE', color: '#cf7d4a', cls: 'rar-bronze' },
    silver: { zh: '银', en: 'SILVER', color: '#c9d9ee', cls: 'rar-silver' },
    gold:   { zh: '金', en: 'GOLD',   color: '#ffd461', cls: 'rar-gold' }
  };

  function element(key) {
    const m = ELEMENT_META[key] || ELEMENT_META.wind;
    const c = m.color;
    const g = m.glow;
    switch (key) {
      case 'wind':
        return `<svg viewBox="0 0 32 32" fill="none">
          <path d="M5 17C9 9 18 5 26 7C21 10 19 13 24 15C18 19 12 20 7 25C10 20 9 18 5 17Z" fill="${c}" stroke="${g}" stroke-width="1.3"/>
          <path d="M10 14C14 11 19 10 23 11" stroke="#ffffff" stroke-width="1.2" stroke-linecap="round"/>
          <path d="M8 21C13 19 18 19 22 17" stroke="${g}" stroke-width="1.2" stroke-linecap="round"/>
        </svg>`;
      case 'fire':
        return `<svg viewBox="0 0 32 32" fill="none">
          <path d="M16 3C19 9 25 12 25 19C25 24.5 21 28.5 16 28.5C11 28.5 7 24.5 7 19C7 14 10.5 11 12 8C12 11 14 12.5 14 12.5C13.5 9 14.5 5.5 16 3Z" fill="${c}" stroke="${g}" stroke-width="1.3"/>
          <path d="M16 14C18 17 20 18.8 20 21.5C20 24 18.2 26 16 26C13.8 26 12 24 12 21.5C12 19 14 17 16 14Z" fill="#fff1c4"/>
        </svg>`;
      case 'water':
        return `<svg viewBox="0 0 32 32" fill="none">
          <path d="M16 4C16 4 25 14 25 20.5C25 25.5 21 29 16 29C11 29 7 25.5 7 20.5C7 14 16 4 16 4Z" fill="${c}" stroke="${g}" stroke-width="1.3"/>
          <path d="M12.5 19.5C12.5 22.5 14.5 24.8 17.5 25" stroke="#ffffff" stroke-width="1.6" stroke-linecap="round"/>
          <circle cx="19" cy="18" r="1.8" fill="#d9f4ff"/>
        </svg>`;
      case 'earth':
        return `<svg viewBox="0 0 32 32" fill="none">
          <polygon points="16,4 27,13 23,27 9,27 5,13" fill="${c}" stroke="${g}" stroke-width="1.4"/>
          <polygon points="16,4 21,14 16,27 11,14" fill="#ffdf9e" fill-opacity="0.45"/>
          <path d="M5 13L16 16L27 13" stroke="${g}" stroke-width="1.2"/>
        </svg>`;
      case 'light':
        return `<svg viewBox="0 0 32 32" fill="none">
          <path d="M16 2L19 12L29 16L19 20L16 30L13 20L3 16L13 12L16 2Z" fill="${c}" stroke="#ffffff" stroke-width="1.2"/>
          <path d="M8 8L14 14M24 8L18 14M24 24L18 18M8 24L14 18" stroke="${g}" stroke-width="1.5" stroke-linecap="round"/>
          <circle cx="16" cy="16" r="3" fill="#ffffff"/>
        </svg>`;
      case 'dark':
      default:
        return `<svg viewBox="0 0 32 32" fill="none">
          <path d="M21 5C14 5.5 8 11 8 18C8 24 13 28 19.5 28C22.2 28 24.6 27 26.5 25.3C24.2 25.8 21.5 25.3 19.2 23.6C15.6 21 15 15.8 17.8 12C19.3 10 21.5 8.8 23.8 8.5C23 6.6 22 5.4 21 5Z" fill="${c}" stroke="${g}" stroke-width="1.3"/>
          <path d="M23 11L24.5 14L27.5 15.5L24.5 17L23 20L21.5 17L18.5 15.5L21.5 14L23 11Z" fill="#f3e0ff"/>
        </svg>`;
    }
  }

  function weapon(type, stroke = '#ffe699') {
    switch (type) {
      case '单手剑':
      case 'sword':
        return `<svg viewBox="0 0 48 48" fill="none">
          <path d="M38 6L41 11L21 31L16 26L38 6Z" fill="rgba(255,230,153,0.22)" stroke="${stroke}" stroke-width="2" stroke-linejoin="round"/>
          <path d="M37 10L20 27" stroke="#ffffff" stroke-width="1.2" opacity="0.7"/>
          <path d="M12 24L24 36" stroke="${stroke}" stroke-width="3" stroke-linecap="round"/>
          <path d="M15 33L8 40" stroke="${stroke}" stroke-width="3.2" stroke-linecap="round"/>
          <circle cx="7.5" cy="40.5" r="2.5" fill="${stroke}"/>
        </svg>`;
      case '长枪':
      case 'spear':
        return `<svg viewBox="0 0 48 48" fill="none">
          <path d="M40 7L34 21L27 14L40 7Z" fill="rgba(255,152,110,0.28)" stroke="${stroke}" stroke-width="2" stroke-linejoin="round"/>
          <path d="M31 17L8 40" stroke="${stroke}" stroke-width="2.6" stroke-linecap="round"/>
          <path d="M26 16L32 22" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
          <polygon points="8,40 12,39 9,36" fill="${stroke}"/>
        </svg>`;
      case '法杖':
      case 'staff':
        return `<svg viewBox="0 0 48 48" fill="none">
          <path d="M29 19L8 40" stroke="${stroke}" stroke-width="2.6" stroke-linecap="round"/>
          <circle cx="34" cy="14" r="7" fill="rgba(140,220,255,0.25)" stroke="${stroke}" stroke-width="2"/>
          <path d="M34 5L36 12L43 14L36 16L34 23L32 16L25 14L32 12L34 5Z" fill="#ffffff" opacity="0.9"/>
          <path d="M24 20C27 20 28 22 28 25" stroke="${stroke}" stroke-width="1.8" stroke-linecap="round"/>
        </svg>`;
      case '大斧':
      case 'axe':
        return `<svg viewBox="0 0 48 48" fill="none">
          <path d="M35 12L9 39" stroke="${stroke}" stroke-width="3" stroke-linecap="round"/>
          <path d="M25 10C32 7 39 10 41 18C38 22 33 25 27 24L25 10Z" fill="rgba(255,208,122,0.28)" stroke="${stroke}" stroke-width="2" stroke-linejoin="round"/>
          <path d="M22 15C18 14 15 16 14 20L21 23" stroke="${stroke}" stroke-width="2" stroke-linejoin="round"/>
        </svg>`;
      case '双刀':
      case 'twinblades':
        return `<svg viewBox="0 0 48 48" fill="none">
          <path d="M11 8C16 14 23 22 33 32L29 36C19 26 12 19 11 8Z" fill="rgba(214,166,255,0.26)" stroke="${stroke}" stroke-width="2"/>
          <path d="M37 8C32 14 25 22 15 32L19 36C29 26 36 19 37 8Z" fill="rgba(214,166,255,0.26)" stroke="${stroke}" stroke-width="2"/>
          <path d="M31 34L38 41M17 34L10 41" stroke="${stroke}" stroke-width="2.8" stroke-linecap="round"/>
        </svg>`;
      case '双枪':
      case 'dualguns':
      default:
        return `<svg viewBox="0 0 48 48" fill="none">
          <path d="M10 15H34L37 19H24L20 27H14L17 19H10V15Z" fill="rgba(255,235,140,0.28)" stroke="${stroke}" stroke-width="2" stroke-linejoin="round"/>
          <path d="M38 25H14L11 29H24L28 37H34L31 29H38V25Z" fill="rgba(255,235,140,0.28)" stroke="${stroke}" stroke-width="2" stroke-linejoin="round"/>
          <circle cx="38" cy="17" r="2" fill="#ffffff"/>
          <circle cx="10" cy="27" r="2" fill="#ffffff"/>
        </svg>`;
    }
  }

  function questType(type) {
    switch (type) {
      case '首领讨伐':
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M18 4L22 12L31 9L26 19L30 29L18 25L6 29L10 19L5 9L14 12L18 4Z" fill="rgba(255,96,64,0.28)" stroke="#ff825c" stroke-width="2" stroke-linejoin="round"/>
          <circle cx="18" cy="18" r="4" fill="#ffe699"/>
        </svg>`;
      case '空域护航':
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M18 4L30 9V18C30 25 24.8 30 18 33C11.2 30 6 25 6 18V9L18 4Z" fill="rgba(53,197,235,0.25)" stroke="#6ce5ff" stroke-width="2"/>
          <path d="M18 10L23 18L18 24L13 18L18 10Z" fill="#ffe699"/>
        </svg>`;
      case '遗迹探索':
        return `<svg viewBox="0 0 36 36" fill="none">
          <circle cx="18" cy="18" r="12" stroke="#ffe699" stroke-width="1.8"/>
          <path d="M18 4V10M18 26V32M4 18H10M26 18H32" stroke="#ffe699" stroke-width="1.8"/>
          <polygon points="18,9 21,18 18,27 15,18" fill="#6ce5ff"/>
        </svg>`;
      default:
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M7 29L29 7M29 29L7 7" stroke="#ffe699" stroke-width="2.4" stroke-linecap="round"/>
          <circle cx="18" cy="18" r="5" fill="rgba(230,184,86,0.35)" stroke="#ffe699" stroke-width="1.8"/>
        </svg>`;
    }
  }

  function skill(kind, color = '#85ffd0') {
    switch (kind) {
      case 'slash':
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M6 28C10 15 20 8 31 6C26 14 20 22 11 30L6 28Z" fill="${color}" fill-opacity="0.32" stroke="${color}" stroke-width="2"/>
          <path d="M12 26L28 10" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
        </svg>`;
      case 'whirlwind':
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M7 13C11 8 25 8 29 13C24 16 12 16 7 13Z" stroke="${color}" stroke-width="2"/>
          <path d="M10 20C14 17 22 17 26 20C22 23 14 23 10 20Z" stroke="#ffffff" stroke-width="1.8"/>
          <path d="M14 27C16 25 20 25 22 27L18 32L14 27Z" fill="${color}"/>
        </svg>`;
      case 'thrust':
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M5 31L27 9" stroke="${color}" stroke-width="2.8" stroke-linecap="round"/>
          <polygon points="32,4 28,15 21,8" fill="#ffffff" stroke="${color}" stroke-width="1.5"/>
          <path d="M12 16L20 24" stroke="${color}" stroke-width="2" opacity="0.7"/>
        </svg>`;
      case 'aegis':
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M18 5L29 10V18C29 24.5 24 29 18 31.5C12 29 7 24.5 7 18V10L18 5Z" fill="${color}" fill-opacity="0.25" stroke="${color}" stroke-width="2"/>
          <path d="M18 11V25M12 17H24" stroke="#ffffff" stroke-width="2.2" stroke-linecap="round"/>
        </svg>`;
      case 'flame':
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M18 4C23 11 28 14 28 21C28 27 23.5 31 18 31C12.5 31 8 27 8 21C8 15 13 11 18 4Z" fill="${color}" fill-opacity="0.32" stroke="${color}" stroke-width="2"/>
          <path d="M18 14L22 22L18 26L14 22L18 14Z" fill="#fff3c4"/>
        </svg>`;
      case 'heal':
        return `<svg viewBox="0 0 36 36" fill="none">
          <circle cx="18" cy="18" r="12" fill="${color}" fill-opacity="0.22" stroke="${color}" stroke-width="2"/>
          <path d="M18 10V26M10 18H26" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/>
        </svg>`;
      case 'wave':
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M5 22C9 12 16 10 21 16C24 20 28 18 31 14C30 24 23 29 14 29C9 29 6 26 5 22Z" fill="${color}" fill-opacity="0.32" stroke="${color}" stroke-width="2"/>
          <path d="M11 22C15 19 20 22 25 20" stroke="#ffffff" stroke-width="1.6" stroke-linecap="round"/>
        </svg>`;
      case 'cleave':
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M8 8L28 28M28 8L8 28" stroke="${color}" stroke-width="2.8" stroke-linecap="round"/>
          <polygon points="18,4 23,14 18,18 13,14" fill="#ffffff"/>
        </svg>`;
      case 'buff':
      default:
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M18 5L22 14L31 18L22 22L18 31L14 22L5 18L14 14L18 5Z" fill="${color}" fill-opacity="0.3" stroke="${color}" stroke-width="2"/>
          <circle cx="18" cy="18" r="3.5" fill="#ffffff"/>
        </svg>`;
    }
  }

  function item(kind, color = '#ffd461') {
    switch (kind) {
      case 'core':
        return `<svg viewBox="0 0 36 36" fill="none">
          <polygon points="18,3 30,12 26,29 10,29 6,12" fill="${color}" fill-opacity="0.3" stroke="${color}" stroke-width="2"/>
          <polygon points="18,9 24,18 18,26 12,18" fill="#ffffff" fill-opacity="0.85"/>
        </svg>`;
      case 'scale':
        return `<svg viewBox="0 0 36 36" fill="none">
          <path d="M18 4L29 15C29 24 24 30 18 32C12 30 7 24 7 15L18 4Z" fill="${color}" fill-opacity="0.28" stroke="${color}" stroke-width="2"/>
          <path d="M18 10V26M12 17L18 22L24 17" stroke="#ffffff" stroke-width="1.6"/>
        </svg>`;
      case 'sigil':
        return `<svg viewBox="0 0 36 36" fill="none">
          <polygon points="18,3 31,10.5 31,25.5 18,33 5,25.5 5,10.5" fill="${color}" fill-opacity="0.26" stroke="${color}" stroke-width="2"/>
          <path d="M18 9L23 18L18 27L13 18L18 9Z" fill="#ffffff" fill-opacity="0.88"/>
        </svg>`;
      case 'crystal':
        return `<svg viewBox="0 0 36 36" fill="none">
          <polygon points="18,3 27,15 18,33 9,15" fill="${color}" fill-opacity="0.32" stroke="${color}" stroke-width="2"/>
          <path d="M18 3V33M9 15H27" stroke="#ffffff" stroke-width="1.2" opacity="0.7"/>
        </svg>`;
      default:
        return `<svg viewBox="0 0 36 36" fill="none">
          <rect x="8" y="8" width="20" height="20" transform="rotate(45 18 18)" fill="${color}" fill-opacity="0.28" stroke="${color}" stroke-width="2"/>
          <circle cx="18" cy="18" r="4" fill="#ffffff"/>
        </svg>`;
    }
  }

  function chest(rarity, opened) {
    const pal = {
      bronze: { body: '#6b381d', trim: '#e0915c', glow: '#ffbe8a' },
      silver: { body: '#364a66', trim: '#dbe9fa', glow: '#a8e2ff' },
      gold:   { body: '#7c5312', trim: '#ffe27a', glow: '#fff6b8' }
    }[rarity] || { body: '#7c5312', trim: '#ffe27a', glow: '#fff6b8' };

    if (!opened) {
      return `<svg viewBox="0 0 100 88" fill="none">
        <path d="M14 34L22 18H78L86 34H14Z" fill="${pal.body}" stroke="${pal.trim}" stroke-width="2.6"/>
        <rect x="14" y="34" width="72" height="40" rx="3" fill="${pal.body}" stroke="${pal.trim}" stroke-width="2.6"/>
        <path d="M14 48H86" stroke="${pal.trim}" stroke-width="2.4"/>
        <path d="M32 18V74M68 18V74" stroke="${pal.trim}" stroke-width="2.2" opacity="0.75"/>
        <polygon points="50,38 58,48 50,58 42,48" fill="${pal.trim}" stroke="#161c2e" stroke-width="1.6"/>
      </svg>`;
    }
    return `<svg viewBox="0 0 100 88" fill="none">
      <polygon points="50,4 88,42 12,42" fill="${pal.glow}" fill-opacity="0.34"/>
      <path d="M12 28L20 10H80L88 28L78 36H22L12 28Z" fill="${pal.body}" stroke="${pal.trim}" stroke-width="2.4"/>
      <rect x="16" y="40" width="68" height="36" rx="3" fill="${pal.body}" stroke="${pal.trim}" stroke-width="2.6"/>
      <ellipse cx="50" cy="40" rx="28" ry="8" fill="${pal.glow}" fill-opacity="0.88"/>
      <path d="M50 8L53 24L67 28L53 32L50 46L47 32L33 28L47 24L50 8Z" fill="#ffffff"/>
      <path d="M32 40V76M68 40V76" stroke="${pal.trim}" stroke-width="2.2" opacity="0.8"/>
    </svg>`;
  }

  function titleEmblem() {
    return `<svg viewBox="0 0 240 120" fill="none">
      <circle cx="120" cy="62" r="44" stroke="#ffe699" stroke-width="1.4" stroke-dasharray="5 5" opacity="0.75"/>
      <circle cx="120" cy="62" r="32" stroke="#35c5eb" stroke-width="1.5" opacity="0.8"/>
      <path d="M22 66C52 54 78 52 104 62C78 72 52 76 22 66Z" fill="rgba(255,226,140,0.22)" stroke="#ffe699" stroke-width="1.8"/>
      <path d="M218 66C188 54 162 52 136 62C162 72 188 76 218 66Z" fill="rgba(255,226,140,0.22)" stroke="#ffe699" stroke-width="1.8"/>
      <path d="M48 48C74 44 94 48 110 58" stroke="#8cf0ff" stroke-width="1.4" stroke-linecap="round"/>
      <path d="M192 48C166 44 146 48 130 58" stroke="#8cf0ff" stroke-width="1.4" stroke-linecap="round"/>
      <path d="M120 12L127 52L164 62L127 72L120 110L113 72L76 62L113 52L120 12Z" fill="url(#goldStarGrad)" stroke="#fff8dc" stroke-width="1.4"/>
      <circle cx="120" cy="62" r="7" fill="#ffffff"/>
      <defs>
        <linearGradient id="goldStarGrad" x1="120" y1="12" x2="120" y2="110" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stop-color="#fff8d6"/>
          <stop offset="55%" stop-color="#f0be52"/>
          <stop offset="100%" stop-color="#b57a1c"/>
        </linearGradient>
      </defs>
    </svg>`;
  }

  function astrolabeSvg(stroke = '#e6b856') {
    let ticks = '';
    for (let i = 0; i < 36; i++) {
      const a = (i * 10) * Math.PI / 180;
      const r1 = i % 3 === 0 ? 184 : 190;
      const r2 = 196;
      const x1 = 200 + Math.cos(a) * r1;
      const y1 = 200 + Math.sin(a) * r1;
      const x2 = 200 + Math.cos(a) * r2;
      const y2 = 200 + Math.sin(a) * r2;
      ticks += `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${stroke}" stroke-width="${i % 3 === 0 ? 1.8 : 0.9}" opacity="0.65"/>`;
    }
    return `<svg viewBox="0 0 400 400" fill="none">
      <circle cx="200" cy="200" r="196" stroke="${stroke}" stroke-width="1.2" opacity="0.48"/>
      <circle cx="200" cy="200" r="176" stroke="${stroke}" stroke-width="1" stroke-dasharray="10 8" opacity="0.45"/>
      <circle cx="200" cy="200" r="138" stroke="#6ce5ff" stroke-width="1" opacity="0.35"/>
      <polygon points="200,12 206,26 200,34 194,26" fill="${stroke}"/>
      <polygon points="200,388 206,374 200,366 194,374" fill="${stroke}"/>
      <polygon points="12,200 26,194 34,200 26,206" fill="${stroke}"/>
      <polygon points="388,200 374,194 366,200 374,206" fill="${stroke}"/>
      ${ticks}
    </svg>`;
  }

  function lockOnReticle() {
    return `<svg viewBox="0 0 170 170" fill="none">
      <g class="reticle-outer">
        <circle cx="85" cy="85" r="68" stroke="#ffe699" stroke-width="1.5" stroke-dasharray="22 14" opacity="0.88"/>
        <path d="M85 6V24M85 146V164M6 85H24M146 85H164" stroke="#ffe699" stroke-width="2.4" stroke-linecap="round"/>
      </g>
      <g class="reticle-inner">
        <polygon points="85,32 138,85 85,138 32,85" stroke="#ff7a52" stroke-width="2" fill="rgba(255,96,64,0.06)"/>
        <circle cx="85" cy="85" r="9" stroke="#ffffff" stroke-width="2"/>
        <circle cx="85" cy="85" r="3" fill="#ff5638"/>
      </g>
    </svg>`;
  }

  function tourCursorSvg() {
    return `<svg viewBox="0 0 44 44" fill="none">
      <path d="M6 5L34 19L21 23L17 36L6 5Z" fill="url(#curGrad)" stroke="#ffffff" stroke-width="2" stroke-linejoin="round"/>
      <path d="M12 11L23 20" stroke="#162138" stroke-width="1.4" opacity="0.5"/>
      <defs>
        <linearGradient id="curGrad" x1="6" y1="5" x2="30" y2="34" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stop-color="#fff8d6"/>
          <stop offset="55%" stop-color="#f2bd4e"/>
          <stop offset="100%" stop-color="#35c5eb"/>
        </linearGradient>
      </defs>
    </svg>`;
  }

  function crownSvg() {
    return `<svg viewBox="0 0 24 24" width="15" height="15" fill="none">
      <path d="M3 18L5 7L10 12L12 5L14 12L19 7L21 18H3Z" fill="currentColor"/>
    </svg>`;
  }

  function compassSvg() {
    return `<svg viewBox="0 0 24 24" width="15" height="15" fill="none">
      <circle cx="12" cy="12" r="9.5" stroke="currentColor" stroke-width="1.6"/>
      <polygon points="12,4 14.5,12 12,20 9.5,12" fill="currentColor"/>
    </svg>`;
  }

  return {
    ELEMENT_META,
    RARITY_META,
    element,
    weapon,
    questType,
    skill,
    item,
    chest,
    titleEmblem,
    astrolabeSvg,
    lockOnReticle,
    tourCursorSvg,
    crownSvg,
    compassSvg
  };
})();
