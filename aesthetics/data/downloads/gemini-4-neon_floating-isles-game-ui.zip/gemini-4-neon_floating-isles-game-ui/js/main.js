/* ==========================================================================
   《浮空群岛传说》 — Entry Bootstrap, 16:9 4K Scaler & Real-Time Loop
   ========================================================================== */

window.SkyUI = window.SkyUI || {};

(function () {
  const Icons = window.SkyUI.Icons;
  const State = window.SkyUI.State;
  const Battle = window.SkyUI.Battle;
  const Backdrop = window.SkyUI.Backdrop;
  const UI = window.SkyUI.UI;

  let lastRealTime = null;

  function updateStageScale() {
    const scale = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
    document.documentElement.style.setProperty('--stage-scale', scale.toFixed(6));
    Backdrop.resize(scale);
    if (State.state.exportMode) {
      UI.renderFrame(State.state.t);
    }
  }

  function hydrateSvgOrnaments() {
    const map = {
      'title-emblem-svg': Icons.titleEmblem(),
      'title-astro-outer': Icons.astrolabeSvg('#ffe699'),
      'title-astro-inner': Icons.astrolabeSvg('#6ce5ff'),
      'story-ring-svg': Icons.astrolabeSvg('#ffe699'),
      'chapter-ring-svg': Icons.astrolabeSvg('#ffe699'),
      'battle-lockon-svg': Icons.lockOnReticle(),
      'fb-ring-svg': Icons.astrolabeSvg('#85ffd0'),
      'rank-ring-svg': Icons.astrolabeSvg('#ffe699'),
      'curtain-crest-svg': Icons.astrolabeSvg('#ffe699'),
      'tour-cursor': Icons.tourCursorSvg(),
      'dir-compass-icon': Icons.compassSvg()
    };
    for (const [id, html] of Object.entries(map)) {
      const el = document.getElementById(id);
      if (el) el.innerHTML = html;
    }
  }

  function tick(now) {
    if (!State.state.exportMode) {
      if (lastRealTime === null) lastRealTime = now;
      const dt = Math.min(0.05, Math.max(0, (now - lastRealTime) / 1000));
      lastRealTime = now;

      State.state.t += dt;
      if (State.state.screen === 'battle') {
        Battle.step(dt);
      }
      UI.renderFrame(State.state.t);
    } else {
      lastRealTime = null;
    }
    requestAnimationFrame(tick);
  }

  function boot() {
    Backdrop.init();
    hydrateSvgOrnaments();
    UI.bindEvents();
    updateStageScale();
    window.addEventListener('resize', updateStageScale);

    // Initial UI render
    UI.renderTitleScreen();
    UI.renderQuestScreen();
    UI.renderPartyScreen();
    UI.renderFrame(0);

    requestAnimationFrame(tick);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
