/* ==========================================================================
   《浮空群岛传说》 — Unified Game State, Loadouts & Real-Time Stat Diff Engine
   ========================================================================== */

window.SkyUI = window.SkyUI || {};

window.SkyUI.State = (function () {
  const Data = window.SkyUI.Data;

  const state = {
    screen: 'title',       // 'title' | 'story' | 'quest' | 'party' | 'battle' | 'results'
    screenEnteredAt: 0,
    prevScreen: 'title',

    // Master simulation clock (seconds)
    t: 0,
    exportMode: false,

    // Title Screen State
    title: {
      menuExpanded: false,
      menuExpandedAt: -1,
      selectedIndex: 0,    // 0: 继续游戏, 1: 新游戏, 2: 设置
      settingsOpen: false
    },

    // Settings
    settings: {
      vfx: '高',
      dmgNums: '开启',
      hints: '开启',
      volume: '80%'
    },

    // Story Screen State
    story: {
      lineIndex: 0,
      lineStartedAt: 0,
      autoMode: false,
      fastMode: false,
      openGlossaryTerm: null,
      chapterCardOpen: false,
      chapterCardAt: -1
    },

    // Quest Counter State
    quest: {
      difficulty: 'extreme', // 'normal' | 'hard' | 'extreme' | 'legend'
      selectedQuestId: 'q_e1',
      tabChangedAt: -10,
      detailChangedAt: -10
    },

    // Party & Character Growth State
    party: {
      slots: ['aerin', 'roke', 'sia', 'baldo'], // Slot 0 = Operated Leader
      swapModalSlot: null,                      // null or 0..3
      detailOpen: false,
      detailOpenedAt: -10,
      detailCharId: 'aerin',
      editingSkillSlot: null,                   // null or 0..3
      editingSigilSlot: null,                   // null or 0..5
      hoverSkillId: null,
      hoverSigilId: null
    },

    // Character Mutable Builds (Skills & Sigils)
    builds: {},

    // Results Screen State
    results: {
      enteredAt: 0,
      elapsed: 0,
      skipped: false,
      clearTimeStr: '04:28.64',
      chestBurstSpawned: [false, false, false]
    },

    // Screen Transition Curtain
    transition: {
      active: false,
      startT: 0,
      duration: 0.56,
      targetScreen: null,
      onMidpoint: null,
      swapped: false
    }
  };

  function resetBuilds() {
    state.builds = {};
    for (const id of Object.keys(Data.CHARACTERS)) {
      const c = Data.CHARACTERS[id];
      state.builds[id] = {
        skills: c.defaultSkills.slice(),
        sigils: c.defaultSigils.slice()
      };
    }
  }

  function resetAll(forTour) {
    resetBuilds();
    state.t = 0;
    state.screen = 'title';
    state.screenEnteredAt = 0;
    state.prevScreen = 'title';

    state.title = {
      menuExpanded: false,
      menuExpandedAt: -1,
      selectedIndex: 0,
      settingsOpen: false
    };

    state.story = {
      lineIndex: 0,
      lineStartedAt: 0,
      autoMode: false,
      fastMode: false,
      openGlossaryTerm: null,
      chapterCardOpen: false,
      chapterCardAt: -1
    };

    state.quest = {
      difficulty: forTour ? 'normal' : 'extreme',
      selectedQuestId: forTour ? 'q_n1' : 'q_e1',
      tabChangedAt: -10,
      detailChangedAt: -10
    };

    // During tour, start Slot 4 as Rin so Act 4 showcases swapping Rin -> Baldo
    // before launching the canonical demo squad (艾琳、罗克、希娅、巴尔多)!
    state.party = {
      slots: forTour ? ['aerin', 'roke', 'sia', 'rin'] : ['aerin', 'roke', 'sia', 'baldo'],
      swapModalSlot: null,
      detailOpen: false,
      detailOpenedAt: -10,
      detailCharId: 'aerin',
      editingSkillSlot: null,
      editingSigilSlot: null,
      hoverSkillId: null,
      hoverSigilId: null
    };

    state.results = {
      enteredAt: 0,
      elapsed: 0,
      skipped: false,
      clearTimeStr: '04:28.64',
      chestBurstSpawned: [false, false, false]
    };

    state.transition = {
      active: false,
      startT: 0,
      duration: 0.56,
      targetScreen: null,
      onMidpoint: null,
      swapped: false
    };
  }

  function getSigilById(id) {
    return Data.SIGIL_CATALOG.find(s => s.id === id) || Data.SIGIL_CATALOG[0];
  }

  function getSkillById(charId, skillId) {
    const c = Data.CHARACTERS[charId];
    return c.skillPool.find(s => s.id === skillId) || c.skillPool[0];
  }

  function getSelectedQuest() {
    return Data.QUESTS.find(q => q.id === state.quest.selectedQuestId) || Data.QUESTS[4];
  }

  function computeCharStats(charId, override) {
    const c = Data.CHARACTERS[charId];
    const build = state.builds[charId];
    const skills = build.skills.slice();
    const sigils = build.sigils.slice();

    if (override) {
      if (override.skillSlot != null && override.skillId) {
        skills[override.skillSlot] = override.skillId;
      }
      if (override.sigilSlot != null && override.sigilId) {
        sigils[override.sigilSlot] = override.sigilId;
      }
    }

    // Aggregate stacked sigil traits (also track source count so stacking is unmistakably visible!)
    const traitTotals = {};
    const traitCounts = {};
    for (const sigId of sigils) {
      const s = getSigilById(sigId);
      traitTotals[s.trait] = (traitTotals[s.trait] || 0) + s.level;
      traitCounts[s.trait] = (traitCounts[s.trait] || 0) + 1;
      if (s.secondTrait) {
        traitTotals[s.secondTrait.trait] = (traitTotals[s.secondTrait.trait] || 0) + s.secondTrait.level;
        traitCounts[s.secondTrait.trait] = (traitCounts[s.secondTrait.trait] || 0) + 1;
      }
    }
    // Clamp to trait maxLv
    for (const tid of Object.keys(traitTotals)) {
      const def = Data.TRAITS[tid];
      if (def) traitTotals[tid] = Math.min(def.maxLv, traitTotals[tid]);
    }

    let atk = c.baseStats.atk + c.weapon.atkBonus;
    let hp = c.baseStats.hp;
    let crit = c.baseStats.crit;
    let stun = c.baseStats.stun;
    let power = 1360 + c.level * 16;

    // Skill bonuses
    for (const sid of skills) {
      const sk = getSkillById(charId, sid);
      atk += sk.atkMod;
      crit += sk.critMod;
      stun += sk.stunMod;
      power += Math.round(sk.powerBonus * 0.85);
    }

    // Stacked Trait bonuses
    for (const tid of Object.keys(traitTotals)) {
      const lv = traitTotals[tid];
      const def = Data.TRAITS[tid];
      if (!def) continue;
      if (def.atkPerLv) atk += Math.round(def.atkPerLv * lv);
      if (def.hpPerLv) hp += Math.round(def.hpPerLv * lv);
      if (def.critPerLv) crit += def.critPerLv * lv;
      if (def.stunPerLv) stun += Math.round(def.stunPerLv * lv);
      if (def.pwrPerLv) power += Math.round(def.pwrPerLv * lv * 0.72);
    }

    crit = Math.min(100, Math.round(crit * 10) / 10);
    return { atk, hp, crit, stun, power, traitTotals, traitCounts };
  }

  function computePartyPower() {
    let total = 0;
    for (const cid of state.party.slots) {
      total += computeCharStats(cid).power;
    }
    return total;
  }

  function startTransition(targetScreen, onMidpoint) {
    if (state.exportMode) {
      // Short crisp transition driven strictly by clock
      state.transition = {
        active: true,
        startT: state.t,
        duration: 0.44,
        targetScreen,
        onMidpoint: onMidpoint || null,
        swapped: false
      };
      return;
    }
    state.transition = {
      active: true,
      startT: state.t,
      duration: 0.48,
      targetScreen,
      onMidpoint: onMidpoint || null,
      swapped: false
    };
  }

  function jumpDirect(targetScreen) {
    state.transition.active = false;
    state.prevScreen = state.screen;
    state.screen = targetScreen;
    state.screenEnteredAt = state.t;
  }

  resetAll(false);

  return {
    state,
    resetAll,
    resetBuilds,
    getSigilById,
    getSkillById,
    getSelectedQuest,
    computeCharStats,
    computePartyPower,
    startTransition,
    jumpDirect
  };
})();
