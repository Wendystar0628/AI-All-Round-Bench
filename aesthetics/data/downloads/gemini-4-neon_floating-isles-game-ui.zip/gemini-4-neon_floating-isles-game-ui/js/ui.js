/* ==========================================================================
   《浮空群岛传说》 — UI Renderer, Interactive Controller & Frame Updater
   All 7 Screens unified under one deterministic rendering architecture
   ========================================================================== */

window.SkyUI = window.SkyUI || {};

window.SkyUI.UI = (function () {
  const Data = window.SkyUI.Data;
  const Icons = window.SkyUI.Icons;
  const State = window.SkyUI.State;
  const Battle = window.SkyUI.Battle;
  const Backdrop = window.SkyUI.Backdrop;

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  // Track last rendered keys to avoid redundant DOM rebuilds during 60fps loop
  let lastBattleStaticKey = '';
  let lastStoryKey = '';
  let lastResultsStaticKey = '';
  let lastPickerKey = '';

  function clamp01(v) { return Math.max(0, Math.min(1, v)); }
  function easeOutCubic(p) { return 1 - Math.pow(1 - clamp01(p), 3); }
  function easeOutBack(p) {
    const c1 = 1.70158, c3 = c1 + 1;
    const x = clamp01(p) - 1;
    return 1 + c3 * x * x * x + c1 * x * x;
  }

  function elBadgeHtml(elKey, extraLabel) {
    const m = Icons.ELEMENT_META[elKey] || Icons.ELEMENT_META.wind;
    return `<span class="el-badge ${m.cls}">${Icons.element(elKey)}<span>${extraLabel || m.zh}</span></span>`;
  }

  /* ------------------------------------------------------------------------
     Screen Switching & Directory Sync
     ------------------------------------------------------------------------ */
  function syncActiveScreenDom() {
    const cur = State.state.screen;
    $$('.screen').forEach(el => {
      el.classList.toggle('active', el.id === 'screen-' + cur);
    });
    syncDirectoryHighlight();
  }

  function syncDirectoryHighlight() {
    const cur = State.state.screen;
    const isOugi = cur === 'battle' && Battle.state.ougiSeq.active;
    $$('.dir-btn').forEach(btn => {
      const target = btn.dataset.nav;
      const active = isOugi ? (target === 'ougi') : (target === cur);
      btn.classList.toggle('active', active);
    });
  }

  function navigateTo(target, instant) {
    const go = () => {
      State.state.party.detailOpen = false;
      State.state.party.swapModalSlot = null;
      State.state.story.openGlossaryTerm = null;
      State.state.title.settingsOpen = false;

      if (target === 'ougi') {
        State.jumpDirect('battle');
        Battle.initBattle(true);
        lastBattleStaticKey = '';
      } else if (target === 'battle') {
        State.jumpDirect('battle');
        Battle.initBattle(false);
        lastBattleStaticKey = '';
      } else if (target === 'results') {
        State.jumpDirect('results');
        enterResults();
      } else if (target === 'story') {
        State.jumpDirect('story');
        enterStory();
      } else if (target === 'quest') {
        State.jumpDirect('quest');
        State.state.quest.tabChangedAt = State.state.t;
        State.state.quest.detailChangedAt = State.state.t;
        renderQuestScreen();
      } else if (target === 'party') {
        State.jumpDirect('party');
        renderPartyScreen();
      } else {
        State.jumpDirect('title');
        renderTitleScreen();
      }
      syncActiveScreenDom();
    };

    if (instant) {
      go();
    } else {
      State.startTransition(target === 'ougi' ? 'battle' : target, go);
    }
  }

  function goBack() {
    const s = State.state;
    if (s.screen === 'title' && s.title.settingsOpen) {
      s.title.settingsOpen = false;
      renderTitleScreen();
      return;
    }
    if (s.screen === 'story') {
      if (s.story.openGlossaryTerm) {
        s.story.openGlossaryTerm = null;
        renderStoryFrame();
      } else if (s.story.chapterCardOpen) {
        s.story.chapterCardOpen = false;
        renderStoryFrame();
      } else {
        navigateTo('title');
      }
      return;
    }
    if (s.screen === 'quest') {
      navigateTo('title');
      return;
    }
    if (s.screen === 'party') {
      if (s.party.swapModalSlot !== null) {
        s.party.swapModalSlot = null;
        renderPartyScreen();
      } else if (s.party.editingSkillSlot !== null || s.party.editingSigilSlot !== null) {
        s.party.editingSkillSlot = null;
        s.party.editingSigilSlot = null;
        s.party.hoverSkillId = null;
        s.party.hoverSigilId = null;
        renderCharDetail();
      } else if (s.party.detailOpen) {
        s.party.detailOpen = false;
        renderPartyScreen();
      } else {
        navigateTo('quest');
      }
      return;
    }
    if (s.screen === 'battle') {
      navigateTo('party');
      return;
    }
    if (s.screen === 'results') {
      navigateTo('quest');
    }
  }

  /* ------------------------------------------------------------------------
     SCREEN 1: 标题画面 (Title Screen)
     ------------------------------------------------------------------------ */
  function renderTitleScreen() {
    const ts = State.state.title;
    const pak = $('#title-pak');
    const menu = $('#title-menu');
    const modal = $('#settings-modal');

    if (pak) pak.style.display = ts.menuExpanded ? 'none' : 'flex';
    if (menu) {
      menu.style.display = ts.menuExpanded ? 'flex' : 'none';
      $$('.title-menu-item').forEach((el, idx) => {
        el.classList.toggle('is-selected', idx === ts.selectedIndex);
      });
    }
    if (modal) {
      modal.classList.toggle('open', ts.settingsOpen);
      if (ts.settingsOpen) renderSettingsBody();
    }
  }

  function renderSettingsBody() {
    const st = State.state.settings;
    const rows = [
      { key: 'vfx', label: '画面动效强度', desc: '调整战斗光影、奥义演出与粒子密度', opts: ['标准', '高', '极致'] },
      { key: 'dmgNums', label: '战斗伤害数字', desc: '显示普通、暴击与弱点属性伤害跳字', opts: ['关闭', '开启'] },
      { key: 'hints', label: '战斗机制提示', desc: '超载、破防与奥义就绪时展示视觉引导', opts: ['关闭', '开启'] },
      { key: 'volume', label: '主音量预设', desc: '控制界面反馈与演出氛围音量比例', opts: ['50%', '80%', '100%'] }
    ];
    $('#settings-rows').innerHTML = rows.map(r => `
      <div class="settings-row">
        <div>
          <div class="s-label">${r.label}</div>
          <div class="s-desc">${r.desc}</div>
        </div>
        <div class="seg-group">
          ${r.opts.map(o => `<button class="seg-btn ${st[r.key] === o ? 'active' : ''}" data-setkey="${r.key}" data-setval="${o}">${o}</button>`).join('')}
        </div>
      </div>
    `).join('');
  }

  function updateTitleFrame(t) {
    const age = Math.max(0, t - State.state.screenEnteredAt);
    const hero = $('.title-hero');
    const pak = $('#title-pak');
    const menu = $('#title-menu');
    const ts = State.state.title;

    if (hero) {
      // Begin gracefully emerging even at Frame 0 (t=0) so Frame 0 is immediately composed!
      const p = easeOutCubic(age / 1.15);
      const lift = ts.menuExpanded ? -28 * easeOutCubic((t - ts.menuExpandedAt) / 0.45) : 0;
      hero.style.opacity = (0.35 + 0.65 * p).toFixed(3);
      hero.style.transform = `translateY(${((1 - p) * 26 + lift).toFixed(1)}px) scale(${(0.96 + 0.04 * p).toFixed(4)})`;
      const logoZh = hero.querySelector('.title-logo-zh');
      if (logoZh) {
        const sweep = ((t * 28) % 200) - 50;
        logoZh.style.backgroundPosition = `${sweep.toFixed(1)}% 50%`;
      }
    }

    if (pak && !ts.menuExpanded) {
      const fadeIn = easeOutCubic((age - 0.45) / 0.65);
      const pulse = 0.62 + 0.38 * Math.sin(t * 3.1);
      pak.style.opacity = (fadeIn * pulse).toFixed(3);
    }

    if (menu && ts.menuExpanded) {
      const mAge = Math.max(0, t - ts.menuExpandedAt);
      const items = $$('.title-menu-item');
      items.forEach((item, idx) => {
        const ip = easeOutCubic((mAge - idx * 0.08) / 0.36);
        item.style.opacity = ip.toFixed(3);
        item.style.transform = `translateY(${((1 - ip) * 18).toFixed(1)}px)`;
      });
    }
  }

  function expandTitleMenu() {
    if (State.state.title.menuExpanded) return;
    State.state.title.menuExpanded = true;
    State.state.title.menuExpandedAt = State.state.t;
    State.state.title.selectedIndex = 0;
    Backdrop.spawnFx({
      type: 'ring', birthT: State.state.t, duration: 0.7,
      x: 960, y: 690, maxR: 300, color: '#ffe699'
    });
    renderTitleScreen();
  }

  function activateTitleChoice(idx) {
    State.state.title.selectedIndex = idx;
    if (idx === 2) {
      State.state.title.settingsOpen = true;
      renderTitleScreen();
      return;
    }
    if (idx === 1) {
      // New game resets builds cleanly
      State.resetBuilds();
    }
    Backdrop.spawnFx({
      type: 'burst', birthT: State.state.t, duration: 0.65,
      x: 960, y: 690, maxR: 260, count: 18, color: '#ffe699', seed: 12
    });
    navigateTo('story');
  }

  /* ------------------------------------------------------------------------
     SCREEN 2: 剧情画面 (Story Screen & Chapter Title Card)
     ------------------------------------------------------------------------ */
  function enterStory() {
    const st = State.state.story;
    st.lineIndex = 0;
    st.lineStartedAt = State.state.t;
    st.openGlossaryTerm = null;
    st.chapterCardOpen = false;
    st.chapterCardAt = -1;
    lastStoryKey = '';
    renderStoryFrame();
  }

  function getStoryPlainLength(line) {
    let total = 0;
    for (const seg of line.segments) {
      total += (seg.term || seg.text || '').length;
    }
    return total;
  }

  function buildRevealedSegmentsHtml(line, visibleChars, openTerm) {
    let rem = visibleChars;
    let html = '';
    for (const seg of line.segments) {
      if (rem <= 0) break;
      if (seg.term) {
        const str = seg.term;
        const slice = str.slice(0, rem);
        rem -= str.length;
        const isOpen = openTerm === seg.term;
        html += `<span class="lore-term ${isOpen ? 'is-open' : ''}" data-term="${seg.term}">${slice}</span>`;
      } else {
        const str = seg.text;
        const slice = str.slice(0, rem);
        rem -= str.length;
        html += slice;
      }
    }
    return html;
  }

  function advanceStory() {
    const st = State.state.story;
    if (st.chapterCardOpen) {
      navigateTo('quest');
      return;
    }
    if (st.openGlossaryTerm) {
      st.openGlossaryTerm = null;
      lastStoryKey = '';
      renderStoryFrame();
      return;
    }
    const line = Data.STORY_SCRIPT[st.lineIndex];
    const speed = st.fastMode ? 96 : 36;
    const revealed = Math.floor((State.state.t - st.lineStartedAt) * speed);
    const total = getStoryPlainLength(line);

    if (revealed < total) {
      // Snap full text immediately
      st.lineStartedAt = State.state.t - 10;
      lastStoryKey = '';
      renderStoryFrame();
      return;
    }

    if (st.lineIndex < Data.STORY_SCRIPT.length - 1) {
      st.lineIndex++;
      st.lineStartedAt = State.state.t;
      lastStoryKey = '';
      renderStoryFrame();
    } else {
      openChapterCard();
    }
  }

  function openChapterCard() {
    const st = State.state.story;
    st.openGlossaryTerm = null;
    st.chapterCardOpen = true;
    st.chapterCardAt = State.state.t;
    Backdrop.spawnFx({
      type: 'ring', birthT: State.state.t, duration: 1.0,
      x: 960, y: 540, maxR: 540, color: '#ffe699'
    });
    renderStoryFrame();
  }

  function renderStoryFrame() {
    const st = State.state.story;
    const t = State.state.t;
    const line = Data.STORY_SCRIPT[st.lineIndex] || Data.STORY_SCRIPT[0];
    const speaker = Data.CHARACTERS[line.speakerId];
    const elMeta = Icons.ELEMENT_META[speaker.element];

    const speed = st.fastMode ? 96 : 36;
    const totalChars = getStoryPlainLength(line);
    const visChars = Math.min(totalChars, Math.max(1, Math.floor((t - st.lineStartedAt) * speed)));

    // Auto-advance when in autoMode (interactive mode only)
    if (!State.state.exportMode && st.autoMode && !st.openGlossaryTerm && !st.chapterCardOpen) {
      const doneAt = st.lineStartedAt + totalChars / speed + (st.fastMode ? 0.55 : 1.85);
      if (t >= doneAt) {
        advanceStory();
        return;
      }
    }

    const key = `${st.lineIndex}|${visChars}|${st.openGlossaryTerm || ''}|${st.autoMode}|${st.fastMode}|${st.chapterCardOpen}`;
    if (key !== lastStoryKey) {
      lastStoryKey = key;

      $('#story-loc-en').textContent = line.locationEn;
      $('#story-loc-zh').textContent = line.locationZh;

      $('#story-auto-btn').classList.toggle('active', st.autoMode);
      $('#story-fast-btn').classList.toggle('active', st.fastMode);

      // Speaker crest
      const stageEl = $('#story-speaker-stage');
      stageEl.className = 'story-speaker-crest-stage ' + elMeta.cls;
      $('#story-crest-core').innerHTML = Icons.weapon(speaker.weaponType, elMeta.glow);
      $('#story-speaker-meta').innerHTML = `${elBadgeHtml(speaker.element)} <span>${speaker.title}</span>`;

      // Nameplate
      const np = $('#story-nameplate');
      np.className = 'story-nameplate ' + elMeta.cls;
      $('#story-sp-name').textContent = speaker.name;
      $('#story-sp-role').textContent = `${speaker.enName} · ${speaker.weaponType}`;

      // Typewriter text with clickable lore terms
      $('#story-text').innerHTML = buildRevealedSegmentsHtml(line, visChars, st.openGlossaryTerm);

      // Progress dots
      $('#story-dots').innerHTML = Data.STORY_SCRIPT.map((_, i) =>
        `<span class="story-dot ${i < st.lineIndex ? 'done' : i === st.lineIndex ? 'active' : ''}"></span>`
      ).join('');

      // Glossary Popover
      const gp = $('#glossary-popover');
      if (st.openGlossaryTerm && Data.GLOSSARY[st.openGlossaryTerm]) {
        const g = Data.GLOSSARY[st.openGlossaryTerm];
        gp.classList.add('open');
        $('#gloss-cat').textContent = g.category;
        $('#gloss-term').textContent = g.term;
        $('#gloss-en').textContent = g.en;
        $('#gloss-body').textContent = g.body;
      } else {
        gp.classList.remove('open');
      }
    }

    // Smooth speaker-switch & chapter card kinetic transforms every frame
    const lineAge = Math.max(0, t - st.lineStartedAt);
    const spIn = easeOutCubic(lineAge / 0.35);
    const stageEl = $('#story-speaker-stage');
    if (stageEl) {
      stageEl.style.opacity = (st.chapterCardOpen ? 0 : spIn).toFixed(3);
      stageEl.style.transform = `translateX(-50%) translateY(${((1 - spIn) * 16).toFixed(1)}px)`;
    }

    const caret = $('.story-next-caret');
    if (caret) {
      caret.style.transform = `rotate(45deg) translate(${(Math.sin(t * 5) * 3).toFixed(1)}px, ${(Math.sin(t * 5) * 3).toFixed(1)}px)`;
    }

    // Chapter Title Card overlay
    const card = $('#chapter-card');
    card.classList.toggle('open', st.chapterCardOpen);
    if (st.chapterCardOpen) {
      const cAge = Math.max(0, t - st.chapterCardAt);
      const p1 = easeOutCubic(cAge / 0.55);
      const p2 = easeOutCubic((cAge - 0.22) / 0.65);
      card.style.opacity = p1.toFixed(3);
      const rule = $('.chapter-rule');
      if (rule) rule.style.transform = `scaleX(${p2.toFixed(3)})`;
      const titleZh = $('.chapter-title-zh');
      if (titleZh) {
        titleZh.style.opacity = p2.toFixed(3);
        titleZh.style.transform = `translateY(${((1 - p2) * 20).toFixed(1)}px)`;
      }
      const ring = $('.chapter-ring-bg');
      if (ring) ring.style.transform = `rotate(${(cAge * 12).toFixed(2)}deg) scale(${(0.88 + 0.12 * p1).toFixed(3)})`;
    }
  }

  /* ------------------------------------------------------------------------
     SCREEN 3: 任务柜台 (Quest Counter)
     ------------------------------------------------------------------------ */
  function renderQuestScreen() {
    const qs = State.state.quest;
    const partyPwr = State.computePartyPower();
    $('#quest-party-pwr').textContent = partyPwr.toLocaleString();

    // Difficulty Tabs
    const diffs = [
      { id: 'normal',  zh: '普通', en: 'NORMAL',  stars: '★★',   cls: '' },
      { id: 'hard',    zh: '困难', en: 'HARD',    stars: '★★★',  cls: '' },
      { id: 'extreme', zh: '极难', en: 'EXTREME', stars: '★★★★', cls: 'diff-extreme' },
      { id: 'legend',  zh: '传说', en: 'LEGEND',  stars: '★★★★★', cls: 'diff-legend' }
    ];
    $('#quest-diff-tabs').innerHTML = diffs.map(d => `
      <button class="diff-tab ${d.cls} ${qs.difficulty === d.id ? 'active' : ''}" data-diff="${d.id}">
        <span>${d.zh}</span>
        <span class="d-en">${d.en}</span>
        <span class="d-stars">${d.stars}</span>
      </button>
    `).join('');

    // Filtered Quest List
    const list = Data.QUESTS.filter(q => q.difficulty === qs.difficulty);
    if (!list.some(q => q.id === qs.selectedQuestId)) {
      qs.selectedQuestId = list[0].id;
    }

    $('#quest-list').innerHTML = list.map(q => {
      const sel = q.id === qs.selectedQuestId;
      return `
        <div class="quest-card ${sel ? 'selected' : ''}" data-qid="${q.id}">
          <div class="quest-type-emblem">${Icons.questType(q.type)}</div>
          <div>
            <div class="qc-top-meta">
              <span class="qc-type-pill">${q.type}</span>
              <span class="qc-loc">${q.location}</span>
            </div>
            <div class="qc-name">${q.name}</div>
            <div class="qc-rewards-mini">
              ${q.rewards.slice(0, 3).map(r => {
                const rm = Icons.RARITY_META[r.rarity];
                return `<span class="qc-reward-chip ${rm.cls}">${Icons.item(r.icon, rm.color)}<span>${r.name}</span></span>`;
              }).join('')}
            </div>
          </div>
          <div class="qc-power-col">
            <div class="qc-power-label">推荐战力</div>
            <div class="qc-power-num num">${q.recPower.toLocaleString()}</div>
          </div>
        </div>
      `;
    }).join('');

    // Selected Quest Detail Panel
    const q = State.getSelectedQuest();
    const diffPillCls = q.difficulty === 'extreme' ? 'extreme' : q.difficulty === 'legend' ? 'legend' : '';
    const isSufficient = partyPwr >= q.recPower;
    const maxScale = Math.max(partyPwr, q.recPower) * 1.18;
    const partyPct = Math.min(100, (partyPwr / maxScale) * 100);
    const recPct = Math.min(96, (q.recPower / maxScale) * 100);

    const bossBlock = q.boss ? `
      <div class="qd-boss-card">
        <div class="qd-boss-left">
          <div class="el-icon-circle ${Icons.ELEMENT_META[q.boss.element].cls}">${Icons.element(q.boss.element)}</div>
          <div>
            <div class="qd-boss-name">${q.boss.title}「${q.boss.name}」</div>
            <div class="qd-boss-sub">Lv.${q.boss.level} · ${q.boss.epithet || q.boss.note || '核心讨伐目标'}</div>
          </div>
        </div>
        <div class="qd-boss-badges">
          ${elBadgeHtml(q.boss.element, '属性 ' + Icons.ELEMENT_META[q.boss.element].zh)}
          ${elBadgeHtml(q.boss.weakness, '弱点 ' + Icons.ELEMENT_META[q.boss.weakness].zh)}
        </div>
      </div>
    ` : `
      <div class="qd-boss-card" style="border-color: rgba(53, 197, 235, 0.45);">
        <div class="qd-boss-left">
          <div class="el-icon-circle ${Icons.ELEMENT_META[q.targetSummary.element].cls}">${Icons.element(q.targetSummary.element)}</div>
          <div>
            <div class="qd-boss-name">${q.targetSummary.label}</div>
            <div class="qd-boss-sub">${q.targetSummary.note}</div>
          </div>
        </div>
        <div class="qd-boss-badges">
          ${elBadgeHtml(q.targetSummary.element, '属性 ' + Icons.ELEMENT_META[q.targetSummary.element].zh)}
          ${elBadgeHtml(q.targetSummary.weakness, '弱点 ' + Icons.ELEMENT_META[q.targetSummary.weakness].zh)}
        </div>
      </div>
    `;

    $('#quest-detail').innerHTML = `
      <div class="corner-filigree"></div>
      <div class="qd-head">
        <div>
          <div class="qd-diff-pill ${diffPillCls}">${q.diffLabel} · ${q.stars}</div>
          <div class="qd-title">${q.name}</div>
          <div class="qd-subtitle">${q.enName}</div>
        </div>
        <div style="text-align:right">
          <div style="font-size:12px;color:var(--ink-soft);font-weight:700;">任务类型</div>
          <div style="font-size:18px;font-weight:800;color:var(--ink-dark);margin-top:2px;">${q.type}</div>
        </div>
      </div>

      <div class="qd-meta-grid">
        <div class="qd-meta-box"><div class="mk">讨伐地点</div><div class="mv">${q.location}</div></div>
        <div class="qd-meta-box"><div class="mk">限制时间</div><div class="mv num">${q.timeLimit}</div></div>
        <div class="qd-meta-box"><div class="mk">推荐战力</div><div class="mv num">${q.recPower.toLocaleString()}</div></div>
      </div>

      <div class="qd-section-label">目标说明 · MISSION OBJECTIVE</div>
      <div class="qd-objective">${q.objective}</div>

      <div class="qd-section-label">主要讨伐目标 · TARGET INTEL</div>
      ${bossBlock}

      <div class="qd-section-label">可能获得的奖励 · POTENTIAL REWARDS</div>
      <div class="qd-rewards-grid">
        ${q.rewards.map(r => {
          const rm = Icons.RARITY_META[r.rarity];
          return `
            <div class="qd-reward-tile ${rm.cls}">
              ${Icons.item(r.icon, rm.color)}
              <div>
                <div class="rt-name">${r.name}</div>
                <div class="rt-rar">[${rm.zh}] 稀有掉落</div>
              </div>
            </div>
          `;
        }).join('')}
      </div>

      <div class="qd-footer">
        <div class="power-compare">
          <div class="pc-row">
            <div class="pc-pair">
              <div class="pc-item"><span class="pkl">推荐战力</span><span class="pkv num">${q.recPower.toLocaleString()}</span></div>
              <div class="pc-item party ${isSufficient ? '' : 'warn'}"><span class="pkl">当前队伍</span><span class="pkv num">${partyPwr.toLocaleString()}</span></div>
            </div>
            <span class="pc-status ${isSufficient ? '' : 'warn'}">${isSufficient ? '战力充足 · 胜算极高' : '极具挑战 · 建议整备'}</span>
          </div>
          <div class="pc-bar-track">
            <div class="pc-bar-fill ${isSufficient ? '' : 'warn'}" style="width:${partyPct.toFixed(1)}%"></div>
            <div class="pc-bar-rec-mark" style="left:${recPct.toFixed(1)}%"></div>
          </div>
        </div>
        <button class="btn-gilded" id="quest-depart-btn">
          <span>出发</span>
          <span class="btn-sub">DEPART</span>
        </button>
      </div>
    `;
  }

  /* ------------------------------------------------------------------------
     SCREEN 4: 编队与角色养成 (Party Formation & Character Growth)
     ------------------------------------------------------------------------ */
  function renderPartyScreen() {
    const ps = State.state.party;
    const q = State.getSelectedQuest();
    const totalPwr = State.computePartyPower();
    const diff = totalPwr - q.recPower;

    $('#party-quest-name').textContent = q.name;
    $('#party-quest-meta').textContent = `${q.location} · ${q.type}`;

    // 4 Party Slots
    $('#party-slots').innerHTML = ps.slots.map((cid, idx) => {
      const c = Data.CHARACTERS[cid];
      const stats = State.computeCharStats(cid);
      const el = Icons.ELEMENT_META[c.element];
      const isLeader = idx === 0;
      const build = State.state.builds[cid];
      const sk0 = State.getSkillById(cid, build.skills[0]);
      const sk1 = State.getSkillById(cid, build.skills[1]);

      return `
        <div class="party-slot-card ${el.cls} ${isLeader ? 'is-leader' : ''}" data-slot="${idx}">
          <div class="psc-element-bar"></div>
          <div class="psc-watermark">${Icons.element(c.element)}</div>
          <div class="psc-top">
            <span class="psc-slot-num">SLOT 0${idx + 1}</span>
            ${isLeader
              ? `<span class="psc-leader-badge">${Icons.crownSvg()}<span>操作角色</span></span>`
              : `<span class="psc-ai-badge">AI 队友</span>`}
          </div>

          <div class="psc-crest-hero">
            <div class="psc-crest-ring">
              <div class="weapon-icon">${Icons.weapon(c.weaponType, el.glow)}</div>
              <div class="el-mini">${Icons.element(c.element)}</div>
            </div>
          </div>

          <div class="psc-identity">
            <div class="psc-name">${c.name}</div>
            <div class="psc-tags">
              ${elBadgeHtml(c.element)}
              <span class="psc-weapon-pill">${c.weaponType}</span>
            </div>
          </div>

          <div class="psc-stats-strip">
            <div class="psc-stat-cell lv"><div class="k">等级 LEVEL</div><div class="v num">Lv.${c.level}</div></div>
            <div class="psc-stat-cell"><div class="k">角色战力 PWR</div><div class="v num">${stats.power.toLocaleString()}</div></div>
          </div>

          <div class="psc-mini-loadout">
            <div>武器：<strong>${c.weapon.name}</strong> <span class="num" style="color:var(--gold-bright);">Lv.${c.weapon.level}</span></div>
            <div style="margin-top:5px;">奥义：<strong style="color:var(--el-glow);">${c.ougi.name}</strong></div>
            <div style="margin-top:5px;">主力技能：<strong>${sk0.name}</strong> / <strong>${sk1.name}</strong></div>
          </div>

          <div class="psc-sigil-bar">
            <span class="psc-sigil-lbl">徽印配置</span>
            <div class="psc-sigil-gems">
              ${build.sigils.map(sigId => {
                const sg = State.getSigilById(sigId);
                return `<span class="psc-gem rar-${sg.rarity}" title="${sg.name}"></span>`;
              }).join('')}
            </div>
          </div>

          <div class="psc-actions">
            <button class="psc-btn" data-swap-slot="${idx}">更换角色</button>
            <button class="psc-btn primary" data-detail-char="${cid}">角色养成</button>
          </div>
        </div>
      `;
    }).join('');

    // Footer Power Comparison
    $('#party-total-pwr').textContent = totalPwr.toLocaleString();
    $('#party-rec-pwr').textContent = q.recPower.toLocaleString();
    const deltaEl = $('#party-pwr-delta');
    deltaEl.className = 'ptp-delta num ' + (diff >= 0 ? '' : 'warn');
    deltaEl.textContent = diff >= 0
      ? `战力领先 +${diff.toLocaleString()} · 推荐出击`
      : `战力差额 ${diff.toLocaleString()} · 建议强化`;

    // Swap Modal
    const swapModal = $('#swap-modal');
    if (ps.swapModalSlot !== null) {
      swapModal.classList.add('open');
      $('#swap-modal-title').textContent = `选择 0${ps.swapModalSlot + 1} 号位出战角色`;
      const curCid = ps.slots[ps.swapModalSlot];
      $('#swap-roster-grid').innerHTML = Object.values(Data.CHARACTERS).map(c => {
        const st = State.computeCharStats(c.id);
        const el = Icons.ELEMENT_META[c.element];
        const inIdx = ps.slots.indexOf(c.id);
        const isCurrent = c.id === curCid;
        return `
          <div class="swap-char-card ${el.cls} ${isCurrent ? 'in-slot' : ''}" data-pick-char="${c.id}">
            <div class="swap-char-top">
              <div style="display:flex;align-items:center;gap:10px;">
                <div class="el-icon-circle ${el.cls}">${Icons.element(c.element)}</div>
                <div>
                  <div class="swap-char-name">${c.name}</div>
                  <div style="font-size:12px;color:rgba(245,239,226,0.68);">${c.weaponType} · ${c.title}</div>
                </div>
              </div>
              <span class="swap-status-tag ${inIdx >= 0 ? 'active' : ''}">${inIdx >= 0 ? (inIdx === 0 ? '操作中' : `编队 0${inIdx + 1}`) : '待命'}</span>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:baseline;padding-top:10px;border-top:1px solid rgba(255,255,255,0.08);">
              <span class="num" style="font-size:16px;color:var(--ivory-warm);">Lv.${c.level}</span>
              <span class="num" style="font-size:24px;font-weight:800;color:var(--gold-bright);">PWR ${st.power.toLocaleString()}</span>
            </div>
          </div>
        `;
      }).join('');
    } else {
      swapModal.classList.remove('open');
    }

    // Character Detail Overlay
    const detView = $('#char-detail-view');
    detView.classList.toggle('open', ps.detailOpen);
    if (ps.detailOpen) {
      renderCharDetail();
    }
  }

  function renderCharDetail() {
    const ps = State.state.party;
    const cid = ps.detailCharId;
    const c = Data.CHARACTERS[cid];
    const el = Icons.ELEMENT_META[c.element];
    const build = State.state.builds[cid];

    // Live stat diff preview calculation
    let previewOverride = null;
    if (ps.editingSkillSlot !== null && ps.hoverSkillId) {
      previewOverride = { skillSlot: ps.editingSkillSlot, skillId: ps.hoverSkillId };
    } else if (ps.editingSigilSlot !== null && ps.hoverSigilId) {
      previewOverride = { sigilSlot: ps.editingSigilSlot, sigilId: ps.hoverSigilId };
    }

    const base = State.computeCharStats(cid, null);
    const next = previewOverride ? State.computeCharStats(cid, previewOverride) : base;

    // Top character pills
    $('#cd-char-pills').innerHTML = Object.values(Data.CHARACTERS).map(ch => {
      const m = Icons.ELEMENT_META[ch.element];
      return `
        <button class="cd-char-pill ${m.cls} ${ch.id === cid ? 'active' : ''}" data-cd-char="${ch.id}">
          <span style="width:18px;height:18px;display:inline-flex;">${Icons.element(ch.element)}</span>
          <span>${ch.name}</span>
        </button>
      `;
    }).join('');

    // Helper for stat row with live diff
    const statRow = (label, curVal, nextVal, suffix = '') => {
      const d = Math.round((nextVal - curVal) * 10) / 10;
      const cls = d > 0 ? 'changed-up' : d < 0 ? 'changed-down' : '';
      const dHtml = d !== 0
        ? `<span class="cd-stat-delta num ${d > 0 ? 'up' : 'down'}">${d > 0 ? '▲ +' : '▼ '}${d}${suffix}</span>`
        : '';
      return `
        <div class="cd-stat-row ${cls}">
          <span class="cd-stat-name">${label}</span>
          <div class="cd-stat-val-wrap">
            <span class="cd-stat-val num">${nextVal.toLocaleString()}${suffix}</span>
            ${dHtml}
          </div>
        </div>
      `;
    };

    const expPct = Math.round((c.exp / c.expMax) * 100);
    $('#cd-left').innerHTML = `
      <div class="cd-hero-row ${el.cls}">
        <div class="cd-crest-lg">${Icons.weapon(c.weaponType, el.glow)}</div>
        <div>
          <div class="cd-name-lg">${c.name}</div>
          <div style="display:flex;align-items:center;gap:8px;margin-top:6px;">
            ${elBadgeHtml(c.element)}
            <span class="psc-weapon-pill">${c.weaponType}</span>
            <span class="num" style="font-size:18px;font-weight:800;color:var(--gold-bright);">Lv.${c.level}</span>
          </div>
        </div>
      </div>

      <div class="cd-exp-block">
        <div class="exp-row">
          <span>经验值 EXP</span>
          <span class="num">${c.exp.toLocaleString()} / ${c.expMax.toLocaleString()} (${expPct}%)</span>
        </div>
        <div class="cd-exp-bar"><div class="cd-exp-fill" style="width:${expPct}%"></div></div>
      </div>

      <div class="cd-stats-list">
        ${statRow('综合战力 PWR', base.power, next.power)}
        ${statRow('攻击力 ATK', base.atk, next.atk)}
        ${statRow('生命值 HP', base.hp, next.hp)}
        ${statRow('暴击率 CRIT', base.crit, next.crit, '%')}
        ${statRow('破防力 STUN', base.stun, next.stun)}
      </div>

      <div class="cd-weapon-box">
        <div class="cd-weapon-head">
          <span style="font-size:12px;letter-spacing:0.14em;color:rgba(245,239,226,0.65);">装备武器 · WEAPON</span>
          ${elBadgeHtml(c.weapon.element)}
        </div>
        <div style="display:flex;align-items:center;gap:12px;">
          <div style="width:42px;height:42px;flex-shrink:0;">${Icons.weapon(c.weaponType, el.glow)}</div>
          <div>
            <div class="cd-weapon-name">${c.weapon.name} <span class="num" style="font-size:15px;color:#fff;">Lv.${c.weapon.level}</span></div>
            <div style="font-size:12px;color:rgba(245,239,226,0.75);margin-top:3px;">攻击 +${c.weapon.atkBonus} · ${c.weapon.trait}</div>
          </div>
        </div>
      </div>
    `;

    // Center: 4 Skills + 6 Sigils
    $('#cd-skills-grid').innerHTML = build.skills.map((sid, idx) => {
      const sk = State.getSkillById(cid, sid);
      const editing = ps.editingSkillSlot === idx;
      return `
        <div class="cd-skill-slot ${el.cls} ${editing ? 'editing' : ''}" data-edit-skill="${idx}">
          <div class="cd-skill-icon">${Icons.skill(sk.icon, el.glow)}</div>
          <div>
            <div class="cd-skill-top">
              <span class="cd-skill-name">[${idx + 1}] ${sk.name}</span>
              <span class="cd-skill-cd num">CD ${sk.cd}s</span>
            </div>
            <div class="cd-skill-desc">${sk.desc}</div>
          </div>
        </div>
      `;
    }).join('');

    $('#cd-sigils-grid').innerHTML = build.sigils.map((sigId, idx) => {
      const sg = State.getSigilById(sigId);
      const rm = Icons.RARITY_META[sg.rarity];
      const t1 = Data.TRAITS[sg.trait];
      const t2 = sg.secondTrait ? Data.TRAITS[sg.secondTrait.trait] : null;
      const editing = ps.editingSigilSlot === idx;
      return `
        <div class="cd-sigil-slot ${rm.cls} ${editing ? 'editing' : ''}" data-edit-sigil="${idx}">
          <span class="rar-tag ${rm.cls} sigil-rar-corner">${rm.zh}</span>
          <div class="sigil-hex">${Icons.item('sigil', rm.color)}</div>
          <div class="sigil-info">
            <div class="sn">${sg.name}</div>
            <div class="st">${t1.name} +${sg.level}${t2 ? ` / ${t2.name} +${sg.secondTrait.level}` : ''}</div>
          </div>
        </div>
      `;
    }).join('');

    // Signature Character Ougi Card beneath Sigils (eliminates dead space & links Growth -> Battle!)
    const ougiCard = $('#cd-ougi-card');
    if (ougiCard) {
      ougiCard.className = 'cd-ougi-showcase ' + el.cls;
      ougiCard.innerHTML = `
        <div class="cdo-crest">${Icons.element(c.element)}</div>
        <div class="cdo-body">
          <div class="cdo-kicker">专属奥义 · SIGNATURE OUGI &amp; CHAIN SYNERGY</div>
          <div class="cdo-title-row">
            <span class="cdo-name">${c.ougi.name}</span>
            <span class="cdo-en">${c.ougi.enName}</span>
          </div>
          <div class="cdo-desc">${c.ougi.finisherName
            ? `作为首发释放全员连锁奥义时，激发${el.zh}属性终结技「${c.ougi.finisherName}」并重创首领模式槽。`
            : `衔接队友奥义形成高倍率连锁共鸣，大幅强化全员连锁终结技总伤害。`}</div>
        </div>
        <div class="cdo-right">
          ${elBadgeHtml(c.element, el.zh + '属性')}
        </div>
      `;
    }

    // Preserve scroll position of picker list across live hover preview re-renders for the same slot!
    const pickerKey = `${cid}|${ps.editingSkillSlot}|${ps.editingSigilSlot}`;
    const oldPicker = $('#cd-right-body .picker-list');
    const savedPickerScroll = (oldPicker && pickerKey === lastPickerKey) ? oldPicker.scrollTop : 0;
    lastPickerKey = pickerKey;

    // Right Column: Picker (if editing skill/sigil) + Always-visible Stacked Traits preview
    if (ps.editingSkillSlot !== null) {
      const curSid = build.skills[ps.editingSkillSlot];
      $('#cd-right-title').textContent = `更换技能槽 [${ps.editingSkillSlot + 1}]`;
      $('#cd-right-sub').textContent = '悬停预览属性变化 · 点击确认';
      $('#cd-right-body').innerHTML = `
        <div class="picker-list sky-scroll">
          ${c.skillPool.map(sk => {
            const isEq = sk.id === curSid;
            const isOther = !isEq && build.skills.includes(sk.id);
            return `
              <div class="picker-item ${isEq ? 'equipped' : ''} ${ps.hoverSkillId === sk.id ? 'is-hover' : ''}" data-pick-skill="${sk.id}">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:5px;">
                  <div style="display:flex;align-items:center;gap:10px;">
                    <span style="width:26px;height:26px;display:inline-flex;">${Icons.skill(sk.icon, el.glow)}</span>
                    <strong style="font-size:16px;">${sk.name}</strong>
                  </div>
                  <span class="cd-skill-cd num">CD ${sk.cd}s</span>
                </div>
                <div style="font-size:12px;color:rgba(245,239,226,0.72);line-height:1.45;">${sk.desc}</div>
                <div style="display:flex;justify-content:space-between;margin-top:6px;font-size:12px;color:var(--gold-bright);">
                  <span class="num">ATK +${sk.atkMod} · CRIT +${sk.critMod}% · STUN +${sk.stunMod}</span>
                  <span>${isEq ? '当前已装备' : isOther ? '已装备于其他槽' : '点击替换'}</span>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      `;
    } else if (ps.editingSigilSlot !== null) {
      const curSigId = build.sigils[ps.editingSigilSlot];
      // Show compact stacked trait preview at top + selectable sigil vault below!
      const allTraitKeys = Array.from(new Set([...Object.keys(base.traitTotals), ...Object.keys(next.traitTotals)]));
      const changedTraitsHtml = allTraitKeys.map(tid => {
        const bLv = base.traitTotals[tid] || 0;
        const nLv = next.traitTotals[tid] || 0;
        const delta = nLv - bLv;
        const def = Data.TRAITS[tid];
        if (!delta && bLv === 0) return '';
        return `
          <div style="display:flex;justify-content:space-between;font-size:12px;padding:4px 8px;background:${delta > 0 ? 'rgba(37,217,144,0.16)' : delta < 0 ? 'rgba(255,92,108,0.16)' : 'rgba(255,255,255,0.04)'};">
            <span>${def.name}</span>
            <span class="num" style="font-weight:800;color:${delta > 0 ? 'var(--emerald-up)' : delta < 0 ? 'var(--rose-down)' : 'var(--gold-bright)'};">
              Lv.${nLv}/${def.maxLv}${delta !== 0 ? ` (${delta > 0 ? '+' : ''}${delta})` : ''}
            </span>
          </div>
        `;
      }).join('');

      $('#cd-right-title').textContent = `镶嵌徽印 · 槽位 0${ps.editingSigilSlot + 1}`;
      $('#cd-right-sub').textContent = '同类特性自动叠加';
      $('#cd-right-body').innerHTML = `
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:12px;padding:8px;background:rgba(6,12,26,0.7);border:1px solid rgba(230,184,86,0.28);">
          ${changedTraitsHtml}
        </div>
        <div class="picker-list sky-scroll">
          ${Data.SIGIL_CATALOG.map(sg => {
            const rm = Icons.RARITY_META[sg.rarity];
            const t1 = Data.TRAITS[sg.trait];
            const t2 = sg.secondTrait ? Data.TRAITS[sg.secondTrait.trait] : null;
            const isEq = sg.id === curSigId;
            return `
              <div class="picker-item ${rm.cls} ${isEq ? 'equipped' : ''} ${ps.hoverSigilId === sg.id ? 'is-hover' : ''}" data-pick-sigil="${sg.id}" style="border-color:var(--rar-border);">
                <div style="display:flex;align-items:center;justify-content:space-between;">
                  <div style="display:flex;align-items:center;gap:9px;">
                    <span class="rar-tag ${rm.cls}">${rm.zh}</span>
                    <strong style="font-size:15px;">${sg.name}</strong>
                  </div>
                  <span style="font-size:12px;color:var(--rar-color);">${isEq ? '已镶嵌' : '替换'}</span>
                </div>
                <div style="font-size:12px;color:rgba(245,239,226,0.8);margin-top:5px;">
                  ${t1.name} <span class="num" style="color:var(--gold-bright);">+Lv.${sg.level}</span>
                  ${t2 ? ` &nbsp;·&nbsp; ${t2.name} <span class="num" style="color:var(--cyan-bright);">+Lv.${sg.secondTrait.level}</span>` : ''}
                </div>
              </div>
            `;
          }).join('')}
        </div>
      `;
    } else {
      // Default: Full Stacked Trait Summary
      $('#cd-right-title').textContent = '全身特性汇总';
      $('#cd-right-sub').textContent = '同类自动叠加总等级';
      const sortedTraits = Object.keys(next.traitTotals).sort((a, b) => next.traitTotals[b] - next.traitTotals[a]);
      $('#cd-right-body').innerHTML = `
        <div class="trait-summary-list sky-scroll">
          ${sortedTraits.map(tid => {
            const lv = next.traitTotals[tid];
            const cnt = next.traitCounts[tid] || 1;
            const def = Data.TRAITS[tid];
            const pct = Math.min(100, (lv / def.maxLv) * 100);
            return `
              <div class="trait-row ${cnt > 1 ? 'stacked' : ''}">
                <div class="trait-head">
                  <span class="trait-name">${def.name}${cnt > 1 ? `<span class="trait-stack-pill">×${cnt} 叠加</span>` : ''}</span>
                  <span class="trait-lv num">Lv.${lv} <small style="font-size:13px;opacity:0.55;">/ ${def.maxLv}</small></span>
                </div>
                <div class="trait-bar-track"><div class="trait-bar-fill" style="width:${pct.toFixed(1)}%"></div></div>
                <div class="trait-effect">${def.desc}</div>
              </div>
            `;
          }).join('')}
        </div>
      `;
    }

    const newPicker = $('#cd-right-body .picker-list');
    if (newPicker && savedPickerScroll > 0) {
      newPicker.scrollTop = savedPickerScroll;
    }
  }

  /* ------------------------------------------------------------------------
     SCREEN 5 & 6: 战斗画面 + 奥义与连锁奥义 (Battle HUD & Cut-ins)
     ------------------------------------------------------------------------ */
  function buildBattleStaticDom() {
    const slots = State.state.party.slots;
    const selQ = State.getSelectedQuest();
    const key = slots.join(',') + '|' + State.state.builds[slots[0]].skills.join(',') + '|' + selQ.id;
    if (key === lastBattleStaticKey) return;
    lastBattleStaticKey = key;

    // Sync Quest Banner dynamically
    const bqn = $('#battle-quest-name');
    const bql = $('#battle-quest-loc');
    if (bqn) bqn.textContent = selQ.name;
    if (bql) bql.textContent = selQ.location;

    // Boss static header
    const boss = Data.BOSS_IGNIS;
    $('#boss-name-hud').textContent = boss.name;
    $('#boss-lv-hud').textContent = 'Lv.' + boss.level;
    $('#boss-el-badge').innerHTML = elBadgeHtml(boss.element, '火属性');
    $('#boss-weak-badge').innerHTML = `${Icons.element(boss.weakness)}<span>WEAK 水</span>`;
    $('#boss-layer-pips').innerHTML = Array.from({ length: boss.maxLayers }, (_, i) =>
      `<span class="boss-layer-pip" id="boss-pip-${i}"></span>`
    ).join('');

    // Party HUD (Link Buff Strip + 3 Allies above + Operated Leader prominent at bottom)
    const linkStripHtml = `
      <div class="party-link-buff-strip" id="party-link-buff-strip" style="display:none;">
        <span>✦ 连携时刻强化中 · LINK TIME</span>
        <span class="num">ATK+30% · CRIT+25% · CD↑</span>
      </div>
    `;
    const alliesHtml = linkStripHtml + [1, 2, 3].map(idx => {
      const c = Data.CHARACTERS[slots[idx]];
      const el = Icons.ELEMENT_META[c.element];
      return `
        <div class="ally-mini-row ${el.cls}" id="ally-row-${idx}">
          <div class="el-icon-circle ${el.cls}" style="width:30px;height:30px;">${Icons.element(c.element)}</div>
          <div class="ally-name-wrap"><span class="an">${c.name}</span><span class="alv num">Lv.${c.level}</span></div>
          <div class="ally-bars">
            <div class="hp-track"><div class="hp-fill" id="ally-hp-${idx}" style="width:100%"></div></div>
            <div class="ougi-track"><div class="ougi-fill" id="ally-ougi-bar-${idx}" style="width:35%"></div></div>
          </div>
          <div class="ally-ougi-pct num" id="ally-ougi-pct-${idx}">35%</div>
        </div>
      `;
    }).join('');

    const leader = Data.CHARACTERS[slots[0]];
    const lEl = Icons.ELEMENT_META[leader.element];
    const leaderHtml = `
      <div class="leader-hud-card ${lEl.cls}" id="leader-hud-card">
        <div class="lh-top">
          <div class="lh-id">
            <div class="el-icon-circle ${lEl.cls}">${Icons.element(leader.element)}</div>
            <span class="lh-name">${leader.name}</span>
            <span class="num" style="font-size:17px;color:var(--gold-bright);font-weight:800;">Lv.${leader.level}</span>
            <span class="lh-ctrl-pill">操作中</span>
          </div>
          <div class="lh-hp-nums num" id="leader-hp-txt">40,000 <small>/ 40,000</small></div>
        </div>
        <div class="lh-hp-bar"><div class="hp-fill" id="leader-hp-fill" style="width:100%"></div></div>
        <div class="lh-ougi-row">
          <span class="lh-ougi-label">奥义槽 OUGI</span>
          <div class="lh-ougi-bar"><div class="ougi-fill" id="leader-ougi-fill" style="width:30%"></div></div>
          <span class="lh-ougi-num num" id="leader-ougi-pct">30%</span>
        </div>
        <div class="lh-ready-banner" id="leader-ready-banner" style="display:none;">
          <span>✦ 奥义槽已满 · FULL OUGI READY</span>
          <span class="num">[R] 解放</span>
        </div>
      </div>
    `;
    $('#party-hud').innerHTML = alliesHtml + leaderHtml;

    // Leader's 4 Skill Slots
    const leaderSkills = Battle.state.skills;
    $('#battle-skill-slots').innerHTML = leaderSkills.map((sk, idx) => `
      <div class="battle-skill-slot ${lEl.cls}" id="bskill-${idx}" data-bskill="${idx}">
        <div class="bss-top">
          <span class="bss-key">${idx + 1}</span>
          <div class="bss-icon">${Icons.skill(sk.icon, lEl.glow)}</div>
        </div>
        <div>
          <div class="bss-name">${sk.name}</div>
          <div class="bss-ready-dot" id="bskill-status-${idx}">READY</div>
        </div>
        <div class="bss-cd-mask" id="bskill-mask-${idx}" style="height:0%"></div>
        <div class="bss-cd-timer" id="bskill-cd-${idx}" style="display:none;"></div>
      </div>
    `).join('');
  }

  function updateBattleFrame(t) {
    buildBattleStaticDom();
    const bs = Battle.state;
    syncDirectoryHighlight();

    // Battle quest timer
    const mins = Math.floor(bs.bTime / 60);
    const secs = Math.floor(bs.bTime % 60);
    const ms = Math.floor((bs.bTime % 1) * 100);
    $('#battle-timer').textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(ms).padStart(2, '0')}`;

    // Combo
    const comboBox = $('#battle-combo-box');
    comboBox.style.opacity = bs.combo > 0 ? '1' : '0';
    $('#battle-combo-num').textContent = bs.combo;

    // Boss Multi-Layer HP
    const li = Battle.getBossLayerInfo();
    $('#boss-hp-under').style.background = li.underColor;
    $('#boss-hp-ghost').style.width = li.ghostPct.toFixed(2) + '%';
    $('#boss-hp-fill').style.width = li.pct.toFixed(2) + '%';
    $('#boss-hp-fill').style.background = li.fillColor;
    $('#boss-layer-count').textContent = '×' + li.currentLayer;

    for (let i = 0; i < bs.bossLayers; i++) {
      const pip = $('#boss-pip-' + i);
      if (pip) pip.classList.toggle('filled', i < li.currentLayer);
    }

    // Boss Mode Gauge (Normal / Overdrive / Break)
    const mTag = $('#boss-mode-tag');
    const mFill = $('#boss-mode-fill');
    mTag.className = 'boss-mode-tag ' + (bs.bossMode === 'overdrive' ? 'overdrive' : bs.bossMode === 'break' ? 'break' : '');
    mFill.className = 'boss-mode-fill ' + (bs.bossMode === 'overdrive' ? 'overdrive' : bs.bossMode === 'break' ? 'break' : '');
    mFill.style.width = Math.max(0, Math.min(100, bs.bossModeGauge)).toFixed(1) + '%';

    if (bs.bossMode === 'overdrive') {
      mTag.textContent = '超载 OVERDRIVE';
    } else if (bs.bossMode === 'break') {
      mTag.textContent = `破防 BREAK ${bs.breakRemaining.toFixed(1)}s`;
    } else {
      mTag.textContent = '模式槽 MODE';
    }

    // Screen-edge Auras
    $('#battle-link-aura').style.opacity = bs.linkTimeActive ? (0.72 + 0.25 * Math.sin(t * 6)).toFixed(3) : '0';
    $('#battle-overdrive-aura').style.opacity = (bs.bossMode === 'overdrive' && !bs.ougiSeq.active) ? (0.62 + 0.28 * Math.sin(t * 7)).toFixed(3) : '0';

    // Lock-On Reticle
    const reticle = $('#battle-lockon');
    reticle.style.opacity = (bs.defeated || bs.ougiSeq.active) ? '0' : '1';
    reticle.style.left = bs.lockX.toFixed(1) + 'px';
    reticle.style.top = bs.lockY.toFixed(1) + 'px';
    const rOuter = reticle.querySelector('.reticle-outer');
    const rInner = reticle.querySelector('.reticle-inner');
    if (rOuter) rOuter.style.transform = `rotate(${(t * 42).toFixed(1)}deg)`;
    if (rOuter) rOuter.style.transformOrigin = '85px 85px';
    if (rInner) {
      const sc = bs.bossMode === 'overdrive' ? (1 + 0.08 * Math.sin(t * 14)) : 1;
      rInner.style.transform = `rotate(${(-t * 28).toFixed(1)}deg) scale(${sc.toFixed(3)})`;
      rInner.style.transformOrigin = '85px 85px';
    }
    $('#lockon-label').textContent = bs.bossMode === 'break'
      ? 'LOCK // BREAK WEAKENED'
      : bs.bossMode === 'overdrive'
        ? 'LOCK // OVERDRIVE DANGER'
        : 'LOCK // 焰冠龙 伊格瑞斯';

    // Link Gauge Circular Progress (r=52 -> circumference 326.7)
    const linkHud = $('#link-hud');
    linkHud.classList.toggle('active', bs.linkTimeActive);
    linkHud.style.opacity = bs.ougiSeq.active ? '0' : '1';
    const circ = 326.73;
    const lOffset = circ * (1 - clamp01(bs.linkGauge / 100));
    $('#link-ring-prog').style.strokeDashoffset = lOffset.toFixed(2);
    $('#link-pct-num').innerHTML = `${Math.round(bs.linkGauge)}<small>%</small>`;
    $('#link-title').textContent = bs.linkTimeActive ? '连携时刻 ACTIVE' : '连携值 LINK';
    $('#link-buffs').style.display = bs.linkTimeActive ? 'flex' : 'none';
    const plb = $('#party-link-buff-strip');
    if (plb) plb.style.display = bs.linkTimeActive ? 'flex' : 'none';

    // Party 4 Members HP & Ougi
    bs.members.forEach((m, idx) => {
      const hpPct = Math.max(0, Math.min(100, (m.hp / m.maxHp) * 100));
      const ougiPct = Math.max(0, Math.min(100, m.ougi));
      const ready = ougiPct >= 100;

      if (idx === 0) {
        $('#leader-hud-card').classList.toggle('ougi-ready', ready);
        $('#leader-hp-txt').innerHTML = `${m.hp.toLocaleString()} <small>/ ${m.maxHp.toLocaleString()}</small>`;
        const lf = $('#leader-hp-fill');
        lf.style.width = hpPct.toFixed(1) + '%';
        lf.classList.toggle('low', hpPct < 35);

        const ofill = $('#leader-ougi-fill');
        ofill.style.width = ougiPct.toFixed(1) + '%';
        ofill.classList.toggle('ready', ready);
        $('#leader-ougi-pct').textContent = Math.floor(ougiPct) + '%';
        $('#leader-ready-banner').style.display = ready ? 'flex' : 'none';

        const ougiBtn = $('#battle-ougi-btn');
        ougiBtn.classList.toggle('ready', ready);
        ougiBtn.innerHTML = ready
          ? `<span>✦ 奥义解放 · ${Data.CHARACTERS[m.charId].ougi.name}</span><span class="num">[R]</span>`
          : `<span>奥义蓄能中</span><span class="num">${Math.floor(ougiPct)}%</span>`;
      } else {
        const row = $('#ally-row-' + idx);
        if (!row) return;
        row.classList.toggle('ougi-ready', ready);
        const hf = $('#ally-hp-' + idx);
        hf.style.width = hpPct.toFixed(1) + '%';
        hf.classList.toggle('low', hpPct < 35);
        const ob = $('#ally-ougi-bar-' + idx);
        ob.style.width = ougiPct.toFixed(1) + '%';
        ob.classList.toggle('ready', ready);
        const op = $('#ally-ougi-pct-' + idx);
        op.classList.toggle('ready', ready);
        op.textContent = ready ? 'READY!' : Math.floor(ougiPct) + '%';
      }
    });

    // Leader's 4 Skill Slots Cooldown & READY Flash
    bs.skills.forEach((sk, idx) => {
      const slot = $('#bskill-' + idx);
      if (!slot) return;
      const onCd = sk.cdLeft > 0;
      slot.classList.toggle('on-cd', onCd);
      slot.classList.toggle('just-ready', sk.justReadyTimer > 0);
      slot.classList.toggle('just-cast', sk.justCastTimer > 0);

      const mask = $('#bskill-mask-' + idx);
      const cdTxt = $('#bskill-cd-' + idx);
      const stTxt = $('#bskill-status-' + idx);

      if (onCd) {
        mask.style.height = ((sk.cdLeft / sk.cdMax) * 100).toFixed(1) + '%';
        cdTxt.style.display = 'flex';
        cdTxt.textContent = sk.cdLeft.toFixed(1);
        stTxt.textContent = 'COOLING';
        stTxt.style.color = 'rgba(245,239,226,0.45)';
      } else {
        mask.style.height = '0%';
        cdTxt.style.display = 'none';
        stTxt.textContent = sk.justReadyTimer > 0 ? '✦ READY!' : 'READY';
        stTxt.style.color = 'var(--el-wind-glow)';
      }
    });

    // Floating Damage Popups
    const dmgLayer = $('#damage-layer');
    if (State.state.settings.dmgNums === '关闭') {
      dmgLayer.innerHTML = '';
    } else {
      dmgLayer.innerHTML = bs.popups.map(p => {
        const pr = p.age / p.duration;
        const punch = pr < 0.14 ? (0.6 + 0.65 * easeOutBack(pr / 0.14)) : (pr < 0.25 ? 1.25 - 0.25 * ((pr - 0.14) / 0.11) : 1.0);
        const alpha = pr > 0.72 ? (1 - (pr - 0.72) / 0.28) : 1;
        return `
          <div class="dmg-pop ${p.kind}" style="left:${p.x.toFixed(1)}px;top:${p.y.toFixed(1)}px;opacity:${alpha.toFixed(3)};transform:translate(-50%,-50%) scale(${punch.toFixed(3)});">
            ${p.tag ? `<span class="dmg-tag">${p.tag}</span>` : ''}
            <span>${p.val}</span>
          </div>
        `;
      }).join('');
    }

    // Cinematic Event Banner (Boss Intro / Link Time / Overdrive / Break / Clear)
    const bLayer = $('#battle-banner-layer');
    if (bs.banner && !bs.ougiSeq.active) {
      const bn = bs.banner;
      const pIn = easeOutCubic(bn.age / 0.24);
      const pOut = bn.age > bn.duration - 0.35 ? clamp01((bn.duration - bn.age) / 0.35) : 1;
      const op = pIn * pOut;
      const sc = 1.08 - 0.08 * pIn;
      const clsMap = {
        'boss-intro': 'banner-boss-intro',
        'link-time':  'banner-link-time',
        'overdrive':  'banner-overdrive',
        'break':      'banner-break',
        'clear':      'banner-clear'
      };
      if (bn.kind === 'boss-intro') {
        bLayer.innerHTML = `
          <div class="cinematic-banner ${clsMap[bn.kind]}" style="opacity:${op.toFixed(3)};transform:scale(${sc.toFixed(3)});">
            <div class="bbi-kicker">${bn.kicker}</div>
            <div class="bbi-title">${bn.title}</div>
            <div class="bbi-sub">${bn.sub}</div>
          </div>
        `;
      } else {
        bLayer.innerHTML = `
          <div class="cinematic-banner ${clsMap[bn.kind]}" style="opacity:${op.toFixed(3)};transform:scale(${sc.toFixed(3)});">
            <div class="cb-big-en">${bn.kicker}</div>
            <div class="cb-big-zh">${bn.title}</div>
            <div class="cb-big-sub">${bn.sub}</div>
          </div>
        `;
      }
    } else {
      bLayer.innerHTML = '';
    }

    // OUGI CUT-IN & CHAIN COUNTER & FULL BURST OVERLAY
    const ougiCutin = $('#ougi-cutin');
    const chainBadge = $('#chain-badge');
    const fbOverlay = $('#fullburst-overlay');
    const seq = bs.ougiSeq;

    if (seq.active && seq.phase === 'cutin') {
      const elapsed = bs.bTime - seq.startT;
      const stageStarts = [0, 2.0, 3.8, 5.6];
      const stageAge = Math.max(0, elapsed - stageStarts[seq.casterIdx]);
      const pIn = easeOutCubic(stageAge / 0.22);
      const pOut = stageAge > 1.45 ? clamp01((1.78 - stageAge) / 0.33) : 1;

      const caster = Data.CHARACTERS[seq.casterCharId];
      const elM = Icons.ELEMENT_META[seq.element];

      ougiCutin.style.opacity = (pIn * pOut).toFixed(3);
      ougiCutin.innerHTML = `
        <div class="ougi-ribbon ${elM.cls}" style="transform:rotate(-4deg) translateX(${((1 - pIn) * 260).toFixed(1)}px);">
          <div class="ougi-crest-box">${Icons.element(seq.element)}</div>
          <div class="ougi-text-col">
            <div class="ougi-caster-row">
              <span class="ougi-kicker">OUGI // ${elM.en}</span>
              <span class="ougi-caster-name">${caster.name}</span>
              ${elBadgeHtml(seq.element, elM.zh + '属性奥义')}
            </div>
            <div class="ougi-skill-title">${seq.ougiName}</div>
            <div class="ougi-skill-en">${seq.ougiEn}</div>
          </div>
        </div>
      `;

      // Chain counter appears from 2 CHAIN -> 4 CHAIN!
      if (seq.chainCount >= 2) {
        const chScale = 1 + 0.25 * (1 - easeOutCubic(stageAge / 0.3));
        chainBadge.style.opacity = '1';
        chainBadge.style.transform = `scale(${chScale.toFixed(3)})`;
        $('#chain-num').textContent = seq.chainCount;
      } else {
        chainBadge.style.opacity = '0';
      }
      fbOverlay.style.opacity = '0';
    } else if (seq.active && seq.phase === 'fullburst') {
      ougiCutin.style.opacity = '0';
      chainBadge.style.opacity = '1';
      chainBadge.style.transform = 'scale(1)';
      $('#chain-num').textContent = '4';

      const fbAge = Math.max(0, (bs.bTime - seq.startT) - 7.4);
      const pIn = easeOutCubic(fbAge / 0.32);
      const pOut = fbAge > 3.15 ? clamp01((3.6 - fbAge) / 0.45) : 1;
      const firstCaster = Data.CHARACTERS[bs.members[0].charId];
      const firstElMeta = Icons.ELEMENT_META[firstCaster.element];
      fbOverlay.className = firstElMeta.cls;
      fbOverlay.style.opacity = (pIn * pOut).toFixed(3);
      const ring = fbOverlay.querySelector('.fb-crest-ring');
      if (ring) {
        if (ring.dataset.el !== firstCaster.element) {
          ring.dataset.el = firstCaster.element;
          ring.innerHTML = Icons.astrolabeSvg(firstElMeta.glow);
        }
        ring.style.transform = `rotate(${(fbAge * 45).toFixed(1)}deg) scale(${(0.85 + 0.2 * pIn).toFixed(3)})`;
      }
      $('#fb-total-num').textContent = seq.displayedTotalDmg.toLocaleString();
      $('#fb-finisher-name').textContent = firstCaster.ougi.finisherName || '风极·天穹裁决';
      $('#fb-attr-note').innerHTML = `${Icons.element(firstCaster.element)}<span>${firstElMeta.zh}属性终结技 · 首发奥义共鸣：${firstCaster.name}</span>`;
    } else {
      ougiCutin.style.opacity = '0';
      chainBadge.style.opacity = '0';
      fbOverlay.style.opacity = '0';
    }
  }

  /* ------------------------------------------------------------------------
     SCREEN 7: 结算画面 (Results Screen — Rank, MVP, EXP, Sequential Chests)
     ------------------------------------------------------------------------ */
  function enterResults() {
    const rs = State.state.results;
    rs.enteredAt = State.state.t;
    rs.elapsed = 0;
    rs.skipped = false;
    rs.rankBurstSpawned = false;
    rs.chestBurstSpawned = [false, false, false];
    lastResultsStaticKey = '';
    buildResultsStaticDom();
    updateResultsFrame(State.state.t);
  }

  function skipResultsAnim() {
    State.state.results.skipped = true;
    updateResultsFrame(State.state.t);
  }

  function buildResultsStaticDom() {
    const slots = State.state.party.slots;
    const key = slots.join(',');
    if (key === lastResultsStaticKey) return;
    lastResultsStaticKey = key;

    const q = State.getSelectedQuest();
    $('#res-quest-name').textContent = q.name;
    $('#res-clear-time').textContent = State.state.results.clearTimeStr;

    const contribScores = [148520, 114280, 129640, 106310];
    const expGains = [19400, 16800, 17200, 16500];

    $('#res-member-list').innerHTML = slots.map((cid, idx) => {
      const c = Data.CHARACTERS[cid];
      const el = Icons.ELEMENT_META[c.element];
      const isMvp = idx === 0;
      const isLvUp = idx === 0;
      return `
        <div class="res-member-card ${el.cls}" id="rmc-${idx}" data-score="${contribScores[idx]}" data-exp-gain="${expGains[idx]}" data-exp-start="${c.exp}" data-exp-max="${c.expMax}" data-lv="${c.level}" data-mvp="${isMvp ? 1 : 0}" data-lvup="${isLvUp ? 1 : 0}">
          <div class="rmc-top">
            <div class="rmc-left">
              <div class="el-icon-circle ${el.cls}">${Icons.element(c.element)}</div>
              <span class="rmc-name">${c.name}</span>
              <span class="psc-weapon-pill">${c.weaponType}</span>
              <span class="mvp-badge" id="rmc-mvp-${idx}" style="display:none;">${Icons.crownSvg()}<span>MVP</span></span>
              <span class="levelup-badge" id="rmc-lvup-${idx}" style="display:none;">LEVEL UP! Lv.${c.level} → Lv.${c.level + 1}</span>
            </div>
            <div class="rmc-contrib">
              <span class="cl">贡献度</span>
              <span class="cv num" id="rmc-score-${idx}">0</span>
            </div>
          </div>
          <div class="rmc-bars-grid">
            <div class="rmc-bar-col">
              <div class="bl"><span>战斗贡献占比</span><span class="num" id="rmc-cpct-${idx}">0%</span></div>
              <div class="rmc-bar-track"><div class="rmc-contrib-fill" id="rmc-cbar-${idx}" style="width:0%"></div></div>
            </div>
            <div class="rmc-bar-col">
              <div class="bl"><span id="rmc-lv-lbl-${idx}">Lv.${c.level} 经验值</span><span class="num" style="color:var(--emerald-up);" id="rmc-exp-txt-${idx}">+0 EXP</span></div>
              <div class="rmc-bar-track"><div class="rmc-exp-fill" id="rmc-ebar-${idx}" style="width:${Math.round((c.exp / c.expMax) * 100)}%"></div></div>
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  function updateResultsFrame(t) {
    buildResultsStaticDom();
    const rs = State.state.results;
    const el = rs.skipped ? 12.0 : Math.max(0, t - rs.enteredAt);
    rs.elapsed = el;

    // 1. Rank Reveal Ladder (C -> B -> A -> S -> S+ slamming at 1.45s!)
    const grades = ['C', 'B', 'A', 'S', 'S+'];
    let gradeIdx = 0;
    if (el >= 1.45) gradeIdx = 4;
    else if (el >= 1.12) gradeIdx = 3;
    else if (el >= 0.80) gradeIdx = 2;
    else if (el >= 0.48) gradeIdx = 1;

    const rankEl = $('#res-rank-letter');
    rankEl.textContent = grades[gradeIdx];
    const stampAge = Math.max(0, el - 1.45);
    const stampScale = el >= 1.45 ? (1 + 0.42 * (1 - easeOutBack(Math.min(1, stampAge / 0.35)))) : (0.85 + 0.15 * Math.sin(el * 12));
    rankEl.style.transform = `scale(${stampScale.toFixed(3)})`;

    if (el >= 1.45 && !rs.rankBurstSpawned && !rs.skipped) {
      rs.rankBurstSpawned = true;
      Backdrop.spawnFx({
        type: 'burst', birthT: t, duration: 0.95,
        x: 246, y: 485, maxR: 220, count: 24, color: '#ffe699', seed: 515
      });
      Backdrop.spawnFx({
        type: 'ring', birthT: t, duration: 0.75,
        x: 246, y: 485, maxR: 200, color: '#fff3be'
      });
    }

    $$('.rank-step').forEach((sEl, i) => {
      sEl.classList.toggle('passed', i < gradeIdx);
      sEl.classList.toggle('active', i === gradeIdx);
    });

    // 2. Party Contribution Bars, MVP Stamp & EXP Level Up (1.7s -> 4.0s)
    const totalContrib = 498750;
    const contribP = easeOutCubic((el - 1.75) / 1.0);
    const expP = easeOutCubic((el - 2.4) / 1.25);

    for (let i = 0; i < 4; i++) {
      const card = $('#rmc-' + i);
      if (!card) continue;
      const targetScore = Number(card.dataset.score);
      const gain = Number(card.dataset.expGain);
      const startExp = Number(card.dataset.expStart);
      const maxExp = Number(card.dataset.expMax);
      const lv = Number(card.dataset.lv);
      const isMvp = card.dataset.mvp === '1';
      const isLvUp = card.dataset.lvup === '1';

      const curScore = Math.round(targetScore * contribP);
      const pct = Math.round((curScore / totalContrib) * 100);
      $('#rmc-score-' + i).textContent = curScore.toLocaleString();
      $('#rmc-cpct-' + i).textContent = pct + '%';
      $('#rmc-cbar-' + i).style.width = ((curScore / 155000) * 100).toFixed(1) + '%';

      const showMvp = isMvp && el >= 2.45;
      card.classList.toggle('is-mvp', showMvp);
      $('#rmc-mvp-' + i).style.display = showMvp ? 'inline-flex' : 'none';

      const curGain = Math.round(gain * expP);
      $('#rmc-exp-txt-' + i).textContent = `+${curGain.toLocaleString()} EXP`;
      const sumExp = startExp + curGain;
      if (isLvUp && sumExp >= maxExp) {
        $('#rmc-lvup-' + i).style.display = 'inline-flex';
        $('#rmc-lv-lbl-' + i).textContent = `Lv.${lv + 1} 经验值 (ATK+24 HP+480)`;
        $('#rmc-ebar-' + i).style.width = (((sumExp - maxExp) / maxExp) * 100).toFixed(1) + '%';
      } else {
        $('#rmc-lvup-' + i).style.display = 'none';
        $('#rmc-lv-lbl-' + i).textContent = `Lv.${lv} 经验值`;
        $('#rmc-ebar-' + i).style.width = Math.min(100, (sumExp / maxExp) * 100).toFixed(1) + '%';
      }
    }

    // 3. Treasure Chests Sequential Opening: Bronze (4.4s) -> Silver (5.6s) -> Gold (7.15s)
    const chestDefs = [
      { id: 'bronze', label: '铜宝箱', openAt: 4.4, shakeFrom: 4.05, x: 1410 },
      { id: 'silver', label: '银宝箱', openAt: 5.6, shakeFrom: 5.25, x: 1585 },
      { id: 'gold',   label: '金宝箱', openAt: 7.15, shakeFrom: 6.55, x: 1760 }
    ];

    const unlockedDrops = [];
    chestDefs.forEach((ch, idx) => {
      const card = $('#chest-card-' + ch.id);
      const svgWrap = $('#chest-svg-' + ch.id);
      const status = $('#chest-status-' + ch.id);
      const isOpen = el >= ch.openAt;
      const isShaking = !isOpen && el >= ch.shakeFrom;

      card.classList.toggle('opened', isOpen);
      const shakeX = isShaking ? Math.sin(el * (ch.id === 'gold' ? 56 : 38)) * (ch.id === 'gold' ? 7 : 4) : 0;
      const popScale = isOpen ? (1 + (ch.id === 'gold' ? 0.24 : 0.12) * (1 - easeOutBack(Math.min(1, (el - ch.openAt) / 0.4)))) : 1;
      svgWrap.style.transform = `translateX(${shakeX.toFixed(1)}px) scale(${popScale.toFixed(3)})`;

      const wantMode = isOpen ? 'open' : 'closed';
      if (svgWrap.dataset.mode !== wantMode) {
        svgWrap.dataset.mode = wantMode;
        svgWrap.innerHTML = Icons.chest(ch.id, isOpen);
      }

      status.textContent = isOpen
        ? (ch.id === 'gold' ? '✦ 传说稀有开启！' : '已开启')
        : (isShaking ? '开启中…' : '待开启');

      if (isOpen && !rs.chestBurstSpawned[idx] && !rs.skipped) {
        rs.chestBurstSpawned[idx] = true;
        Backdrop.spawnFx({
          type: 'burst',
          birthT: t,
          duration: ch.id === 'gold' ? 1.2 : 0.65,
          x: ch.x,
          y: 325,
          maxR: ch.id === 'gold' ? 300 : 150,
          count: ch.id === 'gold' ? 32 : 14,
          color: Icons.RARITY_META[ch.id].color,
          seed: 600 + idx * 37
        });
        if (ch.id === 'gold') {
          Backdrop.spawnFx({
            type: 'ring', birthT: t, duration: 0.9,
            x: ch.x, y: 325, maxR: 280, color: '#fff3b0'
          });
        }
      }

      if (isOpen) {
        Data.RESULTS_LOOT[ch.id].forEach(it => unlockedDrops.push(it));
      }
    });

    const dropsBox = $('#res-drops-list');
    const dropKey = String(unlockedDrops.length);
    if (dropsBox.dataset.cnt !== dropKey) {
      dropsBox.dataset.cnt = dropKey;
      // Show newest (highest rarity) at top so Gold rare loot immediately stands out!
      const ordered = unlockedDrops.slice().reverse();
      dropsBox.innerHTML = ordered.map(it => {
        const rm = Icons.RARITY_META[it.rarity];
        return `
          <div class="drop-item-row ${rm.cls}">
            <div class="dir-left">
              ${Icons.item(it.icon, rm.color)}
              <div>
                <div class="dir-name">${it.name} <span class="rar-tag ${rm.cls}" style="margin-left:6px;">${rm.zh}</span></div>
                <div class="dir-sub">${it.sub}</div>
              </div>
            </div>
            <div class="dir-qty num">×${it.qty}</div>
          </div>
        `;
      }).join('');
    }

    const skipBtn = $('#res-skip-btn');
    if (skipBtn) {
      skipBtn.textContent = el >= 7.6 ? '✦ 全部结算已揭晓 · COMPLETE' : '跳过演出 · SKIP [SPACE]';
      skipBtn.style.opacity = el >= 7.6 ? '0.82' : '1';
    }
  }

  /* ------------------------------------------------------------------------
     Transition Curtain Frame Update
     ------------------------------------------------------------------------ */
  function updateTransitionFrame(t) {
    const tr = State.state.transition;
    const el = $('#transition-curtain');
    if (!tr.active) {
      el.style.opacity = '0';
      return;
    }
    const p = clamp01((t - tr.startT) / tr.duration);
    if (p >= 0.48 && !tr.swapped) {
      tr.swapped = true;
      if (tr.onMidpoint) tr.onMidpoint();
    }
    const alpha = p < 0.5 ? easeOutCubic(p * 2) : easeOutCubic((1 - p) * 2);
    el.style.opacity = alpha.toFixed(3);
    const crest = el.querySelector('.curtain-crest');
    if (crest) crest.style.transform = `rotate(${(p * 75).toFixed(1)}deg) scale(${(0.86 + 0.22 * alpha).toFixed(3)})`;
    if (p >= 1) {
      tr.active = false;
      el.style.opacity = '0';
    }
  }

  function updateQuestFrame(t) {
    const qs = State.state.quest;
    const tabAge = Math.max(0, t - Math.max(State.state.screenEnteredAt, qs.tabChangedAt));
    $$('#quest-list .quest-card').forEach((card, idx) => {
      const p = easeOutCubic((tabAge - idx * 0.055) / 0.26);
      if (p >= 0.999) {
        card.style.opacity = '';
        card.style.transform = '';
      } else {
        card.style.opacity = p.toFixed(3);
        card.style.transform = `translateX(${((1 - p) * -22).toFixed(1)}px)`;
      }
    });
    const det = $('#quest-detail');
    if (det) {
      const dAge = Math.max(0, t - Math.max(State.state.screenEnteredAt, qs.detailChangedAt));
      const dp = easeOutCubic(dAge / 0.24);
      if (dp >= 0.999) {
        det.style.opacity = '';
        det.style.transform = '';
      } else {
        det.style.opacity = dp.toFixed(3);
        det.style.transform = `translateY(${((1 - dp) * 14).toFixed(1)}px)`;
      }
    }
  }

  function updatePartyFrame(t) {
    const ps = State.state.party;
    const pAge = Math.max(0, t - State.state.screenEnteredAt);
    $$('#party-slots .party-slot-card').forEach((card, idx) => {
      const p = easeOutCubic((pAge - idx * 0.06) / 0.30);
      if (p >= 0.999) {
        card.style.opacity = '';
        card.style.transform = '';
      } else {
        card.style.opacity = p.toFixed(3);
        card.style.transform = `translateY(${((1 - p) * 24).toFixed(1)}px)`;
      }
    });
    const det = $('#char-detail-view');
    if (det && ps.detailOpen) {
      const dAge = Math.max(0, t - ps.detailOpenedAt);
      const dp = easeOutCubic(dAge / 0.24);
      if (dp >= 0.999) {
        det.style.opacity = '';
        det.style.transform = '';
      } else {
        det.style.opacity = dp.toFixed(3);
        det.style.transform = `scale(${(0.97 + 0.03 * dp).toFixed(4)})`;
      }
    }
  }

  /* ------------------------------------------------------------------------
     Master Render Tick (Called every frame in Live Mode & Export Mode)
     ------------------------------------------------------------------------ */
  function renderFrame(t) {
    document.documentElement.style.setProperty('--t', t.toFixed(4));
    syncActiveScreenDom();

    const cur = State.state.screen;
    if (cur === 'title') {
      updateTitleFrame(t);
    } else if (cur === 'story') {
      renderStoryFrame();
    } else if (cur === 'quest') {
      updateQuestFrame(t);
    } else if (cur === 'party') {
      updatePartyFrame(t);
    } else if (cur === 'battle') {
      updateBattleFrame(t);
    } else if (cur === 'results') {
      updateResultsFrame(t);
    }

    updateTransitionFrame(t);
    Backdrop.render(t, cur, cur === 'battle' ? Battle.state : null);
  }

  /* ------------------------------------------------------------------------
     Bind All Mouse & Keyboard Interactions
     ------------------------------------------------------------------------ */
  function bindEvents() {
    // 1. Screen Directory
    $('#screen-dir').addEventListener('click', (e) => {
      const btn = e.target.closest('.dir-btn');
      if (!btn) return;
      navigateTo(btn.dataset.nav);
    });

    // 2. Title Screen Interactions
    $('#title-pak').addEventListener('click', expandTitleMenu);
    $('#title-menu').addEventListener('click', (e) => {
      const item = e.target.closest('.title-menu-item');
      if (!item) return;
      activateTitleChoice(Number(item.dataset.idx));
    });
    $('#title-menu').addEventListener('mouseover', (e) => {
      const item = e.target.closest('.title-menu-item');
      if (!item) return;
      State.state.title.selectedIndex = Number(item.dataset.idx);
      renderTitleScreen();
    });
    $('#settings-close').addEventListener('click', () => {
      State.state.title.settingsOpen = false;
      renderTitleScreen();
    });
    $('#settings-modal').addEventListener('click', (e) => {
      if (e.target === e.currentTarget) {
        State.state.title.settingsOpen = false;
        renderTitleScreen();
      }
    });
    $('#settings-rows').addEventListener('click', (e) => {
      const btn = e.target.closest('.seg-btn');
      if (!btn) return;
      State.state.settings[btn.dataset.setkey] = btn.dataset.setval;
      renderSettingsBody();
    });

    // 3. Story Screen Interactions
    $('#story-box').addEventListener('click', (e) => {
      const termEl = e.target.closest('.lore-term');
      if (termEl) {
        e.stopPropagation();
        const term = termEl.dataset.term;
        State.state.story.openGlossaryTerm = State.state.story.openGlossaryTerm === term ? null : term;
        lastStoryKey = '';
        renderStoryFrame();
        return;
      }
      advanceStory();
    });
    $('#story-box').addEventListener('mouseover', (e) => {
      if (State.state.exportMode) return;
      const termEl = e.target.closest('.lore-term');
      if (termEl && termEl.dataset.term) {
        State.state.story.openGlossaryTerm = termEl.dataset.term;
        lastStoryKey = '';
        renderStoryFrame();
      }
    });
    $('#gloss-close').addEventListener('click', (e) => {
      e.stopPropagation();
      State.state.story.openGlossaryTerm = null;
      lastStoryKey = '';
      renderStoryFrame();
    });
    $('#story-auto-btn').addEventListener('click', () => {
      State.state.story.autoMode = !State.state.story.autoMode;
      lastStoryKey = '';
      renderStoryFrame();
    });
    $('#story-fast-btn').addEventListener('click', () => {
      State.state.story.fastMode = !State.state.story.fastMode;
      lastStoryKey = '';
      renderStoryFrame();
    });
    $('#story-chapter-btn').addEventListener('click', () => openChapterCard());
    $('#chapter-card').addEventListener('click', () => navigateTo('quest'));

    // 4. Quest Counter Interactions
    $('#quest-back-btn').addEventListener('click', goBack);
    $('#quest-diff-tabs').addEventListener('click', (e) => {
      const tab = e.target.closest('.diff-tab');
      if (!tab) return;
      State.state.quest.difficulty = tab.dataset.diff;
      State.state.quest.tabChangedAt = State.state.t;
      State.state.quest.detailChangedAt = State.state.t;
      renderQuestScreen();
    });
    $('#quest-list').addEventListener('click', (e) => {
      const card = e.target.closest('.quest-card');
      if (!card) return;
      State.state.quest.selectedQuestId = card.dataset.qid;
      State.state.quest.detailChangedAt = State.state.t;
      renderQuestScreen();
    });
    $('#quest-detail').addEventListener('click', (e) => {
      if (e.target.closest('#quest-depart-btn')) {
        navigateTo('party');
      }
    });

    // 5. Party & Character Growth Interactions
    $('#party-back-btn').addEventListener('click', goBack);
    $('#party-sortie-btn').addEventListener('click', () => navigateTo('battle'));

    $('#party-slots').addEventListener('click', (e) => {
      const swapBtn = e.target.closest('[data-swap-slot]');
      if (swapBtn) {
        State.state.party.swapModalSlot = Number(swapBtn.dataset.swapSlot);
        renderPartyScreen();
        return;
      }
      const detBtn = e.target.closest('[data-detail-char]');
      if (detBtn) {
        State.state.party.detailCharId = detBtn.dataset.detailChar;
        State.state.party.detailOpen = true;
        State.state.party.detailOpenedAt = State.state.t;
        State.state.party.editingSkillSlot = null;
        State.state.party.editingSigilSlot = null;
        renderPartyScreen();
        return;
      }
      const card = e.target.closest('.party-slot-card');
      if (card) {
        State.state.party.swapModalSlot = Number(card.dataset.slot);
        renderPartyScreen();
      }
    });

    $('#swap-close').addEventListener('click', () => {
      State.state.party.swapModalSlot = null;
      renderPartyScreen();
    });
    $('#swap-modal').addEventListener('click', (e) => {
      if (e.target === e.currentTarget) {
        State.state.party.swapModalSlot = null;
        renderPartyScreen();
      }
    });
    $('#swap-roster-grid').addEventListener('click', (e) => {
      const pick = e.target.closest('[data-pick-char]');
      if (!pick) return;
      const cid = pick.dataset.pickChar;
      const slotIdx = State.state.party.swapModalSlot;
      const slots = State.state.party.slots;
      const existing = slots.indexOf(cid);
      if (existing >= 0 && existing !== slotIdx) {
        const tmp = slots[slotIdx];
        slots[slotIdx] = cid;
        slots[existing] = tmp;
      } else {
        slots[slotIdx] = cid;
      }
      State.state.party.swapModalSlot = null;
      renderPartyScreen();
    });

    // Character Detail interactions
    $('#cd-close-btn').addEventListener('click', () => {
      State.state.party.detailOpen = false;
      State.state.party.editingSkillSlot = null;
      State.state.party.editingSigilSlot = null;
      State.state.party.hoverSkillId = null;
      State.state.party.hoverSigilId = null;
      renderPartyScreen();
    });
    $('#cd-char-pills').addEventListener('click', (e) => {
      const pill = e.target.closest('[data-cd-char]');
      if (!pill) return;
      State.state.party.detailCharId = pill.dataset.cdChar;
      State.state.party.editingSkillSlot = null;
      State.state.party.editingSigilSlot = null;
      State.state.party.hoverSkillId = null;
      State.state.party.hoverSigilId = null;
      renderCharDetail();
    });
    $('#cd-skills-grid').addEventListener('click', (e) => {
      const slot = e.target.closest('[data-edit-skill]');
      if (!slot) return;
      const idx = Number(slot.dataset.editSkill);
      State.state.party.editingSigilSlot = null;
      State.state.party.hoverSigilId = null;
      State.state.party.editingSkillSlot = State.state.party.editingSkillSlot === idx ? null : idx;
      State.state.party.hoverSkillId = null;
      renderCharDetail();
    });
    $('#cd-sigils-grid').addEventListener('click', (e) => {
      const slot = e.target.closest('[data-edit-sigil]');
      if (!slot) return;
      const idx = Number(slot.dataset.editSigil);
      State.state.party.editingSkillSlot = null;
      State.state.party.hoverSkillId = null;
      State.state.party.editingSigilSlot = State.state.party.editingSigilSlot === idx ? null : idx;
      State.state.party.hoverSigilId = null;
      renderCharDetail();
    });
    $('#cd-right-body').addEventListener('mouseover', (e) => {
      if (State.state.exportMode) return;
      const sk = e.target.closest('[data-pick-skill]');
      if (sk && State.state.party.hoverSkillId !== sk.dataset.pickSkill) {
        State.state.party.hoverSkillId = sk.dataset.pickSkill;
        renderCharDetail();
        return;
      }
      const sg = e.target.closest('[data-pick-sigil]');
      if (sg && State.state.party.hoverSigilId !== sg.dataset.pickSigil) {
        State.state.party.hoverSigilId = sg.dataset.pickSigil;
        renderCharDetail();
      }
    });
    $('#cd-right-body').addEventListener('mouseleave', () => {
      if (State.state.exportMode) return;
      if (State.state.party.hoverSkillId || State.state.party.hoverSigilId) {
        State.state.party.hoverSkillId = null;
        State.state.party.hoverSigilId = null;
        renderCharDetail();
      }
    });
    $('#cd-right-body').addEventListener('click', (e) => {
      const ps = State.state.party;
      const sk = e.target.closest('[data-pick-skill]');
      if (sk && ps.editingSkillSlot !== null) {
        const skills = State.state.builds[ps.detailCharId].skills;
        const newId = sk.dataset.pickSkill;
        const prevIdx = skills.indexOf(newId);
        if (prevIdx >= 0 && prevIdx !== ps.editingSkillSlot) {
          skills[prevIdx] = skills[ps.editingSkillSlot];
        }
        skills[ps.editingSkillSlot] = newId;
        ps.editingSkillSlot = null;
        ps.hoverSkillId = null;
        renderCharDetail();
        return;
      }
      const sg = e.target.closest('[data-pick-sigil]');
      if (sg && ps.editingSigilSlot !== null) {
        State.state.builds[ps.detailCharId].sigils[ps.editingSigilSlot] = sg.dataset.pickSigil;
        ps.editingSigilSlot = null;
        ps.hoverSigilId = null;
        renderCharDetail();
      }
    });

    // 6. Battle Interactive Controls
    $('#battle-skill-slots').addEventListener('click', (e) => {
      const s = e.target.closest('[data-bskill]');
      if (!s) return;
      Battle.useSkill(Number(s.dataset.bskill));
    });
    $('#battle-atk-btn').addEventListener('click', () => Battle.basicAttack());
    $('#battle-ougi-btn').addEventListener('click', () => Battle.triggerOugiSequence());

    // 7. Results Interactions
    $('#res-skip-btn').addEventListener('click', skipResultsAnim);
    $('#res-retry-btn').addEventListener('click', () => navigateTo('battle'));
    $('#res-return-btn').addEventListener('click', () => navigateTo('quest'));

    // Global Keyboard Controls
    window.addEventListener('keydown', (e) => {
      if (State.state.exportMode) return;
      const cur = State.state.screen;

      if (e.key === 'Escape' || e.key === 'Backspace') {
        if (cur !== 'title' || State.state.title.settingsOpen) {
          e.preventDefault();
          goBack();
        }
        return;
      }

      if (cur === 'title') {
        if (!State.state.title.menuExpanded) {
          expandTitleMenu();
          return;
        }
        if (State.state.title.settingsOpen) return;
        if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
          State.state.title.selectedIndex = (State.state.title.selectedIndex + 1) % 3;
          renderTitleScreen();
        } else if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
          State.state.title.selectedIndex = (State.state.title.selectedIndex + 2) % 3;
          renderTitleScreen();
        } else if (e.key === 'Enter' || e.key === ' ') {
          activateTitleChoice(State.state.title.selectedIndex);
        }
      } else if (cur === 'story') {
        if (e.key === ' ' || e.key === 'Enter') {
          e.preventDefault();
          advanceStory();
        } else if (e.key === 'a' || e.key === 'A') {
          State.state.story.autoMode = !State.state.story.autoMode;
          lastStoryKey = '';
          renderStoryFrame();
        } else if (e.key === 'f' || e.key === 'F') {
          State.state.story.fastMode = !State.state.story.fastMode;
          lastStoryKey = '';
          renderStoryFrame();
        }
      } else if (cur === 'quest') {
        const diffOrder = ['normal', 'hard', 'extreme', 'legend'];
        const curDiffIdx = diffOrder.indexOf(State.state.quest.difficulty);
        const list = Data.QUESTS.filter(q => q.difficulty === State.state.quest.difficulty);
        const curQIdx = list.findIndex(q => q.id === State.state.quest.selectedQuestId);

        if (e.key === 'ArrowRight' || e.key === 'e' || e.key === 'E' || e.key === 'd' || e.key === 'D') {
          State.state.quest.difficulty = diffOrder[(curDiffIdx + 1) % diffOrder.length];
          renderQuestScreen();
        } else if (e.key === 'ArrowLeft' || e.key === 'q' || e.key === 'Q' || e.key === 'a' || e.key === 'A') {
          State.state.quest.difficulty = diffOrder[(curDiffIdx + diffOrder.length - 1) % diffOrder.length];
          renderQuestScreen();
        } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
          const next = list[(curQIdx + 1) % list.length];
          if (next) { State.state.quest.selectedQuestId = next.id; renderQuestScreen(); }
        } else if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
          const prev = list[(curQIdx + list.length - 1) % list.length];
          if (prev) { State.state.quest.selectedQuestId = prev.id; renderQuestScreen(); }
        } else if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          navigateTo('party');
        }
      } else if (cur === 'party') {
        const ps = State.state.party;
        if (ps.detailOpen) {
          const charIds = Object.keys(Data.CHARACTERS);
          const ci = charIds.indexOf(ps.detailCharId);
          if (e.key === 'ArrowRight' || e.key === 'e' || e.key === 'E') {
            ps.detailCharId = charIds[(ci + 1) % charIds.length];
            ps.editingSkillSlot = null; ps.editingSigilSlot = null;
            renderCharDetail();
          } else if (e.key === 'ArrowLeft' || e.key === 'q' || e.key === 'Q') {
            ps.detailCharId = charIds[(ci + charIds.length - 1) % charIds.length];
            ps.editingSkillSlot = null; ps.editingSigilSlot = null;
            renderCharDetail();
          } else if (['1', '2', '3', '4'].includes(e.key)) {
            ps.editingSigilSlot = null;
            ps.editingSkillSlot = Number(e.key) - 1;
            renderCharDetail();
          }
        } else if (ps.swapModalSlot === null) {
          if (['1', '2', '3', '4'].includes(e.key)) {
            ps.detailCharId = ps.slots[Number(e.key) - 1];
            ps.detailOpen = true;
            ps.detailOpenedAt = State.state.t;
            renderPartyScreen();
          } else if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            navigateTo('battle');
          }
        }
      } else if (cur === 'battle') {
        if (e.key === '1') Battle.useSkill(0);
        else if (e.key === '2') Battle.useSkill(1);
        else if (e.key === '3') Battle.useSkill(2);
        else if (e.key === '4') Battle.useSkill(3);
        else if (e.key === 'r' || e.key === 'R') Battle.triggerOugiSequence();
        else if (e.key === ' ') { e.preventDefault(); Battle.basicAttack(); }
      } else if (cur === 'results') {
        const rs = State.state.results;
        if (e.key === ' ' || e.key === 'Enter') {
          e.preventDefault();
          if (!rs.skipped && rs.elapsed < 7.6) {
            skipResultsAnim();
          } else {
            navigateTo('quest');
          }
        } else if (e.key === 'r' || e.key === 'R') {
          navigateTo('battle');
        }
      }
    });
  }

  return {
    bindEvents,
    navigateTo,
    renderTitleScreen,
    renderQuestScreen,
    renderPartyScreen,
    renderCharDetail,
    renderStoryFrame,
    enterStory,
    enterResults,
    expandTitleMenu,
    openChapterCard,
    renderFrame,
    resetStaticCaches: () => { lastBattleStaticKey = ''; lastStoryKey = ''; lastResultsStaticKey = ''; }
  };
})();
