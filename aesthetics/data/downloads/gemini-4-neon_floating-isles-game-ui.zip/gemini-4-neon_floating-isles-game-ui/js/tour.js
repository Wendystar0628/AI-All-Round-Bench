/* ==========================================================================
   《浮空群岛传说》 — Deterministic Video Export Engine (`window.videoExport`)
   90-second Choreographed Tour with Visible Virtual Cursor & 3fps/60fps Parity
   ========================================================================== */

window.SkyUI = window.SkyUI || {};

window.SkyUI.Tour = (function () {
  const State = window.SkyUI.State;
  const Battle = window.SkyUI.Battle;
  const UI = window.SkyUI.UI;
  const Backdrop = window.SkyUI.Backdrop;

  const TOUR_DURATION = 90.0; // Total length in seconds (Battle = 36s = 40%)
  const FIXED_DT = 1 / 60;

  let exportFps = 60;
  let simT = 0;
  let fired = {};

  // Virtual cursor state (in 1920x1080 stage space)
  const cursor = {
    visible: false,
    x: 960,
    y: 780,
    fromX: 960,
    fromY: 780,
    toX: 960,
    toY: 780,
    moveStart: 0,
    moveEnd: 0,
    clickAt: -10,
    hoverSelector: null
  };

  function scrollInsidePicker(selector) {
    const item = document.querySelector(selector);
    const list = item ? item.closest('.picker-list') : null;
    if (item && list) {
      const targetTop = item.offsetTop - list.offsetTop - list.clientHeight * 0.4;
      list.scrollTop = Math.max(0, targetTop);
    }
  }

  function clearHoverClasses() {
    document.querySelectorAll('.is-hover').forEach(el => el.classList.remove('is-hover'));
  }

  function getStageCenter(selector, fallbackX, fallbackY) {
    const el = selector ? document.querySelector(selector) : null;
    const stage = document.getElementById('stage');
    if (!el || !stage) return { x: fallbackX, y: fallbackY };
    const r = el.getBoundingClientRect();
    const sr = stage.getBoundingClientRect();
    if (r.width === 0 || r.height === 0 || sr.width === 0) {
      return { x: fallbackX, y: fallbackY };
    }
    const scale = sr.width / 1920;
    return {
      x: (r.left + r.width * 0.5 - sr.left) / scale,
      y: (r.top + r.height * 0.5 - sr.top) / scale
    };
  }

  function glideTo(selector, startT, endT, fbX, fbY, applyHover) {
    cursor.visible = true;
    cursor.fromX = cursor.x;
    cursor.fromY = cursor.y;
    const pt = getStageCenter(selector, fbX, fbY);
    cursor.toX = pt.x;
    cursor.toY = pt.y;
    cursor.moveStart = startT;
    cursor.moveEnd = endT;
    cursor.hoverSelector = applyHover ? selector : null;
  }

  function triggerClick(selector, fbX, fbY) {
    const pt = getStageCenter(selector, fbX, fbY);
    cursor.x = pt.x;
    cursor.y = pt.y;
    cursor.toX = pt.x;
    cursor.toY = pt.y;
    cursor.clickAt = simT;
  }

  function updateCursorVisual(t) {
    const curEl = document.getElementById('tour-cursor');
    const ripEl = document.getElementById('tour-cursor-ripple');
    if (!curEl || !ripEl) return;

    if (!State.state.exportMode || !cursor.visible) {
      curEl.style.opacity = '0';
      ripEl.style.opacity = '0';
      return;
    }

    if (t <= cursor.moveEnd && cursor.moveEnd > cursor.moveStart) {
      const p = Math.max(0, Math.min(1, (t - cursor.moveStart) / (cursor.moveEnd - cursor.moveStart)));
      // Smooth cubic ease in-out
      const ease = p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
      cursor.x = cursor.fromX + (cursor.toX - cursor.fromX) * ease;
      cursor.y = cursor.fromY + (cursor.toY - cursor.fromY) * ease;
    } else {
      cursor.x = cursor.toX;
      cursor.y = cursor.toY;
    }

    // Apply hover visual highlight when cursor reaches target
    clearHoverClasses();
    if (cursor.hoverSelector && t >= cursor.moveEnd - 0.12) {
      const target = document.querySelector(cursor.hoverSelector);
      if (target) target.classList.add('is-hover');
    }

    const clickAge = t - cursor.clickAt;
    const pressScale = (clickAge >= 0 && clickAge < 0.16) ? 0.84 : 1.0;

    curEl.style.opacity = '1';
    curEl.style.transform = `translate(${cursor.x.toFixed(1)}px, ${cursor.y.toFixed(1)}px) scale(${pressScale.toFixed(3)})`;

    if (clickAge >= 0 && clickAge < 0.45) {
      const rp = clickAge / 0.45;
      ripEl.style.opacity = ((1 - rp) * 0.95).toFixed(3);
      ripEl.style.transform = `translate(${cursor.x.toFixed(1)}px, ${cursor.y.toFixed(1)}px) scale(${(0.35 + rp * 1.15).toFixed(3)})`;
    } else {
      ripEl.style.opacity = '0';
    }
  }

  function once(id, atTime, fn) {
    if (!fired[id] && simT >= atTime) {
      fired[id] = true;
      fn();
    }
  }

  function runTourTimeline() {
    /* =====================================================================
       ACT 1: 标题画面 (0.0s -> 8.0s)
       ===================================================================== */
    once('t_glide_pak', 2.2, () => {
      cursor.x = 1220;
      cursor.y = 880;
      glideTo('#title-pak', 2.2, 3.0, 960, 725, true);
    });
    once('t_click_pak', 3.15, () => {
      triggerClick('#title-pak', 960, 725);
      UI.expandTitleMenu();
    });
    once('t_hover_set', 4.0, () => {
      glideTo('.title-menu-item[data-idx="2"]', 4.0, 4.65, 960, 825, true);
    });
    once('t_sel_set', 4.65, () => {
      State.state.title.selectedIndex = 2;
      UI.renderTitleScreen();
    });
    once('t_hover_new', 5.05, () => {
      glideTo('.title-menu-item[data-idx="1"]', 5.05, 5.6, 960, 750, true);
    });
    once('t_sel_new', 5.6, () => {
      State.state.title.selectedIndex = 1;
      UI.renderTitleScreen();
    });
    once('t_hover_cont', 5.95, () => {
      glideTo('.title-menu-item[data-idx="0"]', 5.95, 6.55, 960, 675, true);
    });
    once('t_sel_cont', 6.55, () => {
      State.state.title.selectedIndex = 0;
      UI.renderTitleScreen();
    });
    once('t_click_cont', 7.15, () => {
      triggerClick('.title-menu-item[data-idx="0"]', 960, 675);
      Backdrop.spawnFx({
        type: 'burst', birthT: simT, duration: 0.6,
        x: 960, y: 675, maxR: 260, count: 18, color: '#ffe699', seed: 11
      });
      State.startTransition('story', () => {
        State.jumpDirect('story');
        UI.enterStory();
      });
    });

    /* =====================================================================
       ACT 2: 剧情画面 + 名词解释 + 章节标题卡 (8.0s -> 19.5s)
       ===================================================================== */
    once('st_glide_term', 10.9, () => {
      // Ensure line 1 has typed past 「天渊兽」
      UI.renderStoryFrame();
      glideTo('.lore-term[data-term="天渊兽"]', 10.9, 11.75, 845, 860, true);
    });
    once('st_open_gloss', 11.9, () => {
      triggerClick('.lore-term[data-term="天渊兽"]', 845, 860);
      State.state.story.openGlossaryTerm = '天渊兽';
      UI.resetStaticCaches();
      UI.renderStoryFrame();
    });
    once('st_glide_close', 13.7, () => {
      glideTo('#gloss-close', 13.7, 14.3, 1240, 560, true);
    });
    once('st_close_gloss', 14.45, () => {
      triggerClick('#gloss-close', 1240, 560);
      State.state.story.openGlossaryTerm = null;
      UI.resetStaticCaches();
      UI.renderStoryFrame();
    });
    once('st_next_speaker', 15.05, () => {
      // Switch to Speaker 2 (希娅)
      State.state.story.lineIndex = 1;
      State.state.story.lineStartedAt = simT;
      UI.resetStaticCaches();
      UI.renderStoryFrame();
    });
    once('st_chapter_card', 17.0, () => {
      cursor.visible = false;
      UI.openChapterCard();
    });
    once('st_to_quest', 19.1, () => {
      State.startTransition('quest', () => {
        State.jumpDirect('quest');
        State.state.story.chapterCardOpen = false;
        UI.renderQuestScreen();
      });
    });

    /* =====================================================================
       ACT 3: 任务柜台 (19.5s -> 29.0s)
       ===================================================================== */
    once('q_show_cursor', 20.1, () => {
      cursor.x = 460;
      cursor.y = 320;
      glideTo('.diff-tab[data-diff="hard"]', 20.1, 20.95, 360, 134, true);
    });
    once('q_click_hard', 21.1, () => {
      triggerClick('.diff-tab[data-diff="hard"]', 360, 134);
      State.state.quest.difficulty = 'hard';
      State.state.quest.tabChangedAt = simT;
      State.state.quest.detailChangedAt = simT;
      UI.renderQuestScreen();
    });
    once('q_glide_extreme', 22.1, () => {
      glideTo('.diff-tab[data-diff="extreme"]', 22.1, 22.9, 595, 134, true);
    });
    once('q_click_extreme', 23.05, () => {
      triggerClick('.diff-tab[data-diff="extreme"]', 595, 134);
      State.state.quest.difficulty = 'extreme';
      State.state.quest.selectedQuestId = 'q_e2'; // Briefly start on 2nd quest so clicking 熔炉之巅 shows active switch!
      State.state.quest.tabChangedAt = simT;
      State.state.quest.detailChangedAt = simT;
      UI.renderQuestScreen();
    });
    once('q_glide_roar', 23.8, () => {
      glideTo('.quest-card[data-qid="q_e1"]', 23.8, 24.55, 450, 260, true);
    });
    once('q_click_roar', 24.7, () => {
      triggerClick('.quest-card[data-qid="q_e1"]', 450, 260);
      State.state.quest.selectedQuestId = 'q_e1';
      State.state.quest.detailChangedAt = simT;
      UI.renderQuestScreen();
    });
    once('q_glide_depart', 27.1, () => {
      glideTo('#quest-depart-btn', 27.1, 28.0, 1720, 955, true);
    });
    once('q_click_depart', 28.25, () => {
      triggerClick('#quest-depart-btn', 1720, 955);
      State.startTransition('party', () => {
        State.jumpDirect('party');
        UI.renderPartyScreen();
      });
    });

    /* =====================================================================
       ACT 4: 编队与角色养成 (29.0s -> 44.0s)
       Swap Slot 4 (凛 -> 巴尔多), Open 艾琳 Detail, Swap Skill & Sigil w/ Live Diff, Sortie!
       ===================================================================== */
    once('p_glide_swap', 29.9, () => {
      glideTo('[data-swap-slot="3"]', 29.9, 30.75, 1545, 860, true);
    });
    once('p_click_swap', 30.9, () => {
      triggerClick('[data-swap-slot="3"]', 1545, 860);
      State.state.party.swapModalSlot = 3;
      UI.renderPartyScreen();
    });
    once('p_glide_baldo', 31.4, () => {
      glideTo('[data-pick-char="baldo"]', 31.4, 32.15, 650, 610, true);
    });
    once('p_click_baldo', 32.3, () => {
      triggerClick('[data-pick-char="baldo"]', 650, 610);
      State.state.party.slots[3] = 'baldo';
      State.state.party.swapModalSlot = null;
      UI.renderPartyScreen();
    });

    // Open 艾琳 Character Growth
    once('p_glide_aerin_det', 33.1, () => {
      glideTo('[data-detail-char="aerin"]', 33.1, 33.85, 355, 860, true);
    });
    once('p_click_aerin_det', 34.0, () => {
      triggerClick('[data-detail-char="aerin"]', 355, 860);
      State.state.party.detailCharId = 'aerin';
      State.state.party.detailOpen = true;
      State.state.party.detailOpenedAt = simT;
      UI.renderPartyScreen();
    });

    // Swap Skill Slot 3 -> 旋风破空斩 (with real-time stat diff preview!)
    once('cd_glide_sk3', 34.6, () => {
      glideTo('[data-edit-skill="2"]', 34.6, 35.25, 730, 415, true);
    });
    once('cd_click_sk3', 35.4, () => {
      triggerClick('[data-edit-skill="2"]', 730, 415);
      State.state.party.editingSkillSlot = 2;
      UI.renderCharDetail();
    });
    once('cd_glide_newsk', 35.75, () => {
      glideTo('[data-pick-skill="ae_s5"]', 35.75, 36.3, 1660, 690, true);
    });
    once('cd_hover_newsk', 36.25, () => {
      State.state.party.hoverSkillId = 'ae_s5';
      UI.renderCharDetail();
    });
    once('cd_click_newsk', 37.35, () => {
      triggerClick('[data-pick-skill="ae_s5"]', 1660, 690);
      State.state.builds.aerin.skills[2] = 'ae_s5';
      State.state.party.editingSkillSlot = null;
      State.state.party.hoverSkillId = null;
      UI.renderCharDetail();
    });

    // Swap Sigil Slot 2 -> 疾风猛攻 V [金] (with live stat & stacked trait diff preview!)
    once('cd_glide_sig2', 37.95, () => {
      glideTo('[data-edit-sigil="1"]', 37.95, 38.55, 960, 745, true);
    });
    once('cd_click_sig2', 38.7, () => {
      triggerClick('[data-edit-sigil="1"]', 960, 745);
      State.state.party.editingSigilSlot = 1;
      UI.renderCharDetail();
    });
    once('cd_glide_newsig', 39.05, () => {
      scrollInsidePicker('[data-pick-sigil="sig_wind_g"]');
      glideTo('[data-pick-sigil="sig_wind_g"]', 39.05, 39.65, 1660, 680, true);
    });
    once('cd_hover_newsig', 39.6, () => {
      State.state.party.hoverSigilId = 'sig_wind_g';
      UI.renderCharDetail();
      scrollInsidePicker('[data-pick-sigil="sig_wind_g"]');
    });
    once('cd_click_newsig', 40.75, () => {
      triggerClick('[data-pick-sigil="sig_wind_g"]', 1660, 680);
      State.state.builds.aerin.sigils[1] = 'sig_wind_g';
      State.state.party.editingSigilSlot = null;
      State.state.party.hoverSigilId = null;
      UI.renderCharDetail();
    });

    // Close Character Detail -> Click Sortie!
    once('cd_glide_close', 41.35, () => {
      glideTo('#cd-close-btn', 41.35, 41.9, 1785, 118, true);
    });
    once('cd_click_close', 42.05, () => {
      triggerClick('#cd-close-btn', 1785, 118);
      State.state.party.detailOpen = false;
      UI.renderPartyScreen();
    });
    once('p_glide_sortie', 42.4, () => {
      glideTo('#party-sortie-btn', 42.4, 43.25, 1730, 990, true);
    });
    once('p_click_sortie', 43.45, () => {
      triggerClick('#party-sortie-btn', 1730, 990);
      State.startTransition('battle', () => {
        cursor.visible = false;
        clearHoverClasses();
        State.jumpDirect('battle');
        Battle.initBattle(false);
        UI.resetStaticCaches();
      });
    });

    /* =====================================================================
       ACT 5: 战斗画面 + 奥义与全员连锁 + 破防 + 讨伐成功 (44.0s -> 80.0s)
       (Battle engine advances deterministically every FIXED_DT sub-step!)
       ===================================================================== */
    once('b_to_results', 79.6, () => {
      State.startTransition('results', () => {
        State.jumpDirect('results');
        UI.enterResults();
      });
    });

    /* =====================================================================
       ACT 6: 结算画面 (80.0s -> 90.0s)
       Rank C->S+, MVP Stamp, Level Up, Bronze -> Silver -> Gold Chests!
       ===================================================================== */
  }

  function resetTourState() {
    simT = 0;
    fired = {};
    cursor.visible = false;
    cursor.x = 1220;
    cursor.y = 880;
    cursor.fromX = 1220;
    cursor.fromY = 880;
    cursor.toX = 1220;
    cursor.toY = 880;
    cursor.moveStart = 0;
    cursor.moveEnd = 0;
    cursor.clickAt = -10;
    cursor.hoverSelector = null;
    clearHoverClasses();

    Backdrop.clearFx();
    State.resetAll(true);
    State.state.exportMode = true;
    UI.resetStaticCaches();
    UI.renderTitleScreen();
    UI.renderFrame(0);
    updateCursorVisual(0);
  }

  function advanceTo(targetT) {
    if (targetT < simT - 1e-6) {
      resetTourState();
    }

    // Fixed fine sub-steps so 3fps and 60fps execute IDENTICAL physics & event timing
    while (simT + FIXED_DT <= targetT + 1e-6) {
      simT += FIXED_DT;
      State.state.t = simT;
      runTourTimeline();
      if (State.state.screen === 'battle') {
        Battle.step(FIXED_DT);
      }
      // Step transition curtain midpoint synchronously inside sub-steps
      const tr = State.state.transition;
      if (tr.active) {
        const p = (simT - tr.startT) / tr.duration;
        if (p >= 0.48 && !tr.swapped) {
          tr.swapped = true;
          if (tr.onMidpoint) tr.onMidpoint();
        }
        if (p >= 1) tr.active = false;
      }
    }

    // Handle any tiny remainder cleanly
    const rem = targetT - simT;
    if (rem > 1e-5) {
      simT = targetT;
      State.state.t = simT;
      runTourTimeline();
      if (State.state.screen === 'battle') {
        Battle.step(rem);
      }
      const tr = State.state.transition;
      if (tr.active) {
        const p = (simT - tr.startT) / tr.duration;
        if (p >= 0.48 && !tr.swapped) {
          tr.swapped = true;
          if (tr.onMidpoint) tr.onMidpoint();
        }
        if (p >= 1) tr.active = false;
      }
    }

    UI.renderFrame(simT);
    updateCursorVisual(simT);
  }

  function waitNextPaint() {
    return new Promise((resolve) => {
      requestAnimationFrame(() => resolve());
    });
  }

  // Expose exact required Video Export API on `window.videoExport`
  window.videoExport = {
    runs: ['tour'],

    async begin(runId, opts) {
      if (runId !== 'tour') {
        throw new Error('Unknown videoExport runId: ' + runId);
      }
      exportFps = (opts && opts.fps) ? Number(opts.fps) : 60;
      document.body.classList.add('export-mode');
      resetTourState();
      await waitNextPaint();
      return { frames: Math.round(TOUR_DURATION * exportFps) };
    },

    async frame(i) {
      const targetT = Math.max(0, Number(i) / exportFps);
      advanceTo(targetT);
      await waitNextPaint();
    },

    end() {
      document.body.classList.remove('export-mode');
      clearHoverClasses();
      cursor.visible = false;
      updateCursorVisual(0);
      Backdrop.clearFx();
      State.resetAll(false);
      State.state.exportMode = false;
      UI.resetStaticCaches();
      UI.renderTitleScreen();
      UI.renderFrame(0);
    }
  };

  return {
    TOUR_DURATION
  };
})();
