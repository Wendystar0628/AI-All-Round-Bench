/* ==========================================================================
   《浮空群岛传说》 — Deterministic Canvas2D Backdrop & Kinetic UI-FX Engine
   100% driven by master time `t` (3fps / 60fps / 4K crisp & reproducible)
   ========================================================================== */

window.SkyUI = window.SkyUI || {};

window.SkyUI.Backdrop = (function () {
  let bgCanvas, bgCtx, fxCanvas, fxCtx;
  let logicalW = 1920, logicalH = 1080;

  // Deterministic pseudo-random helper
  function hash(n) {
    const x = Math.sin(n * 127.1 + 311.7) * 43758.5453123;
    return x - Math.floor(x);
  }

  // Active kinetic FX events (all pure functions of age = simT - birthT)
  let fxEvents = [];

  function init() {
    bgCanvas = document.getElementById('bg-canvas');
    fxCanvas = document.getElementById('fx-canvas');
    bgCtx = bgCanvas.getContext('2d');
    fxCtx = fxCanvas.getContext('2d');
    resize(1);
  }

  function resize(stageScale) {
    if (!bgCanvas || !fxCanvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const scaleFactor = Math.max(1, Math.min(2.2, stageScale * dpr));
    const pw = Math.round(logicalW * scaleFactor);
    const ph = Math.round(logicalH * scaleFactor);
    if (bgCanvas.width !== pw || bgCanvas.height !== ph) {
      bgCanvas.width = pw;
      bgCanvas.height = ph;
      fxCanvas.width = pw;
      fxCanvas.height = ph;
    }
    bgCtx.setTransform(scaleFactor, 0, 0, scaleFactor, 0, 0);
    fxCtx.setTransform(scaleFactor, 0, 0, scaleFactor, 0, 0);
  }

  function clearFx() {
    fxEvents = [];
  }

  function spawnFx(evt) {
    fxEvents.push(evt);
    if (fxEvents.length > 64) {
      fxEvents.shift();
    }
  }

  function drawSkyBackdrop(ctx, t, mode) {
    const W = logicalW, H = logicalH;

    // 1. Sky Gradient
    const grad = ctx.createLinearGradient(0, 0, 0, H);
    if (mode === 'title') {
      grad.addColorStop(0, '#091b42');
      grad.addColorStop(0.38, '#133e7a');
      grad.addColorStop(0.70, '#2a79b8');
      grad.addColorStop(0.90, '#8cc8e6');
      grad.addColorStop(1, '#f3dcb0');
    } else if (mode === 'results') {
      grad.addColorStop(0, '#0a1634');
      grad.addColorStop(0.45, '#193566');
      grad.addColorStop(0.80, '#445d8c');
      grad.addColorStop(1, '#c99b56');
    } else {
      // Story / Quest / Party — crisp serene twilight-azure sky-chart
      grad.addColorStop(0, '#08142e');
      grad.addColorStop(0.42, '#122c5c');
      grad.addColorStop(0.78, '#1e4f88');
      grad.addColorStop(1, '#4f8bb8');
    }
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // 2. Radiant Sunlit Sky Bloom
    const sunX = mode === 'title' ? W * 0.5 : W * 0.72;
    const sunY = mode === 'title' ? H * 0.52 : H * 0.24;
    const sunR = mode === 'title' ? 760 : 540;
    const sunGrad = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, sunR);
    sunGrad.addColorStop(0, mode === 'title' ? 'rgba(255, 245, 208, 0.36)' : 'rgba(130, 220, 255, 0.18)');
    sunGrad.addColorStop(0.45, mode === 'title' ? 'rgba(120, 214, 255, 0.14)' : 'rgba(230, 184, 86, 0.08)');
    sunGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = sunGrad;
    ctx.fillRect(0, 0, W, H);

    // 3. Subtle Celestial Chart Grid Arcs (Sky-navigation aesthetic)
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 232, 168, 0.08)';
    ctx.lineWidth = 1;
    const cx = W * 0.5, cy = H * 0.52;
    for (let r = 280; r <= 920; r += 160) {
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();
    }
    // Rotating astrolabe meridian rays
    const rot = t * 0.03;
    for (let i = 0; i < 8; i++) {
      const a = rot + (i * Math.PI) / 4;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * 180, cy + Math.sin(a) * 180);
      ctx.lineTo(cx + Math.cos(a) * 960, cy + Math.sin(a) * 960);
      ctx.stroke();
    }
    ctx.restore();

    // 4. Distant Painterly Floating Island Silhouettes (Soft sunlit top + atmospheric fade)
    ctx.save();
    const islands = [
      { bx: 230,  by: 645, w: 230, h: 52, phase: 0.4, alpha: 0.28 },
      { bx: 1650, by: 605, w: 265, h: 60, phase: 1.9, alpha: 0.25 },
      { bx: 490,  by: 735, w: 145, h: 34, phase: 3.1, alpha: 0.20 },
      { bx: 1400, by: 715, w: 165, h: 38, phase: 4.5, alpha: 0.19 }
    ];
    for (const isl of islands) {
      const fy = isl.by + Math.sin(t * 0.6 + isl.phase) * 8;
      const gIsl = ctx.createLinearGradient(isl.bx, fy - isl.h * 0.35, isl.bx, fy + isl.h * 1.45);
      gIsl.addColorStop(0, `rgba(196, 232, 255, ${isl.alpha * 0.85})`);
      gIsl.addColorStop(0.28, `rgba(28, 66, 122, ${isl.alpha * 0.95})`);
      gIsl.addColorStop(1, `rgba(18, 42, 86, 0)`);
      ctx.fillStyle = gIsl;
      ctx.beginPath();
      ctx.moveTo(isl.bx - isl.w * 0.5, fy);
      ctx.quadraticCurveTo(isl.bx - isl.w * 0.15, fy - isl.h * 0.38, isl.bx + isl.w * 0.12, fy - isl.h * 0.22);
      ctx.quadraticCurveTo(isl.bx + isl.w * 0.36, fy - isl.h * 0.30, isl.bx + isl.w * 0.5, fy);
      ctx.lineTo(isl.bx + isl.w * 0.32, fy + isl.h * 0.65);
      ctx.lineTo(isl.bx + isl.w * 0.12, fy + isl.h * 1.15);
      ctx.lineTo(isl.bx - isl.w * 0.04, fy + isl.h * 1.42);
      ctx.lineTo(isl.bx - isl.w * 0.22, fy + isl.h * 0.88);
      ctx.lineTo(isl.bx - isl.w * 0.38, fy + isl.h * 0.45);
      ctx.closePath();
      ctx.fill();

      // Delicate sunlit rim along top ridge
      ctx.strokeStyle = `rgba(255, 242, 198, ${isl.alpha * 0.9})`;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(isl.bx - isl.w * 0.45, fy - 1);
      ctx.quadraticCurveTo(isl.bx, fy - isl.h * 0.34, isl.bx + isl.w * 0.45, fy - 1);
      ctx.stroke();
    }
    ctx.restore();

    // 5. Layered Sea of Clouds (Smooth parallax bands along the bottom)
    ctx.save();
    for (let layer = 0; layer < 3; layer++) {
      const baseY = H - 210 + layer * 68;
      const speed = 14 + layer * 10;
      const alpha = mode === 'title' ? (0.14 + layer * 0.08) : (0.07 + layer * 0.05);
      ctx.fillStyle = mode === 'title'
        ? `rgba(255, 248, 232, ${alpha})`
        : `rgba(182, 224, 255, ${alpha})`;
      ctx.beginPath();
      ctx.moveTo(0, H);
      for (let x = 0; x <= W + 60; x += 48) {
        const w1 = Math.sin((x + t * speed) * 0.0045 + layer * 2.1) * (32 - layer * 5);
        const w2 = Math.cos((x - t * speed * 0.5) * 0.009 + layer) * 14;
        ctx.lineTo(x, baseY + w1 + w2);
      }
      ctx.lineTo(W, H);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    // 6. Sweeping Wind Current Ribbons
    ctx.save();
    for (let i = 0; i < 4; i++) {
      const y0 = 220 + i * 195;
      const phase = t * (0.45 + i * 0.1) + i * 1.7;
      const gradLine = ctx.createLinearGradient(0, y0, W, y0);
      gradLine.addColorStop(0, 'rgba(140, 240, 255, 0)');
      gradLine.addColorStop(0.5, 'rgba(180, 242, 255, 0.14)');
      gradLine.addColorStop(1, 'rgba(255, 230, 153, 0)');
      ctx.strokeStyle = gradLine;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let x = 0; x <= W; x += 64) {
        const dy = Math.sin(x * 0.003 + phase) * 28;
        if (x === 0) ctx.moveTo(x, y0 + dy);
        else ctx.lineTo(x, y0 + dy);
      }
      ctx.stroke();
    }
    ctx.restore();

    // 7. Rising Sunlit Golden Sky Motes (Deterministic)
    ctx.save();
    for (let i = 0; i < 55; i++) {
      const x0 = hash(i * 3.1) * W;
      const y0 = hash(i * 7.3) * H;
      const spdY = 14 + hash(i * 5.7) * 28;
      const spdX = 8 + hash(i * 11.1) * 16;
      const x = (x0 + t * spdX) % W;
      const y = (y0 - t * spdY % H + H) % H;
      const r = 1.2 + hash(i * 13.7) * 2.6;
      const pulse = 0.35 + 0.55 * Math.sin(t * 2.2 + i);
      ctx.fillStyle = i % 3 === 0
        ? `rgba(140, 240, 255, ${pulse * 0.7})`
        : `rgba(255, 232, 158, ${pulse * 0.78})`;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  function drawBattleBackdrop(ctx, t, battleState) {
    const W = logicalW, H = logicalH;
    const isLink = battleState && battleState.linkTimeActive;
    const isOD = battleState && battleState.bossMode === 'overdrive';
    const isBreak = battleState && battleState.bossMode === 'break';

    // 1. Clean Volcanic Summit Obsidian-Ember Arena Sky
    const grad = ctx.createLinearGradient(0, 0, 0, H);
    if (isLink) {
      grad.addColorStop(0, '#071429');
      grad.addColorStop(0.50, '#0f2c4a');
      grad.addColorStop(0.84, '#1b4761');
      grad.addColorStop(1, '#122130');
    } else if (isOD) {
      grad.addColorStop(0, '#14080e');
      grad.addColorStop(0.45, '#2b1116');
      grad.addColorStop(0.78, '#591e16');
      grad.addColorStop(1, '#260d0c');
    } else if (isBreak) {
      grad.addColorStop(0, '#081326');
      grad.addColorStop(0.50, '#132a47');
      grad.addColorStop(0.82, '#2a4a63');
      grad.addColorStop(1, '#141e2e');
    } else {
      grad.addColorStop(0, '#0d101c');
      grad.addColorStop(0.46, '#1f1824');
      grad.addColorStop(0.76, '#42201b');
      grad.addColorStop(1, '#181116');
    }
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // 2. Horizon Molten Glow (Subtle atmospheric anchor behind combat zone)
    const glowY = H * 0.56;
    const glowColor = isLink
      ? 'rgba(53, 197, 235, 0.22)'
      : isBreak
        ? 'rgba(130, 232, 255, 0.24)'
        : isOD
          ? 'rgba(255, 72, 38, 0.30)'
          : 'rgba(255, 118, 52, 0.20)';
    const hGrad = ctx.createRadialGradient(W * 0.5, glowY, 30, W * 0.5, glowY, 740);
    hGrad.addColorStop(0, glowColor);
    hGrad.addColorStop(0.6, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = hGrad;
    ctx.fillRect(0, 0, W, H);

    // 3. Perspective Geometric Arena Ring (Pure UI spatial stage — no cartoon art)
    ctx.save();
    ctx.translate(W * 0.5, H * 0.66);
    const ringColor = isLink
      ? 'rgba(108, 229, 255, 0.26)'
      : isOD
        ? 'rgba(255, 110, 74, 0.26)'
        : 'rgba(230, 184, 86, 0.18)';
    ctx.strokeStyle = ringColor;
    ctx.lineWidth = 1.5;

    const radii = [220, 420, 640, 860];
    for (const r of radii) {
      ctx.beginPath();
      ctx.ellipse(0, 0, r, r * 0.23, 0, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Perspective radial compass spokes
    const rot = t * (isLink ? 0.04 : 0.11);
    for (let i = 0; i < 12; i++) {
      const a = rot + (i * Math.PI) / 6;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * 140, Math.sin(a) * 140 * 0.23);
      ctx.lineTo(Math.cos(a) * 860, Math.sin(a) * 860 * 0.23);
      ctx.stroke();
    }
    ctx.restore();

    // 4. Subtle Target Core Presence Aura behind Lock-On Reticle (Abstract energy halo)
    if (battleState && !battleState.defeated) {
      const lx = battleState.lockX || 960;
      const ly = battleState.lockY || 410;
      const pulse = 1 + Math.sin(t * (isOD ? 6 : 2.5)) * 0.08;
      const rCore = (isOD ? 165 : 130) * pulse;
      const cGrad = ctx.createRadialGradient(lx, ly, 6, lx, ly, rCore);
      if (isBreak) {
        cGrad.addColorStop(0, 'rgba(140, 244, 255, 0.26)');
        cGrad.addColorStop(0.55, 'rgba(46, 167, 255, 0.08)');
        cGrad.addColorStop(1, 'rgba(0,0,0,0)');
      } else {
        cGrad.addColorStop(0, isOD ? 'rgba(255, 92, 52, 0.34)' : 'rgba(255, 130, 64, 0.22)');
        cGrad.addColorStop(0.55, 'rgba(255, 72, 34, 0.08)');
        cGrad.addColorStop(1, 'rgba(0,0,0,0)');
      }
      ctx.fillStyle = cGrad;
      ctx.beginPath();
      ctx.arc(lx, ly, rCore, 0, Math.PI * 2);
      ctx.fill();
    }

    // 5. Volcanic Embers / Link Time Crystal Motes (Deterministic by time)
    ctx.save();
    const emberTime = isLink ? t * 0.28 : (isOD ? t * 1.45 : t);
    for (let i = 0; i < 68; i++) {
      const x0 = hash(i * 4.3) * W;
      const y0 = hash(i * 9.1) * H;
      const sy = 36 + hash(i * 6.7) * 70;
      const sx = (hash(i * 2.9) - 0.5) * 42;
      const x = ((x0 + emberTime * sx + Math.sin(emberTime * 1.4 + i) * 18) % W + W) % W;
      const y = ((y0 - emberTime * sy) % H + H) % H;
      const sz = 1.4 + hash(i * 15.1) * 3.0;
      const a = 0.3 + 0.6 * Math.abs(Math.sin(t * 2.8 + i));
      ctx.fillStyle = isLink
        ? `rgba(140, 240, 255, ${a * 0.8})`
        : isBreak
          ? `rgba(180, 245, 255, ${a * 0.7})`
          : i % 4 === 0
            ? `rgba(255, 224, 130, ${a * 0.85})`
            : `rgba(255, 102, 52, ${a * 0.82})`;
      ctx.beginPath();
      ctx.arc(x, y, sz, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  function drawFxLayer(ctx, simT) {
    const W = logicalW, H = logicalH;
    ctx.clearRect(0, 0, W, H);

    // Prune expired events safely without mutating if scrubbing
    for (let i = 0; i < fxEvents.length; i++) {
      const e = fxEvents[i];
      const age = simT - e.birthT;
      if (age < 0 || age > e.duration) continue;
      const p = age / e.duration;
      const easeOut = 1 - Math.pow(1 - p, 3);

      ctx.save();
      if (e.type === 'slash') {
        // Crisp geometric ARPG UI light-slash across reticle
        ctx.translate(e.x, e.y);
        ctx.rotate(e.angle || -0.55);
        const len = 140 + easeOut * 220;
        const alpha = (1 - p) * 0.92;
        ctx.strokeStyle = e.color || '#85ffd0';
        ctx.globalAlpha = alpha;
        ctx.lineWidth = (1 - p) * 7 + 1;
        ctx.beginPath();
        ctx.moveTo(-len * 0.5, 0);
        ctx.quadraticCurveTo(0, -26 * (1 - p), len * 0.5, 0);
        ctx.stroke();

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = (1 - p) * 2.5;
        ctx.beginPath();
        ctx.moveTo(-len * 0.42, 0);
        ctx.lineTo(len * 0.42, 0);
        ctx.stroke();
      } else if (e.type === 'ring') {
        const rad = 28 + easeOut * (e.maxR || 240);
        ctx.strokeStyle = e.color || '#ffe699';
        ctx.globalAlpha = (1 - p) * 0.85;
        ctx.lineWidth = Math.max(1, (1 - p) * 8);
        ctx.beginPath();
        ctx.arc(e.x, e.y, rad, 0, Math.PI * 2);
        ctx.stroke();
      } else if (e.type === 'burst') {
        // Radiant sparks burst (Ougi / Break / Gold Chest)
        const count = e.count || 22;
        const maxDist = e.maxR || 260;
        for (let k = 0; k < count; k++) {
          const ang = (k / count) * Math.PI * 2 + hash(e.seed + k) * 0.25;
          const dist = (0.25 + hash(e.seed + k * 7) * 0.75) * maxDist * easeOut;
          const px = e.x + Math.cos(ang) * dist;
          const py = e.y + Math.sin(ang) * dist;
          const sz = (1 - p) * (4 + hash(e.seed + k * 3) * 5);
          ctx.globalAlpha = (1 - p) * 0.95;
          ctx.fillStyle = k % 2 === 0 ? '#ffffff' : (e.color || '#ffe699');
          ctx.save();
          ctx.translate(px, py);
          ctx.rotate(ang);
          ctx.fillRect(-sz * 2.2, -sz * 0.45, sz * 4.4, sz * 0.9);
          ctx.restore();
        }
      } else if (e.type === 'fullburst_vortex') {
        // Dynamic Elemental Full Burst Spiral Arcs (Keyed to First Caster's Element)
        ctx.translate(W * 0.5, H * 0.5);
        const alpha = Math.sin(p * Math.PI) * 0.85;
        ctx.globalAlpha = alpha;
        for (let r = 0; r < 6; r++) {
          const rad = 160 + r * 95 + p * 120;
          const startA = p * 5 + r * 1.1;
          ctx.strokeStyle = r % 2 === 0 ? (e.color || '#85ffd0') : '#ffe699';
          ctx.lineWidth = 4 - r * 0.4;
          ctx.beginPath();
          ctx.arc(0, 0, rad, startA, startA + 1.65);
          ctx.stroke();
        }
      }
      ctx.restore();
    }
  }

  function render(t, screenId, battleState) {
    if (!bgCtx || !fxCtx) return;
    if (screenId === 'battle') {
      drawBattleBackdrop(bgCtx, t, battleState);
    } else if (screenId === 'title') {
      drawSkyBackdrop(bgCtx, t, 'title');
    } else if (screenId === 'results') {
      drawSkyBackdrop(bgCtx, t, 'results');
    } else {
      drawSkyBackdrop(bgCtx, t, 'menu');
    }
    drawFxLayer(fxCtx, t);
  }

  return {
    init,
    resize,
    render,
    spawnFx,
    clearFx
  };
})();
