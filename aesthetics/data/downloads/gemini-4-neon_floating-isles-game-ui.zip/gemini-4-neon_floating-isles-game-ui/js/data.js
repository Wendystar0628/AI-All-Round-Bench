/* ==========================================================================
   《浮空群岛传说》 — Canonical Game Data, Roster, Quests, Skills, Sigils & Lore
   Strictly obeys Section 2.3 (6 Heroes & Boss 焰冠龙 伊格瑞斯)
   ========================================================================== */

window.SkyUI = window.SkyUI || {};

window.SkyUI.Data = (function () {
  const BOSS_IGNIS = {
    id: 'ignis',
    title: '天渊兽',
    epithet: '熔炉之巅的炙热支配者',
    name: '焰冠龙 伊格瑞斯',
    enName: 'IGNIS, THE FLAME-CROWNED',
    level: 85,
    element: 'fire',
    weakness: 'water',
    maxLayers: 5,
    hpPerLayer: 180000
  };

  const TRAITS = {
    atk:    { id: 'atk',    name: '攻击力',   maxLv: 30, desc: '提升基础攻击力与技能倍率', atkPerLv: 38, pwrPerLv: 42 },
    crit:   { id: 'crit',   name: '暴击率',   maxLv: 30, desc: '提升暴击触发概率与暴击伤害', critPerLv: 1.2, pwrPerLv: 36 },
    hp:     { id: 'hp',     name: '生命强化', maxLv: 30, desc: '提升最大生命值与受疗效率', hpPerLv: 420, pwrPerLv: 28 },
    ougi:   { id: 'ougi',   name: '奥义加速', maxLv: 20, desc: '加快奥义槽积攒速度与连锁威力', pwrPerLv: 48, ougiBonusPerLv: 2.5 },
    stun:   { id: 'stun',   name: '破防压制', maxLv: 20, desc: '提升对超载首领的模式槽削减力', stunPerLv: 14, pwrPerLv: 34 },
    link:   { id: 'link',   name: '连携共鸣', maxLv: 20, desc: '加快全队连携值增长与连携时刻增伤', pwrPerLv: 38, linkBonusPerLv: 2 }
  };

  const SIGIL_CATALOG = [
    { id: 'sig_atk_b',    name: '锐锋徽印 II',   rarity: 'bronze', trait: 'atk',  level: 4,  secondTrait: null },
    { id: 'sig_hp_b',     name: '磐石徽印 II',   rarity: 'bronze', trait: 'hp',   level: 5,  secondTrait: null },
    { id: 'sig_crit_s',   name: '星眼徽印 IV',   rarity: 'silver', trait: 'crit', level: 8,  secondTrait: null },
    { id: 'sig_atk_s',    name: '烈刃徽印 IV',   rarity: 'silver', trait: 'atk',  level: 8,  secondTrait: null },
    { id: 'sig_stun_s',   name: '崩甲徽印 IV',   rarity: 'silver', trait: 'stun', level: 7,  secondTrait: null },
    { id: 'sig_ougi_s',   name: '星核徽印 IV',   rarity: 'silver', trait: 'ougi', level: 7,  secondTrait: null },
    { id: 'sig_link_s',   name: '同调徽印 IV',   rarity: 'silver', trait: 'link', level: 8,  secondTrait: null },
    { id: 'sig_hp_s',     name: '苍壁徽印 IV',   rarity: 'silver', trait: 'hp',   level: 9,  secondTrait: null },
    { id: 'sig_wind_g',   name: '疾风猛攻 V',    rarity: 'gold',   trait: 'atk',  level: 10, secondTrait: { trait: 'crit', level: 6 } },
    { id: 'sig_sky_g',    name: '苍穹极意 V',    rarity: 'gold',   trait: 'ougi', level: 10, secondTrait: { trait: 'atk',  level: 6 } },
    { id: 'sig_break_g',  name: '天渊破阵 V',    rarity: 'gold',   trait: 'stun', level: 9,  secondTrait: { trait: 'crit', level: 5 } },
    { id: 'sig_link_g',   name: '晨星共鸣 V',    rarity: 'gold',   trait: 'link', level: 9,  secondTrait: { trait: 'ougi', level: 5 } },
    { id: 'sig_aegis_g',  name: '云海守护 V',    rarity: 'gold',   trait: 'hp',   level: 11, secondTrait: { trait: 'atk',  level: 4 } }
  ];

  const CHARACTERS = {
    aerin: {
      id: 'aerin',
      name: '艾琳',
      enName: 'AERIN',
      title: '晨星号领航剑士',
      weaponType: '单手剑',
      weaponIcon: 'sword',
      element: 'wind',
      level: 75,
      exp: 84200,
      expMax: 100000,
      baseStats: { atk: 2480, hp: 36800, crit: 24, stun: 210 },
      weapon: { name: '苍穹疾风剑', level: 75, element: 'wind', atkBonus: 820, trait: '风压连斩 · 暴击时回复奥义槽' },
      ougi: {
        name: '苍穹裂风斩',
        enName: 'TEMPEST AETHER',
        finisherName: '风极·天穹裁决',
        finisherEn: 'TEMPEST SOVEREIGN'
      },
      skillPool: [
        { id: 'ae_s1', name: '疾风连刺', icon: 'thrust',    cd: 8,  powerBonus: 180, atkMod: 45,  critMod: 2,  stunMod: 15, desc: '化作疾风突进连续斩击，快速积攒连携与奥义槽。' },
        { id: 'ae_s2', name: '翠岚月弧', icon: 'slash',     cd: 11, powerBonus: 210, atkMod: 75,  critMod: 4,  stunMod: 22, desc: '挥出高速风压月牙波，对目标造成高额暴击伤害。' },
        { id: 'ae_s3', name: '风盾壁垒', icon: 'aegis',     cd: 16, powerBonus: 140, atkMod: 0,   critMod: 0,  stunMod: 10, desc: '展开气旋护幕吸收伤害，短时间提升自身防御韧性。' },
        { id: 'ae_s4', name: '苍穹共鸣', icon: 'buff',      cd: 18, powerBonus: 190, atkMod: 50,  critMod: 5,  stunMod: 12, desc: '呼唤云海气流强化全队，攻速提升并加速奥义充能。' },
        { id: 'ae_s5', name: '旋风破空斩', icon: 'whirlwind', cd: 12, powerBonus: 310, atkMod: 165, critMod: 7,  stunMod: 46, desc: '腾空卷起暴烈风刃龙卷，重创首领并大幅削减模式槽。' },
        { id: 'ae_s6', name: '青空瞬步', icon: 'slash',     cd: 9,  powerBonus: 205, atkMod: 85,  critMod: 6,  stunMod: 18, desc: '绕至目标侧翼发动零隙追击，必定触发暴击加成。' }
      ],
      defaultSkills: ['ae_s1', 'ae_s2', 'ae_s3', 'ae_s4'],
      defaultSigils: ['sig_atk_s', 'sig_hp_b', 'sig_crit_s', 'sig_atk_b', 'sig_ougi_s', 'sig_link_s']
    },

    roke: {
      id: 'roke',
      name: '罗克',
      enName: 'ROKE',
      title: '烈焰突击枪手',
      weaponType: '长枪',
      weaponIcon: 'spear',
      element: 'fire',
      level: 74,
      exp: 61500,
      expMax: 96000,
      baseStats: { atk: 2620, hp: 38200, crit: 22, stun: 245 },
      weapon: { name: '赤星贯日枪', level: 74, element: 'fire', atkBonus: 860, trait: '炎枪破阵 · 蓄力突刺附带灼烧' },
      ougi: {
        name: '炽阳贯星枪',
        enName: 'SOLARIS LANCE',
        finisherName: '炎极·赤阳终焉',
        finisherEn: 'SOLARIS SUPERNOVA'
      },
      skillPool: [
        { id: 'rk_s1', name: '炎枪突刺', icon: 'thrust', cd: 9,  powerBonus: 195, atkMod: 60,  critMod: 3, stunMod: 25, desc: '燃起烈焰高速突进，贯穿前方敌人并造成火属性伤害。' },
        { id: 'rk_s2', name: '赤焰回旋', icon: 'flame',  cd: 13, powerBonus: 220, atkMod: 85,  critMod: 4, stunMod: 30, desc: '挥舞长枪卷起火环横扫四周，附加持续灼烧效果。' },
        { id: 'rk_s3', name: '燃魂战吼', icon: 'buff',   cd: 20, powerBonus: 175, atkMod: 95,  critMod: 3, stunMod: 10, desc: '激发高昂斗志，短时间内大幅提升全队攻击力。' },
        { id: 'rk_s4', name: '流星坠击', icon: 'cleave', cd: 15, powerBonus: 250, atkMod: 120, critMod: 5, stunMod: 42, desc: '跃向高空如流星般直刺地面，强力削减首领超载槽。' },
        { id: 'rk_s5', name: '炽轮破盾', icon: 'flame',  cd: 14, powerBonus: 240, atkMod: 100, critMod: 4, stunMod: 52, desc: '凝聚熔火枪势猛击目标护甲，大幅提升破防效率。' }
      ],
      defaultSkills: ['rk_s1', 'rk_s2', 'rk_s3', 'rk_s4'],
      defaultSigils: ['sig_atk_s', 'sig_crit_s', 'sig_stun_s', 'sig_ougi_s', 'sig_hp_s', 'sig_atk_b']
    },

    sia: {
      id: 'sia',
      name: '希娅',
      enName: 'SIA',
      title: '星潮咏唱魔导师',
      weaponType: '法杖',
      weaponIcon: 'staff',
      element: 'water',
      level: 74,
      exp: 73800,
      expMax: 96000,
      baseStats: { atk: 2410, hp: 34400, crit: 20, stun: 195 },
      weapon: { name: '沧溟星环杖', level: 74, element: 'water', atkBonus: 790, trait: '水灵加护 · 弱点克制伤害 +18%' },
      ougi: {
        name: '沧溟星瀑咏',
        enName: 'ABYSSAL CASCADE',
        finisherName: '水极·沧溟星潮',
        finisherEn: 'ABYSSAL DELUGE'
      },
      skillPool: [
        { id: 'si_s1', name: '冰晶星矢', icon: 'wave',  cd: 8,  powerBonus: 210, atkMod: 70,  critMod: 4, stunMod: 20, desc: '释放多枚追踪水蓝晶矢，精准打击火属性弱点。' },
        { id: 'si_s2', name: '潮汐圣愈', icon: 'heal',  cd: 16, powerBonus: 190, atkMod: 30,  critMod: 0, stunMod: 10, desc: '召来温柔云海泉流，立刻回复全体队员大量生命。' },
        { id: 'si_s3', name: '深蓝涡流', icon: 'wave',  cd: 14, powerBonus: 245, atkMod: 110, critMod: 5, stunMod: 32, desc: '在目标脚下唤起高压水涡，持续造成弱点属性重创。' },
        { id: 'si_s4', name: '星海庇佑', icon: 'aegis', cd: 20, powerBonus: 185, atkMod: 40,  critMod: 3, stunMod: 15, desc: '为全队编织水镜护壁，降低受到的烈焰伤害。' },
        { id: 'si_s5', name: '霜澜新星', icon: 'wave',  cd: 15, powerBonus: 265, atkMod: 130, critMod: 6, stunMod: 35, desc: '瞬发广域霜涛冲击，降低敌人攻速并积累连携值。' }
      ],
      defaultSkills: ['si_s1', 'si_s2', 'si_s3', 'si_s4'],
      defaultSigils: ['sig_ougi_s', 'sig_atk_s', 'sig_link_s', 'sig_hp_s', 'sig_crit_s', 'sig_sky_g']
    },

    baldo: {
      id: 'baldo',
      name: '巴尔多',
      enName: 'BALDO',
      title: '重岩先锋重斧手',
      weaponType: '大斧',
      weaponIcon: 'axe',
      element: 'earth',
      level: 75,
      exp: 68900,
      expMax: 100000,
      baseStats: { atk: 2560, hp: 46500, crit: 18, stun: 320 },
      weapon: { name: '裂峰玄岩巨斧', level: 75, element: 'earth', atkBonus: 840, trait: '撼地重压 · 超载破防压制 +22%' },
      ougi: {
        name: '断岳崩岩击',
        enName: 'TERRA BREAKER',
        finisherName: '岩极·碎岳星陨',
        finisherEn: 'TERRA CATACLYSM'
      },
      skillPool: [
        { id: 'ba_s1', name: '裂地重劈', icon: 'cleave', cd: 10, powerBonus: 225, atkMod: 90,  critMod: 2, stunMod: 48, desc: '蓄力纵劈震裂大地，造成极高的破防压制值。' },
        { id: 'ba_s2', name: '岩甲不动', icon: 'aegis',  cd: 18, powerBonus: 180, atkMod: 20,  critMod: 0, stunMod: 25, desc: '覆上厚重岩晶护甲，霸体承伤并吸引首领仇恨。' },
        { id: 'ba_s3', name: '山崩回旋', icon: 'whirlwind', cd: 13, powerBonus: 230, atkMod: 105, critMod: 3, stunMod: 40, desc: '抡动巨斧连环旋斩，以排山之势压制超载首领。' },
        { id: 'ba_s4', name: '震岳咆哮', icon: 'buff',   cd: 19, powerBonus: 200, atkMod: 65,  critMod: 2, stunMod: 55, desc: '发出震撼空域的战吼，令全队破防效率大幅提升。' }
      ],
      defaultSkills: ['ba_s1', 'ba_s2', 'ba_s3', 'ba_s4'],
      defaultSigils: ['sig_break_g', 'sig_hp_s', 'sig_stun_s', 'sig_atk_s', 'sig_aegis_g', 'sig_ougi_s']
    },

    rin: {
      id: 'rin',
      name: '凛',
      enName: 'RIN',
      title: '影刃双刀游侠',
      weaponType: '双刀',
      weaponIcon: 'twinblades',
      element: 'dark',
      level: 72,
      exp: 42000,
      expMax: 92000,
      baseStats: { atk: 2490, hp: 31800, crit: 32, stun: 175 },
      weapon: { name: '夜羽双月刃', level: 72, element: 'dark', atkBonus: 760, trait: '暗影瞬袭 · 背后暴击伤害提升' },
      ougi: {
        name: '冥月千影舞',
        enName: 'ECLIPSE PHANTOM',
        finisherName: '暗极·永夜星蚀',
        finisherEn: 'ECLIPSE OBLIVION'
      },
      skillPool: [
        { id: 'rn_s1', name: '影步双斩', icon: 'slash',  cd: 7,  powerBonus: 185, atkMod: 75, critMod: 7, stunMod: 15, desc: '化影贴近瞬斩二连击，高概率触发暴击。' },
        { id: 'rn_s2', name: '幽刃旋舞', icon: 'cleave', cd: 11, powerBonus: 205, atkMod: 95, critMod: 6, stunMod: 18, desc: '双刀交错切出暗芒风暴，快速积累连击数。' },
        { id: 'rn_s3', name: '夜幕残影', icon: 'buff',   cd: 16, powerBonus: 165, atkMod: 45, critMod: 8, stunMod: 10, desc: '留下幻影规避攻击并强化下一次技能威力。' },
        { id: 'rn_s4', name: '噬影绝杀', icon: 'thrust', cd: 14, powerBonus: 225, atkMod: 115, critMod: 9, stunMod: 20, desc: '贯穿目标弱点的致命一击，对破防敌人增伤。' }
      ],
      defaultSkills: ['rn_s1', 'rn_s2', 'rn_s3', 'rn_s4'],
      defaultSigils: ['sig_crit_s', 'sig_atk_b', 'sig_ougi_s', 'sig_link_s', 'sig_hp_b', 'sig_atk_s']
    },

    viola: {
      id: 'viola',
      name: '薇奥拉',
      enName: 'VIOLA',
      title: '圣辉双枪神射手',
      weaponType: '双枪',
      weaponIcon: 'dualguns',
      element: 'light',
      level: 73,
      exp: 54100,
      expMax: 94000,
      baseStats: { atk: 2440, hp: 33100, crit: 28, stun: 190 },
      weapon: { name: '晨曦双星铳', level: 73, element: 'light', atkBonus: 780, trait: '光弹连射 · 远距持续积攒连携' },
      ougi: {
        name: '极光星雨炮',
        enName: 'AURORA SALVO',
        finisherName: '光极·晨星圣裁',
        finisherEn: 'AURORA JUDGMENT'
      },
      skillPool: [
        { id: 'vi_s1', name: '圣光齐射', icon: 'thrust', cd: 8,  powerBonus: 190, atkMod: 70,  critMod: 5, stunMod: 18, desc: '高速倾泻光属性弹幕，精准压制空中目标。' },
        { id: 'vi_s2', name: '星芒标记', icon: 'buff',   cd: 15, powerBonus: 185, atkMod: 55,  critMod: 6, stunMod: 22, desc: '标记首领要害，令全队对其暴击率提升。' },
        { id: 'vi_s3', name: '极光穿刺', icon: 'slash',  cd: 13, powerBonus: 225, atkMod: 105, critMod: 5, stunMod: 26, desc: '双枪合束射出高能光矢，穿透护甲造成重伤。' },
        { id: 'vi_s4', name: '浮空跃射', icon: 'whirlwind', cd: 12, powerBonus: 195, atkMod: 80, critMod: 5, stunMod: 16, desc: '后跃腾空同时扫射地面，兼具机动与连携充能。' }
      ],
      defaultSkills: ['vi_s1', 'vi_s2', 'vi_s3', 'vi_s4'],
      defaultSigils: ['sig_link_g', 'sig_crit_s', 'sig_atk_s', 'sig_ougi_s', 'sig_hp_b', 'sig_stun_s']
    }
  };

  // Quests across 4 difficulty tiers (Strictly no unlisted boss/character names!)
  const QUESTS = [
    // 普通 NORMAL
    {
      id: 'q_n1',
      difficulty: 'normal',
      diffLabel: '普通',
      stars: '★★',
      name: '晨星号航路护航',
      enName: 'MORNINGSTAR AIRLANE ESCORT',
      type: '空域护航',
      location: '碧风群岛 · 高空航道',
      timeLimit: '15:00',
      recPower: 9800,
      objective: '护送补给飞空艇穿越风蚀空域，击退沿途袭来的狂风魔物群，确保航路补给安全抵达。',
      boss: null,
      targetSummary: { label: '空域魔物群', element: 'wind', weakness: 'fire', note: '护航防卫 · 无天渊兽反应' },
      rewards: [
        { name: '风纹矿石', rarity: 'bronze', icon: 'ore' },
        { name: '空铁锭', rarity: 'bronze', icon: 'ore' },
        { name: '星眼徽印 IV', rarity: 'silver', icon: 'sigil' },
        { name: '浮空晶屑', rarity: 'bronze', icon: 'crystal' }
      ]
    },
    {
      id: 'q_n2',
      difficulty: 'normal',
      diffLabel: '普通',
      stars: '★★',
      name: '风蚀遗迹的共鸣石',
      enName: 'RESONANCE OF WIND RUINS',
      type: '遗迹探索',
      location: '苍穹浮岛 · 古代星盘遗迹',
      timeLimit: '20:00',
      recPower: 11200,
      objective: '调查古代星盘装置异常共鸣，回收三枚失落的导航晶核并肃清遗迹守卫魔物。',
      boss: null,
      targetSummary: { label: '遗迹晶核守卫', element: 'earth', weakness: 'wind', note: '探索回收 · 古代航图线索' },
      rewards: [
        { name: '星盘碎片', rarity: 'silver', icon: 'crystal' },
        { name: '磐石徽印 II', rarity: 'bronze', icon: 'sigil' },
        { name: '风纹矿石', rarity: 'bronze', icon: 'ore' },
        { name: '古代银币', rarity: 'silver', icon: 'core' }
      ]
    },
    {
      id: 'q_n3',
      difficulty: 'normal',
      diffLabel: '普通',
      stars: '★★☆',
      name: '云海灯塔信标校准',
      enName: 'CLOUD SEA BEACON CALIBRATION',
      type: '遗迹探索',
      location: '晨曦浮岛 · 东翼航标塔',
      timeLimit: '15:00',
      recPower: 12100,
      objective: '云海潮汐扰乱了航标灯塔的浮力共鸣，驱散盘踞于塔顶的风暴魔物并重启导航信标。',
      boss: null,
      targetSummary: { label: '风暴巡游魔物群', element: 'wind', weakness: 'fire', note: '航标修复 · 常规清剿' },
      rewards: [
        { name: '浮空晶屑', rarity: 'bronze', icon: 'crystal' },
        { name: '锐锋徽印 II', rarity: 'bronze', icon: 'sigil' },
        { name: '空铁锭', rarity: 'bronze', icon: 'ore' },
        { name: '星盘碎片', rarity: 'silver', icon: 'crystal' }
      ]
    },

    // 困难 HARD
    {
      id: 'q_h1',
      difficulty: 'hard',
      diffLabel: '困难',
      stars: '★★★',
      name: '熔岩裂谷的炙热前兆',
      enName: 'EMBERS OF THE MAGMA RIFT',
      type: '精英清剿',
      location: '火山岛 · 外环熔岩裂谷',
      timeLimit: '18:00',
      recPower: 14600,
      objective: '火山岛外环出现强烈热流异动，清剿因高温暴走的熔核魔物，开辟通往熔炉之巅的着陆点。',
      boss: null,
      targetSummary: { label: '暴走熔核魔物群', element: 'fire', weakness: 'water', note: '高热空域 · 建议携带水属性' },
      rewards: [
        { name: '炽炎矿髓', rarity: 'silver', icon: 'ore' },
        { name: '烈刃徽印 IV', rarity: 'silver', icon: 'sigil' },
        { name: '熔岩铁矿', rarity: 'bronze', icon: 'ore' },
        { name: '星核徽印 IV', rarity: 'silver', icon: 'sigil' }
      ]
    },
    {
      id: 'q_h2',
      difficulty: 'hard',
      diffLabel: '困难',
      stars: '★★★☆',
      name: '沉眠之巢的余烬',
      enName: 'ASHES OF THE SLUMBERING NEST',
      type: '首领讨伐',
      location: '火山岛 · 火山口外廊',
      timeLimit: '20:00',
      recPower: 15800,
      objective: '侦测到苏醒初期的天渊兽热源信号。前往火山口外廊迎击「焰冠龙 伊格瑞斯」，试探其攻势并击退其苏醒咆哮。',
      boss: { ...BOSS_IGNIS, level: 74, note: '苏醒初期形态' },
      rewards: [
        { name: '炽炎龙鳞', rarity: 'silver', icon: 'scale' },
        { name: '崩甲徽印 IV', rarity: 'silver', icon: 'sigil' },
        { name: '熔岩铁矿', rarity: 'bronze', icon: 'ore' },
        { name: '苍壁徽印 IV', rarity: 'silver', icon: 'sigil' }
      ]
    },
    {
      id: 'q_h3',
      difficulty: 'hard',
      diffLabel: '困难',
      stars: '★★★',
      name: '高空风暴下的紧急补给',
      enName: 'STORMFRONT SUPPLY ESCORT',
      type: '空域护航',
      location: '火山外海 · 乱流云廊',
      timeLimit: '16:00',
      recPower: 15200,
      objective: '伴随火山热流生成的强雷云廊中，护送冷却晶石补给艇安全抵达晨星号前线锚点。',
      boss: null,
      targetSummary: { label: '热流掠空魔物群', element: 'fire', weakness: 'water', note: '空域防卫 · 限时护航' },
      rewards: [
        { name: '星眼徽印 IV', rarity: 'silver', icon: 'sigil' },
        { name: '同调徽印 IV', rarity: 'silver', icon: 'sigil' },
        { name: '风纹碎片', rarity: 'bronze', icon: 'crystal' },
        { name: '熔岩铁矿', rarity: 'bronze', icon: 'ore' }
      ]
    },

    // 极难 EXTREME (Signature Demo Mission!)
    {
      id: 'q_e1',
      difficulty: 'extreme',
      diffLabel: '极难',
      stars: '★★★★☆',
      name: '熔炉之巅的咆哮',
      enName: 'ROAR OF THE FURNACE SUMMIT',
      type: '首领讨伐',
      location: '火山岛 · 熔岩竞技场',
      timeLimit: '20:00',
      recPower: 18000,
      objective: '天渊兽「焰冠龙 伊格瑞斯」已于火山岛核心彻底苏醒，浮空群岛的热流平衡濒临崩坏！驾驶晨星号直抵熔岩竞技场，与伙伴携手将其彻底讨伐！',
      boss: BOSS_IGNIS,
      rewards: [
        { name: '天渊焰冠核', rarity: 'gold',   icon: 'core' },
        { name: '苍穹极意 V', rarity: 'gold',   icon: 'sigil' },
        { name: '炽炎龙鳞',   rarity: 'silver', icon: 'scale' },
        { name: '熔岩铁矿',   rarity: 'bronze', icon: 'ore' }
      ]
    },
    {
      id: 'q_e2',
      difficulty: 'extreme',
      diffLabel: '极难',
      stars: '★★★★',
      name: '灼热空域双线压制',
      enName: 'SCORCHING SKYLINE DEFENSE',
      type: '空域护航',
      location: '火山岛 · 晨星号降落甲板',
      timeLimit: '15:00',
      recPower: 17200,
      objective: '在剧烈上升气流中守卫晨星号降落甲板，抵挡连续三波高阶魔物突袭，确保引擎冷却完成。',
      boss: null,
      targetSummary: { label: '高阶炎翼魔物波次', element: 'fire', weakness: 'water', note: '阵地防守 · 考验连携爆发' },
      rewards: [
        { name: '晨星共鸣 V', rarity: 'gold',   icon: 'sigil' },
        { name: '炽炎龙鳞',   rarity: 'silver', icon: 'scale' },
        { name: '同调徽印 IV', rarity: 'silver', icon: 'sigil' },
        { name: '风纹碎片',   rarity: 'bronze', icon: 'crystal' }
      ]
    },
    {
      id: 'q_e3',
      difficulty: 'extreme',
      diffLabel: '极难',
      stars: '★★★★',
      name: '地脉熔核星晶采掘',
      enName: 'DEEP CORE CRYSTAL SURVEY',
      type: '遗迹探索',
      location: '火山岛 · 熔岩地脉深窟',
      timeLimit: '18:00',
      recPower: 17600,
      objective: '深入火山地脉遗迹，在高温崩塌前采集高纯度浮力星晶并击溃守护遗迹的古代构装体。',
      boss: null,
      targetSummary: { label: '熔岩遗迹构装体', element: 'earth', weakness: 'wind', note: '高压遗迹 · 稀有徽印产出' },
      rewards: [
        { name: '天渊破阵 V', rarity: 'gold',   icon: 'sigil' },
        { name: '星穹辉晶',   rarity: 'silver', icon: 'crystal' },
        { name: '崩甲徽印 IV', rarity: 'silver', icon: 'sigil' },
        { name: '熔岩铁矿',   rarity: 'bronze', icon: 'ore' }
      ]
    },

    // 传说 LEGEND
    {
      id: 'q_l1',
      difficulty: 'legend',
      diffLabel: '传说',
      stars: '★★★★★',
      name: '终焉熔炉·焰冠再临',
      enName: 'FINAL FURNACE · IGNIS AWAKENED',
      type: '首领讨伐',
      location: '火山岛 · 熔岩竞技场深渊层',
      timeLimit: '15:00',
      recPower: 22500,
      objective: '吸收云海深处天渊之力的极境讨伐任务！直面完全觉醒的「焰冠龙 伊格瑞斯」，以四人全员连锁奥义击溃毁灭之焰。',
      boss: { ...BOSS_IGNIS, level: 99, note: '天渊觉醒极境形态' },
      rewards: [
        { name: '天渊焰冠核·极', rarity: 'gold', icon: 'core' },
        { name: '疾风猛攻 V',     rarity: 'gold', icon: 'sigil' },
        { name: '天渊破阵 V',     rarity: 'gold', icon: 'sigil' },
        { name: '星穹辉晶',       rarity: 'silver', icon: 'crystal' }
      ]
    },
    {
      id: 'q_l2',
      difficulty: 'legend',
      diffLabel: '传说',
      stars: '★★★★★',
      name: '云海深渊的回响',
      enName: 'ECHOES BENEATH THE CLOUD SEA',
      type: '遗迹探索',
      location: '无尽云海 · 传说边境航域',
      timeLimit: '25:00',
      recPower: 21000,
      objective: '驾驶晨星号下潜至传说中无人涉足的云海深层，记录古老航标回响，追寻「云海之下未知大地」的真相。',
      boss: null,
      targetSummary: { label: '深渊回响异常体', element: 'dark', weakness: 'light', note: '极秘航行 · 传说线索' },
      rewards: [
        { name: '云海守护 V', rarity: 'gold',   icon: 'sigil' },
        { name: '深渊星图残页', rarity: 'gold', icon: 'crystal' },
        { name: '苍穹极意 V', rarity: 'gold',   icon: 'sigil' },
        { name: '古代银币',   rarity: 'silver', icon: 'core' }
      ]
    },
    {
      id: 'q_l3',
      difficulty: 'legend',
      diffLabel: '传说',
      stars: '★★★★★',
      name: '苍穹星盘·极境试炼',
      enName: 'CELESTIAL ASTROLABE TRIAL',
      type: '精英清剿',
      location: '浮空群岛核心 · 星盘圣殿',
      timeLimit: '15:00',
      recPower: 21800,
      objective: '启动太古空行者留下的星盘试炼阵，在无休止的强敌轮战中锤炼四人小队的连携与奥义默契。',
      boss: null,
      targetSummary: { label: '星盘幻象魔物群', element: 'light', weakness: 'dark', note: '极境连战 · 全金徽印试炼' },
      rewards: [
        { name: '晨星共鸣 V', rarity: 'gold', icon: 'sigil' },
        { name: '疾风猛攻 V', rarity: 'gold', icon: 'sigil' },
        { name: '星穹辉晶',   rarity: 'silver', icon: 'crystal' },
        { name: '古代银币',   rarity: 'silver', icon: 'core' }
      ]
    }
  ];

  const GLOSSARY = {
    '空行者': {
      term: '空行者',
      en: 'SKYFARERS',
      category: '世界观 · 职业',
      body: '驾驶飞空艇穿梭于浮空群岛之间，承接公国与岛屿委托、讨伐失控魔物与探索古代遗迹的冒险者。晨星号小队正是其中声名鹊起的精锐队伍。'
    },
    '天渊兽': {
      term: '天渊兽',
      en: 'ABYSSAL BEASTS',
      category: '世界观 · 远古灾厄',
      body: '自太古时代便沉睡在浮空群岛地脉深处的超巨型元素巨兽。随着群岛浮力核心波动，它们接连苏醒，每一次咆哮都足以撼动整座岛屿的平衡。'
    },
    '晨星号': {
      term: '晨星号',
      en: 'THE MORNINGSTAR',
      category: '飞空艇 · 主角据点',
      body: '艾琳一行人驾驶的高速探索型飞空艇，搭载古代星盘导航仪与双翼风晶推进器，专为突破云海乱流与追寻「云海之下未知大地」而打造。'
    },
    '浮空群岛': {
      term: '浮空群岛',
      en: 'THE FLOATING ISLES',
      category: '世界观 · 地理',
      body: '漂浮在无边云海之上的成千上万座岛屿，由地脉中的星晶矿脉维系浮力。各岛生态迥异，从翠风高原到炽热火山岛，皆靠飞空艇彼此相连。'
    }
  };

  // Story dialogue strictly featuring our canonical heroes!
  const STORY_SCRIPT = [
    {
      speakerId: 'aerin',
      locationZh: '飞空艇「晨星号」· 舰桥甲板',
      locationEn: 'AIRSHIP MORNINGSTAR · BRIDGE DECK',
      segments: [
        { text: '风向变了……火山岛上空的热流正在冲破云层。作为' },
        { term: '空行者' },
        { text: '，我们绝不能坐视那头' },
        { term: '天渊兽' },
        { text: '彻底崩坏这片浮空航域的平衡！' }
      ]
    },
    {
      speakerId: 'sia',
      locationZh: '飞空艇「晨星号」· 星盘观测台',
      locationEn: 'AIRSHIP MORNINGSTAR · ASTROLABE DECK',
      segments: [
        { text: '星盘读数已达临界！熔岩竞技场苏醒的正是火属性「焰冠龙 伊格瑞斯」——交给我，水属性咏唱正好能压制它的烈焰！' }
      ]
    },
    {
      speakerId: 'roke',
      locationZh: '飞空艇「晨星号」· 舰桥甲板',
      locationEn: 'AIRSHIP MORNINGSTAR · BRIDGE DECK',
      segments: [
        { text: '哈哈，这才配得上我们「' },
        { term: '晨星号' },
        { text: '」的名号！巴尔多，等会儿超载破防就看你我顶在最前面了！' }
      ]
    },
    {
      speakerId: 'baldo',
      locationZh: '飞空艇「晨星号」· 武器整备舱',
      locationEn: 'AIRSHIP MORNINGSTAR · ARMORY BAY',
      segments: [
        { text: '放心吧！这把巨斧早就按捺不住了。穿过这片' },
        { term: '浮空群岛' },
        { text: '最炙热的火山云层，我们距离云海之下的传说又近了一步。准备接取讨伐委托吧！' }
      ]
    }
  ];

  const CHAPTER_CARD = {
    numEn: 'CHAPTER 04',
    numZh: '第 四 章',
    titleZh: '炽焰苏醒之岛',
    titleEn: 'ISLE OF THE AWAKENED FLAME'
  };

  // Results Loot Table (Bronze -> Silver -> Gold chests)
  const RESULTS_LOOT = {
    bronze: [
      { name: '熔岩铁矿', sub: '强化素材 · 火山岛', rarity: 'bronze', icon: 'ore', qty: 6 },
      { name: '风纹碎片', sub: '星晶素材 · 空域', rarity: 'bronze', icon: 'crystal', qty: 4 }
    ],
    silver: [
      { name: '炽炎龙鳞', sub: '首领素材 · 伊格瑞斯', rarity: 'silver', icon: 'scale', qty: 3 },
      { name: '星眼徽印 IV', sub: '徽印 · 暴击率 +Lv.8', rarity: 'silver', icon: 'sigil', qty: 1 }
    ],
    gold: [
      { name: '天渊焰冠核', sub: '稀有核心 · 天渊兽讨伐', rarity: 'gold', icon: 'core', qty: 1 },
      { name: '苍穹极意 V', sub: '传奇徽印 · 奥义加速+10 / 攻击+6', rarity: 'gold', icon: 'sigil', qty: 1 }
    ]
  };

  return {
    BOSS_IGNIS,
    TRAITS,
    SIGIL_CATALOG,
    CHARACTERS,
    QUESTS,
    GLOSSARY,
    STORY_SCRIPT,
    CHAPTER_CARD,
    RESULTS_LOOT
  };
})();
