/**
 * 纯代码绘制的三款游戏专属主题动态背景引擎（Canvas 2D）
 * 完全确定性：所有粒子、网格、星轨与逆流溯回雨均以伪随机种子 + 外部时刻 t 确定性计算，
 * 零外部图片依赖（100% 兼容 file://），且在 videoExport 逐帧导出模式下完美丝滑连贯！
 */
(function () {
  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0;
      a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // 预生成确定性粒子表，避免逐帧分配和随机抖动
  const rngEf = mulberry32(104729);
  const EF_PARTICLES = Array.from({ length: 65 }, () => ({
    x: rngEf(),
    y: rngEf(),
    s: 1.5 + rngEf() * 4.2,
    vy: 0.008 + rngEf() * 0.022,
    vx: 0.004 + rngEf() * 0.012,
    gold: rngEf() > 0.72,
    phase: rngEf() * Math.PI * 2,
  }));

  const rngSr = mulberry32(224737);
  const SR_STARS = Array.from({ length: 190 }, () => ({
    x: rngSr(),
    y: rngSr(),
    r: 0.5 + rngSr() * 1.9,
    twinkle: 0.6 + rngSr() * 2.2,
    phase: rngSr() * Math.PI * 2,
    tint: rngSr(),
  }));
  const SR_STREAKS = Array.from({ length: 14 }, () => ({
    x0: rngSr(),
    y0: rngSr(),
    len: 0.08 + rngSr() * 0.16,
    speed: 0.06 + rngSr() * 0.11,
    phase: rngSr() * 10,
    gold: rngSr() > 0.35,
  }));

  const rngWw = mulberry32(350377);
  const WW_RAIN = Array.from({ length: 95 }, () => ({
    x: rngWw(),
    y: rngWw(),
    len: 0.025 + rngWw() * 0.065,
    speed: 0.055 + rngWw() * 0.11,
    r: 1.0 + rngWw() * 1.8,
    alpha: 0.18 + rngWw() * 0.45,
    gold: rngWw() > 0.91,
  }));

  class ThemeBackground {
    constructor(canvas) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d');
      this.mode = 'gallery'; // 'gallery' | 'endfield' | 'starrail' | 'wuthering' | 'studio'
      this.intensity = 1.0;  // 展示片拆解阶段可淡化为干净制图深灰室，定格阶段回到 1.0 专属主题背景
      this.resize();
    }

    resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(1, Math.round(window.innerWidth * dpr));
      const h = Math.max(1, Math.round(window.innerHeight * dpr));
      if (this.canvas.width !== w || this.canvas.height !== h) {
        this.canvas.width = w;
        this.canvas.height = h;
      }
      this.w = w;
      this.h = h;
    }

    render(mode, t, intensity = 1.0) {
      this.resize();
      const ctx = this.ctx;
      const w = this.w;
      const h = this.h;
      ctx.save();
      ctx.clearRect(0, 0, w, h);

      // 始终先铺一层高级深色调策展底色
      const baseG = ctx.createRadialGradient(w * 0.5, h * 0.46, 0, w * 0.5, h * 0.5, Math.max(w, h) * 0.72);
      baseG.addColorStop(0, '#131720');
      baseG.addColorStop(1, '#07090d');
      ctx.fillStyle = baseG;
      ctx.fillRect(0, 0, w, h);

      if (intensity > 0.005) {
        ctx.save();
        ctx.globalAlpha = Math.max(0, Math.min(1, intensity));
        if (mode === 'gallery') {
          this._drawGallery(ctx, w, h, t);
        } else if (mode === 'endfield') {
          this._drawEndfield(ctx, w, h, t);
        } else if (mode === 'starrail') {
          this._drawStarRail(ctx, w, h, t);
        } else if (mode === 'wuthering') {
          this._drawWuthering(ctx, w, h, t);
        }
        ctx.restore();
      }

      // 展示片制图室微弱工程点阵（当 intensity < 0.85 时微微显现，强化字体设计工作台质感）
      if (intensity < 0.88 && mode !== 'gallery') {
        const studioA = (1 - intensity) * 0.24;
        ctx.save();
        ctx.strokeStyle = `rgba(180, 198, 220, ${studioA * 0.35})`;
        ctx.lineWidth = Math.max(1, w / 1920);
        const step = Math.max(48, Math.round(w / 24));
        ctx.beginPath();
        for (let x = step; x < w; x += step) {
          ctx.moveTo(x, 0);
          ctx.lineTo(x, h);
        }
        for (let y = step; y < h; y += step) {
          ctx.moveTo(0, y);
          ctx.lineTo(w, y);
        }
        ctx.stroke();
        ctx.restore();
      }

      ctx.restore();
    }

    _drawGallery(ctx, w, h, t) {
      // 三色主题微光分别温柔照亮左、中、右三张展卡后方
      const spots = [
        { x: w * 0.18, y: h * 0.48, c: 'rgba(245, 230, 40, 0.08)' },
        { x: w * 0.50, y: h * 0.46, c: 'rgba(235, 192, 90, 0.09)' },
        { x: w * 0.82, y: h * 0.48, c: 'rgba(59, 229, 218, 0.085)' },
      ];
      spots.forEach((sp, idx) => {
        const dy = Math.sin(t * 0.4 + idx * 2.1) * h * 0.025;
        const g = ctx.createRadialGradient(sp.x, sp.y + dy, 0, sp.x, sp.y + dy, w * 0.32);
        g.addColorStop(0, sp.c);
        g.addColorStop(1, 'transparent');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, w, h);
      });
      // 极细腻建筑标尺暗网格
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
      ctx.lineWidth = Math.max(1, w / 1920);
      const step = Math.round(w / 18);
      ctx.beginPath();
      for (let x = step; x < w; x += step) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
      }
      ctx.stroke();
    }

    /* ---------------- 1. 明日方舟：终末地 — 塔卫二荒原工业测绘与源石晶尘 ---------------- */
    _drawEndfield(ctx, w, h, t) {
      const s = w / 1920;
      const g = ctx.createLinearGradient(0, 0, w * 0.25, h);
      g.addColorStop(0, '#101821');
      g.addColorStop(0.52, '#172330');
      g.addColorStop(1, '#0a1017');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);

      // 协议核心后方微暖冷交界光晕
      const halo = ctx.createRadialGradient(w * 0.52, h * 0.44, 0, w * 0.52, h * 0.44, w * 0.46);
      halo.addColorStop(0, 'rgba(245, 230, 40, 0.11)');
      halo.addColorStop(0.45, 'rgba(66, 98, 130, 0.14)');
      halo.addColorStop(1, 'transparent');
      ctx.fillStyle = halo;
      ctx.fillRect(0, 0, w, h);

      // 5.5° 同源倾斜测绘工程网格
      ctx.save();
      ctx.strokeStyle = 'rgba(130, 165, 200, 0.075)';
      ctx.lineWidth = Math.max(1, s);
      const cell = Math.round(92 * s);
      const slantDx = Math.tan((5.5 * Math.PI) / 180) * h;
      ctx.beginPath();
      for (let x = -slantDx; x < w + slantDx; x += cell) {
        ctx.moveTo(x + slantDx * 0.5, 0);
        ctx.lineTo(x - slantDx * 0.5, h);
      }
      for (let y = 0; y < h; y += cell) {
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
      }
      ctx.stroke();

      // 透视荒原集成工业地平线与斜向电力传输塔剪影
      const horizonY = h * 0.78;
      ctx.strokeStyle = 'rgba(165, 198, 228, 0.14)';
      ctx.lineWidth = Math.max(1.2, 1.4 * s);
      ctx.beginPath();
      ctx.moveTo(0, horizonY);
      ctx.lineTo(w, horizonY);
      ctx.stroke();

      // 透视地面放射测绘线
      ctx.strokeStyle = 'rgba(110, 148, 184, 0.08)';
      ctx.beginPath();
      for (let i = -8; i <= 8; i++) {
        ctx.moveTo(w * 0.5 + i * 75 * s, horizonY);
        ctx.lineTo(w * 0.5 + i * 280 * s, h);
      }
      ctx.stroke();

      // 远景六边形源石测绘靶环（缓慢脉冲呼吸）
      const hexR = (310 + Math.sin(t * 0.7) * 8) * s;
      ctx.strokeStyle = 'rgba(245, 230, 40, 0.10)';
      ctx.lineWidth = Math.max(1, 1.5 * s);
      ctx.beginPath();
      for (let i = 0; i <= 6; i++) {
        const a = (i * Math.PI) / 3 - Math.PI / 6;
        const px = w * 0.52 + Math.cos(a) * hexR;
        const py = h * 0.45 + Math.sin(a) * hexR;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();

      // 缓慢竖向扫描的集成工业雷达线
      const scanY = ((t * 58 * s) % (h * 1.2)) - h * 0.1;
      const scanG = ctx.createLinearGradient(0, scanY - 70 * s, 0, scanY + 6 * s);
      scanG.addColorStop(0, 'transparent');
      scanG.addColorStop(0.92, 'rgba(245, 230, 40, 0.055)');
      scanG.addColorStop(1, 'rgba(245, 230, 40, 0.22)');
      ctx.fillStyle = scanG;
      ctx.fillRect(0, scanY - 70 * s, w, 76 * s);

      // 飘浮的菱形源石尘埃与工业信标
      for (const p of EF_PARTICLES) {
        const px = ((p.x + t * p.vx) % 1) * w;
        const py = ((p.y - t * p.vy + 10) % 1) * h;
        const pulse = 0.45 + 0.55 * Math.sin(t * 1.8 + p.phase);
        const r = p.s * s;
        ctx.fillStyle = p.gold
          ? `rgba(245, 230, 40, ${0.42 * pulse})`
          : `rgba(170, 200, 228, ${0.28 * pulse})`;
        ctx.beginPath();
        ctx.moveTo(px, py - r);
        ctx.lineTo(px + r * 0.85, py);
        ctx.lineTo(px, py + r);
        ctx.lineTo(px - r * 0.85, py);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    }

    /* ---------------- 2. 崩坏：星穹铁道 — 深邃星海、黄铜星图环与跃迁流光 ---------------- */
    _drawStarRail(ctx, w, h, t) {
      const s = w / 1920;
      const g = ctx.createRadialGradient(w * 0.46, h * 0.45, 0, w * 0.5, h * 0.5, Math.max(w, h) * 0.78);
      g.addColorStop(0, '#182050');
      g.addColorStop(0.45, '#0f1436');
      g.addColorStop(1, '#060816');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);

      // 极光青蓝与星云紫红微雾
      const neb1 = ctx.createRadialGradient(w * 0.72, h * 0.28, 0, w * 0.72, h * 0.28, w * 0.42);
      neb1.addColorStop(0, 'rgba(46, 108, 178, 0.20)');
      neb1.addColorStop(1, 'transparent');
      ctx.fillStyle = neb1;
      ctx.fillRect(0, 0, w, h);

      const neb2 = ctx.createRadialGradient(w * 0.28, h * 0.55, 0, w * 0.28, h * 0.55, w * 0.36);
      neb2.addColorStop(0, 'rgba(235, 192, 90, 0.11)');
      neb2.addColorStop(1, 'transparent');
      ctx.fillStyle = neb2;
      ctx.fillRect(0, 0, w, h);

      // 缓慢旋转的巨型黄铜浑天仪星轨圆环
      ctx.save();
      ctx.translate(w * 0.5, h * 0.5);
      ctx.rotate((-16 * Math.PI) / 180);
      const drawEll = (rx, ry, rotOffset, color, lw) => {
        ctx.save();
        ctx.strokeStyle = color;
        ctx.lineWidth = lw;
        ctx.beginPath();
        ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
        ctx.stroke();
        // 环上运行的星体小亮点
        const a = t * 0.14 + rotOffset;
        const sx = Math.cos(a) * rx;
        const sy = Math.sin(a) * ry;
        ctx.fillStyle = 'rgba(255, 240, 185, 0.75)';
        ctx.beginPath();
        ctx.arc(sx, sy, 3.2 * s, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      };
      drawEll(760 * s, 245 * s, 0.4, 'rgba(235, 192, 90, 0.16)', 1.4 * s);
      drawEll(640 * s, 200 * s, 2.5, 'rgba(180, 210, 255, 0.10)', 1.0 * s);
      drawEll(910 * s, 315 * s, 4.1, 'rgba(235, 192, 90, 0.08)', 1.0 * s);
      ctx.restore();

      // 深空呼吸繁星
      for (const st of SR_STARS) {
        const px = st.x * w;
        const py = st.y * h;
        const a = 0.25 + 0.75 * (0.5 + 0.5 * Math.sin(t * st.twinkle + st.phase));
        ctx.fillStyle = st.tint > 0.7
          ? `rgba(255, 236, 178, ${a * 0.85})`
          : `rgba(216, 232, 255, ${a * 0.72})`;
        const r = st.r * s;
        ctx.beginPath();
        ctx.arc(px, py, r, 0, Math.PI * 2);
        ctx.fill();
      }

      // 沿 -16° 跃迁轨迹疾驰而过的星穹流光丝
      ctx.save();
      const ang = (-16 * Math.PI) / 180;
      const dx = Math.cos(ang);
      const dy = Math.sin(ang);
      for (const sk of SR_STREAKS) {
        const prog = ((t * sk.speed + sk.phase) % 1.4) - 0.2;
        const x1 = (sk.x0 * 0.4 + prog * 0.85) * w;
        const y1 = (sk.y0 * 0.9 + prog * 0.85 * Math.tan(ang)) * h;
        const L = sk.len * w;
        const x0 = x1 - dx * L;
        const y0 = y1 - dy * L;
        const lg = ctx.createLinearGradient(x0, y0, x1, y1);
        lg.addColorStop(0, 'transparent');
        lg.addColorStop(0.7, sk.gold ? 'rgba(242, 202, 108, 0.24)' : 'rgba(170, 215, 255, 0.22)');
        lg.addColorStop(1, 'rgba(255, 252, 235, 0.72)');
        ctx.strokeStyle = lg;
        ctx.lineWidth = Math.max(1, 1.5 * s);
        ctx.beginPath();
        ctx.moveTo(x0, y0);
        ctx.lineTo(x1, y1);
        ctx.stroke();
      }
      ctx.restore();
    }

    /* ---------------- 3. 鸣潮 — 天空海倒悬水墨、多轨声波频率弦与逆流溯回雨 ---------------- */
    _drawWuthering(ctx, w, h, t) {
      const s = w / 1920;
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, '#07121a');
      g.addColorStop(0.45, '#0b1922');
      g.addColorStop(1, '#05080d');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);

      // 天空海深渊青碧与中心曜金微光晕
      const cyGlow = ctx.createRadialGradient(w * 0.5, h * 0.46, 0, w * 0.5, h * 0.46, w * 0.48);
      cyGlow.addColorStop(0, 'rgba(38, 216, 206, 0.14)');
      cyGlow.addColorStop(0.55, 'rgba(15, 68, 84, 0.16)');
      cyGlow.addColorStop(1, 'transparent');
      ctx.fillStyle = cyGlow;
      ctx.fillRect(0, 0, w, h);

      // 远景巨型倒悬声痕涟漪波环（从中心缓慢向外扩散）
      ctx.save();
      for (let i = 0; i < 4; i++) {
        const p = ((t * 0.14 + i * 0.25) % 1);
        const rx = (120 + p * 680) * s;
        const ry = rx * 0.42;
        ctx.strokeStyle = `rgba(59, 229, 218, ${(1 - p) * 0.14})`;
        ctx.lineWidth = Math.max(1, 1.3 * s);
        ctx.beginPath();
        ctx.ellipse(w * 0.5, h * 0.52, rx, ry, -0.1, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();

      // 实时共振的立体正弦声波频谱弦线（贯穿背景）
      ctx.save();
      const waveSpecs = [
        { y: h * 0.54, amp: 46 * s, freq: 0.0055, sp: 1.1, col: 'rgba(59, 229, 218, 0.20)', lw: 1.6 * s },
        { y: h * 0.58, amp: 32 * s, freq: 0.0078, sp: -0.85, col: 'rgba(130, 224, 232, 0.13)', lw: 1.2 * s },
        { y: h * 0.50, amp: 58 * s, freq: 0.0042, sp: 0.65, col: 'rgba(245, 196, 81, 0.08)', lw: 1.1 * s },
      ];
      for (const ws of waveSpecs) {
        ctx.strokeStyle = ws.col;
        ctx.lineWidth = ws.lw;
        ctx.beginPath();
        for (let x = 0; x <= w; x += Math.max(8, Math.round(14 * s))) {
          const env = Math.sin((x / w) * Math.PI);
          const y = ws.y + Math.sin(x * ws.freq + t * ws.sp) * ws.amp * env;
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      ctx.restore();

      // 标志性「逆流溯回雨」：圆润水珠向上飞升，纤细雨丝拖在下方（30° 微斜逆重力！）
      ctx.save();
      const tiltX = Math.sin((12 * Math.PI) / 180);
      const tiltY = Math.cos((12 * Math.PI) / 180);
      for (const r of WW_RAIN) {
        const py = ((r.y - t * r.speed + 20) % 1.15) * h - h * 0.05;
        const px = ((r.x + t * r.speed * 0.16) % 1.05) * w;
        const len = r.len * h;
        const xEnd = px - tiltX * len;
        const yEnd = py + tiltY * len;
        const lg = ctx.createLinearGradient(px, py, xEnd, yEnd);
        lg.addColorStop(0, r.gold ? `rgba(255, 224, 130, ${r.alpha * 1.15})` : `rgba(115, 245, 238, ${r.alpha})`);
        lg.addColorStop(1, 'transparent');
        ctx.strokeStyle = lg;
        ctx.lineWidth = Math.max(1, r.r * 0.75 * s);
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(xEnd, yEnd);
        ctx.stroke();
        // 顶部晶莹向上飞升水珠头
        ctx.fillStyle = r.gold ? `rgba(255, 242, 195, ${r.alpha * 1.2})` : `rgba(210, 255, 252, ${r.alpha * 1.15})`;
        ctx.beginPath();
        ctx.arc(px, py, r.r * 0.85 * s, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  window.ThemeBackground = ThemeBackground;
})();
