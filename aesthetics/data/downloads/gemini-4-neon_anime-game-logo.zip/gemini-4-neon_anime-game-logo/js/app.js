/**
 * 主交互应用控制器 + window.videoExport 标准导出接口
 */
(function () {
  const LOGOS = [
    Object.assign({}, window.LOGO_DATA_ENDFIELD, {
      indexStr: '01',
      styleTag: '工业方黑 · CNC 钛合金',
      concept: '在荒原塔卫二上，由协议核心竖起电网母线、经数控铣削铆合而成的拉丝钛合金工业铭牌。',
      traits: ['硬朗', '秩序', '拓荒'],
      baseFont: 'Source Han Sans Heavy',
      climaxBrief: '「末」字协议核心能源塔',
      materialBrief: '拉丝钛银 × 警示柠檬黄电路扩散',
    }),
    Object.assign({}, window.LOGO_DATA_STARRAIL, {
      indexStr: '02',
      styleTag: '星图明朝 · 镀金浑天仪',
      concept: '群星列车的跃迁星轨破开午夜天幕，在镀金黄铜浑天仪的刻度间点亮开拓星芒。',
      traits: ['璀璨', '浪漫', '开拓'],
      baseFont: 'Noto Serif SC Bold',
      climaxBrief: '「星」字日框四芒星核',
      materialBrief: '珠光象牙釉面 × 复古流金黄铜',
    }),
    Object.assign({}, window.LOGO_DATA_WUTHERING, {
      indexStr: '03',
      styleTag: '声刃大楷 · 频率水墨',
      concept: '悲鸣之后的深渊水墨间，共鸣者的曜金十字声痕在「鸣」口震醒频率，激起逆流溯回的青碧声浪。',
      traits: ['冷峻', '共鸣', '激荡'],
      baseFont: '阿里妈妈东方大楷',
      climaxBrief: '「鸣」口十字声痕震源',
      materialBrief: '月华冷银玄石 × 青碧干涉水墨',
    }),
  ];

  const bgCanvas = document.getElementById('bg-canvas');
  const bg = new window.ThemeBackground(bgCanvas);
  const show = new window.ShowEngine(bg, LOGOS);

  const views = {
    gallery: document.getElementById('view-gallery'),
    detail: document.getElementById('view-detail'),
    show: document.getElementById('view-show'),
  };

  let currentView = 'gallery';
  let currentDetailIdx = 0;
  let detailExploded = false;
  let detailMono = false;

  // 展示片播放状态
  let isPlaying = false;
  let showTime = 0.0;
  let lastWallTs = 0;
  let exportActive = false;
  let exportFps = 60;
  let exportFrames = 5400;
  let preExportState = null;

  // DOM 引用
  const detailLogoBox = document.getElementById('detail-logo-box');
  const detailLayerLegend = document.getElementById('detail-layer-legend');
  const detailTitleZh = document.getElementById('detail-zh');
  const detailTitleEn = document.getElementById('detail-en');
  const detailConcept = document.getElementById('detail-concept');
  const detailSpecs = document.getElementById('detail-specs');
  const btnDetailExplode = document.getElementById('btn-detail-explode');
  const btnDetailMono = document.getElementById('btn-detail-mono');
  const btnDetailPlayShow = document.getElementById('btn-detail-play');
  const detailSwitchBtns = Array.from(document.querySelectorAll('.switch-pill'));

  const btnShowPlay = document.getElementById('btn-show-play');
  const btnShowExit = document.getElementById('btn-show-exit');
  const showScrubber = document.getElementById('show-scrubber');
  const showTimeLabel = document.getElementById('show-time-label');
  const chapterSpans = Array.from(document.querySelectorAll('.chapter-tabs span'));

  function setView(name) {
    currentView = name;
    for (const [k, el] of Object.entries(views)) {
      el.classList.toggle('active', k === name);
    }
    document.body.classList.toggle('show-has-controls', name === 'show' && !exportActive);
  }

  /* ---------------- 首页画廊渲染 ---------------- */
  function initGallery() {
    const grid = document.getElementById('triptych-grid');
    grid.innerHTML = '';
    LOGOS.forEach((item, idx) => {
      const card = document.createElement('article');
      card.className = 'logo-card';
      card.dataset.id = item.id;
      card.innerHTML = `
        <div class="card-top">
          <span class="card-index">NO.${item.indexStr}</span>
          <span class="card-tag">${item.styleTag}</span>
        </div>
        <div class="card-visual">
          <img src="${item.finalPath}" alt="${item.name}" />
        </div>
        <div class="card-meta">
          <div class="zh-name">${item.name}</div>
          <div class="en-name">${item.en}</div>
          <p class="concept-line">${item.concept}</p>
          <div class="card-pills">
            ${item.traits.map((tr) => `<span class="pill">${tr}</span>`).join('')}
          </div>
        </div>
        <span class="card-footer-hint">进入专属展厅 →</span>
      `;
      card.addEventListener('click', () => openDetail(idx));
      grid.appendChild(card);
    });

    document.getElementById('btn-gallery-play').addEventListener('click', () => {
      openShow(0.0, true);
    });
  }

  /* ---------------- 独立主题展厅渲染 ---------------- */
  function openDetail(idx) {
    currentDetailIdx = idx;
    detailExploded = false;
    detailMono = false;
    renderDetailContent();
    setView('detail');
  }

  function renderDetailContent() {
    const item = LOGOS[currentDetailIdx];
    detailSwitchBtns.forEach((b, i) => b.classList.toggle('active', i === currentDetailIdx));
    detailTitleZh.textContent = item.name;
    detailTitleEn.textContent = item.en;
    detailConcept.textContent = item.concept;
    detailSpecs.innerHTML = `
      <span><b>底字谱系</b>${item.baseFont}</span>
      <span><b>母题高潮</b>${item.climaxBrief}</span>
      <span><b>材质工艺</b>${item.materialBrief}</span>
    `;

    detailLogoBox.innerHTML = '';
    detailLogoBox.classList.remove('exploded', 'mono-mode');
    detailLayerLegend.classList.remove('visible');
    detailLayerLegend.style.setProperty('--legend-accent', item.accent);
    detailLayerLegend.innerHTML = item.layers.map((L, i) =>
      `<div class="detail-legend-row"><span class="z-tag">Z${String(i + 1).padStart(2, '0')}</span><span>${L.name}</span></div>`
    ).join('');
    btnDetailExplode.classList.remove('is-on');
    btnDetailMono.classList.remove('is-on');

    const monoImg = document.createElement('img');
    monoImg.className = 'detail-mono-img';
    monoImg.src = item.monoPath;
    monoImg.alt = item.name + ' 黑白稿';
    detailLogoBox.appendChild(monoImg);

    const n = item.layers.length;
    const mid = (n - 1) * 0.5;
    item.layers.forEach((L, i) => {
      const img = document.createElement('img');
      img.className = 'detail-layer-img';
      img.src = item.layerBasePath + L.file;
      img.alt = L.name;
      img.dataset.zIdx = String(i - mid);
      detailLogoBox.appendChild(img);
    });
  }

  function updateDetailModes() {
    detailLogoBox.classList.toggle('exploded', detailExploded);
    detailLogoBox.classList.toggle('mono-mode', detailMono);
    detailLayerLegend.classList.toggle('visible', detailExploded);
    btnDetailExplode.classList.toggle('is-on', detailExploded);
    btnDetailMono.classList.toggle('is-on', detailMono);
    const imgs = detailLogoBox.querySelectorAll('.detail-layer-img');
    imgs.forEach((img) => {
      const zi = parseFloat(img.dataset.zIdx || '0');
      img.style.transform = detailExploded ? `translate3d(${(zi * 9).toFixed(1)}px, 0, ${(zi * 42).toFixed(1)}px)` : 'none';
      img.style.filter = detailExploded ? 'drop-shadow(0 10px 22px rgba(0,0,0,0.52))' : 'none';
    });
  }

  document.getElementById('btn-detail-back').addEventListener('click', () => setView('gallery'));
  detailSwitchBtns.forEach((b, i) => b.addEventListener('click', () => openDetail(i)));
  btnDetailExplode.addEventListener('click', () => {
    detailExploded = !detailExploded;
    if (detailExploded) detailMono = false;
    updateDetailModes();
  });
  btnDetailMono.addEventListener('click', () => {
    detailMono = !detailMono;
    if (detailMono) detailExploded = false;
    updateDetailModes();
  });
  btnDetailPlayShow.addEventListener('click', () => {
    openShow(currentDetailIdx * 30.0, true);
  });

  /* ---------------- 展示片剧场交互 ---------------- */
  function fmtTime(sec) {
    const s = Math.max(0, Math.min(show.totalDuration, sec));
    const mm = Math.floor(s / 60);
    const ss = Math.floor(s % 60);
    const ds = Math.floor((s % 1) * 10);
    return `${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}.${ds}`;
  }

  function syncShowUI() {
    showScrubber.value = String(Math.round((showTime / show.totalDuration) * 1000));
    showTimeLabel.textContent = `${fmtTime(showTime)} / 01:30.0`;
    btnShowPlay.textContent = isPlaying ? '❚❚ 暂停' : '▶ 播放';
    const chIdx = Math.min(2, Math.floor(showTime / 30.0));
    chapterSpans.forEach((sp, i) => sp.classList.toggle('active', i === chIdx));
  }

  function openShow(startSec = 0.0, autoPlay = true) {
    showTime = startSec;
    isPlaying = autoPlay;
    lastWallTs = performance.now();
    setView('show');
    show.renderAt(showTime);
    syncShowUI();
  }

  btnShowPlay.addEventListener('click', () => {
    if (showTime >= show.totalDuration - 0.05) showTime = 0;
    isPlaying = !isPlaying;
    lastWallTs = performance.now();
    syncShowUI();
  });

  btnShowExit.addEventListener('click', () => {
    isPlaying = false;
    setView('gallery');
  });

  showScrubber.addEventListener('input', () => {
    isPlaying = false;
    showTime = (parseFloat(showScrubber.value) / 1000) * show.totalDuration;
    show.renderAt(showTime);
    syncShowUI();
  });

  chapterSpans.forEach((sp, idx) => {
    sp.addEventListener('click', () => {
      showTime = idx * 30.0;
      lastWallTs = performance.now();
      show.renderAt(showTime);
      syncShowUI();
    });
  });

  window.addEventListener('keydown', (e) => {
    if (exportActive) return;
    if (currentView === 'show') {
      if (e.code === 'Space') {
        e.preventDefault();
        btnShowPlay.click();
      } else if (e.code === 'Escape') {
        btnShowExit.click();
      }
    } else if (currentView === 'detail' && e.code === 'Escape') {
      setView('gallery');
    }
  });

  /* ---------------- 交互模式动画主循环（导出模式下完全静默停止） ---------------- */
  let rafId = 0;
  function tick(now) {
    if (!exportActive) {
      const sec = now * 0.001;
      if (currentView === 'gallery') {
        bg.render('gallery', sec, 1.0);
      } else if (currentView === 'detail') {
        bg.render(LOGOS[currentDetailIdx].id, sec, 1.0);
      } else if (currentView === 'show') {
        if (isPlaying) {
          const dt = Math.min(0.1, (now - lastWallTs) * 0.001);
          showTime += dt;
          if (showTime >= show.totalDuration) {
            showTime = show.totalDuration - 0.001;
            isPlaying = false;
          }
          show.renderAt(showTime);
          syncShowUI();
        }
      }
      lastWallTs = now;
    }
    rafId = requestAnimationFrame(tick);
  }

  /* ================================================================
     标准逐帧视频导出接口：window.videoExport
     严格遵循题面第 9 节：
       window.videoExport.runs                           -> ['show']
       await window.videoExport.begin('show', { fps })   -> { frames }
       await window.videoExport.frame(i)                 -> 显示时刻 i / fps 后返回
       window.videoExport.end()                          -> 回到正常展示网页
     ================================================================ */
  function waitPaint() {
    return new Promise((resolve) => {
      requestAnimationFrame(() => requestAnimationFrame(resolve));
    });
  }

  window.videoExport = {
    runs: ['show'],

    async begin(runName = 'show', opts = {}) {
      if (runName !== 'show') {
        throw new Error(`Unknown videoExport run: ${runName}`);
      }
      const fps = Math.max(1, Number(opts && opts.fps) || 60);
      preExportState = { view: currentView, detailIdx: currentDetailIdx, showTime, isPlaying };

      exportActive = true;
      exportFps = fps;
      exportFrames = Math.round(show.totalDuration * fps);
      isPlaying = false;

      document.body.classList.add('export-mode');
      setView('show');

      // 预加载并解码所有 31 张分层 PNG 与 3 张黑白稿，确保任意帧零延迟零白屏
      await show.preloadAllImages();
      show.renderAt(0);
      await waitPaint();
      return { frames: exportFrames };
    },

    async frame(i) {
      if (!exportActive) {
        throw new Error('videoExport.frame() called before begin()');
      }
      const idx = Math.max(0, Math.min(exportFrames - 1, Number(i) || 0));
      const t = idx / exportFps;
      showTime = t;
      show.renderAt(t);
      await waitPaint();
    },

    end() {
      exportActive = false;
      document.body.classList.remove('export-mode');
      const restore = preExportState || { view: 'gallery', detailIdx: 0, showTime: 0, isPlaying: false };
      if (restore.view === 'detail') {
        openDetail(restore.detailIdx);
      } else if (restore.view === 'show') {
        openShow(restore.showTime, false);
      } else {
        setView('gallery');
      }
      lastWallTs = performance.now();
    },
  };

  window.addEventListener('resize', () => {
    bg.resize();
    if (currentView === 'show') {
      show.renderAt(showTime);
    }
  });

  // 初始化启动
  initGallery();
  setView('gallery');
  // 后台温和预热展示片图层，让用户点击播放时秒开
  show.preloadAllImages();
  lastWallTs = performance.now();
  rafId = requestAnimationFrame(tick);
})();
