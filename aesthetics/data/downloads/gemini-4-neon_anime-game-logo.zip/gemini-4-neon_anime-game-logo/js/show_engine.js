/**
 * 展示片 `show` 连续单镜头确定性渲染引擎 + window.videoExport 标准接口
 * 全片 90 秒（每枚 30 秒：0-30s 终末地 | 30-60s 星穹铁道 | 60-90s 鸣潮）
 * 100% 纯前端无 fetch 依赖，本地 file:// 双击直接运行与逐帧导出均完整可用。
 */
(function () {
  const SVG_NS = 'http://www.w3.org/2000/svg';
  const DURATION_PER_LOGO = 30.0;

  function clamp(v, lo = 0, hi = 1) {
    return v < lo ? lo : v > hi ? hi : v;
  }

  function prog(t, t0, t1) {
    return clamp((t - t0) / (t1 - t0));
  }

  function easeOutCubic(x) {
    const t = clamp(x);
    return 1 - Math.pow(1 - t, 3);
  }

  function easeInOutCubic(x) {
    const t = clamp(x);
    return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  }

  function easeOutQuint(x) {
    const t = clamp(x);
    return 1 - Math.pow(1 - t, 5);
  }

  function lerp(a, b, t) {
    return a + (b - a) * t;
  }

  function svgEl(tag, attrs = {}) {
    const el = document.createElementNS(SVG_NS, tag);
    for (const [k, v] of Object.entries(attrs)) {
      el.setAttribute(k, String(v));
    }
    return el;
  }

  class ShowEngine {
    constructor(bgEngine, logos) {
      this.bg = bgEngine;
      this.logos = logos; // [LOGO_DATA_ENDFIELD, LOGO_DATA_STARRAIL, LOGO_DATA_WUTHERING]
      this.totalDuration = logos.length * DURATION_PER_LOGO;

      this.viewEl = document.getElementById('view-show');
      this.cameraEl = document.getElementById('show-camera');
      this.scene3dEl = document.getElementById('show-scene-3d');
      this.svgEl = document.getElementById('show-svg');
      this.calloutsEl = document.getElementById('show-layer-callouts');
      this.subBadgeEl = document.getElementById('show-sub-badge');
      this.subTextEl = document.getElementById('show-sub-text');
      this.subDescEl = document.getElementById('show-sub-desc');

      // DOM 缓存（每个 Logo 预建一套 img 图层，切章节零 DOM 重建抖动）
      this.logoNodes = {};
      this.activeLogoId = null;
      this.imagesReadyPromise = null;

      this._initAllLogoDom();
    }

    _initAllLogoDom() {
      this.scene3dEl.innerHTML = '';
      for (const data of this.logos) {
        const group = document.createElement('div');
        group.className = 'show-logo-group';
        group.style.cssText = 'position:absolute;inset:0;transform-style:preserve-3d;display:none;';

        // 黑白稿整图（用于第 6 步黑白停留）
        const monoImg = document.createElement('img');
        monoImg.className = 'show-mono-img';
        monoImg.src = data.monoPath;
        monoImg.alt = data.name + ' mono';
        group.appendChild(monoImg);

        // 各独立分层 PNG
        const layerImgs = data.layers.map((L) => {
          const img = document.createElement('img');
          img.className = 'show-layer-img';
          img.src = data.layerBasePath + L.file;
          img.alt = L.name;
          img.dataset.layerName = L.name;
          img.dataset.z = String(L.z);
          group.appendChild(img);
          return { el: img, meta: L };
        });

        this.scene3dEl.appendChild(group);
        this.logoNodes[data.id] = { group, monoImg, layerImgs, data };
      }

      // 构建 SVG 永久结构（仅改 d 与属性，避免每帧创建销毁 DOM 节点）
      this._initSvgSkeleton();
    }

    _initSvgSkeleton() {
      const svg = this.svgEl;
      svg.innerHTML = '';

      const defs = svgEl('defs');

      // SVG 发光滤镜（供方言新增变体、高潮核心与扫光使用）
      const flt = svgEl('filter', { id: 'vec-glow', x: '-20%', y: '-20%', width: '140%', height: '140%' });
      flt.appendChild(svgEl('feGaussianBlur', { stdDeviation: '4.2', result: 'blur' }));
      const merge = svgEl('feMerge');
      merge.appendChild(svgEl('feMergeNode', { in: 'blur' }));
      merge.appendChild(svgEl('feMergeNode', { in: 'SourceGraphic' }));
      flt.appendChild(merge);
      defs.appendChild(flt);

      // 布尔差集 Mask 1：只显示「新形减去旧形」（New \ Prev）——高亮本条方言新生长出来的部位！
      const maskAdded = svgEl('mask', { id: 'mask-added', maskUnits: 'userSpaceOnUse', x: 0, y: 0, width: 1200, height: 600 });
      maskAdded.appendChild(svgEl('rect', { x: 0, y: 0, width: 1200, height: 600, fill: '#ffffff' }));
      this.maskAddedSub = svgEl('path', { d: '', fill: '#000000' });
      maskAdded.appendChild(this.maskAddedSub);
      defs.appendChild(maskAdded);

      // 布尔差集 Mask 2：只显示「旧形减去新形」（Prev \ Next）——高亮本条方言切削掉的部位！
      const maskRemoved = svgEl('mask', { id: 'mask-removed', maskUnits: 'userSpaceOnUse', x: 0, y: 0, width: 1200, height: 600 });
      maskRemoved.appendChild(svgEl('rect', { x: 0, y: 0, width: 1200, height: 600, fill: '#ffffff' }));
      this.maskRemovedSub = svgEl('path', { d: '', fill: '#000000' });
      maskRemoved.appendChild(this.maskRemovedSub);
      defs.appendChild(maskRemoved);

      // 字面高光扫光渐变 + 裁剪区
      const sweepGrad = svgEl('linearGradient', { id: 'spec-sweep-grad', x1: '0%', y1: '0%', x2: '100%', y2: '25%' });
      sweepGrad.appendChild(svgEl('stop', { offset: '0%', 'stop-color': '#ffffff', 'stop-opacity': '0' }));
      sweepGrad.appendChild(svgEl('stop', { offset: '42%', 'stop-color': '#ffffff', 'stop-opacity': '0.12' }));
      sweepGrad.appendChild(svgEl('stop', { offset: '50%', 'stop-color': '#ffffff', 'stop-opacity': '0.92' }));
      sweepGrad.appendChild(svgEl('stop', { offset: '58%', 'stop-color': '#ffffff', 'stop-opacity': '0.12' }));
      sweepGrad.appendChild(svgEl('stop', { offset: '100%', 'stop-color': '#ffffff', 'stop-opacity': '0' }));
      defs.appendChild(sweepGrad);

      const textClip = svgEl('clipPath', { id: 'clip-final-text' });
      this.clipFinalTextPath = svgEl('path', { d: '' });
      textClip.appendChild(this.clipFinalTextPath);
      defs.appendChild(textClip);

      // 点缀色径向扩散渐变
      this.accentRippleGrad = svgEl('radialGradient', { id: 'accent-ripple-grad' });
      this.accentRippleStop1 = svgEl('stop', { offset: '0%', 'stop-color': '#f5e628', 'stop-opacity': '0' });
      this.accentRippleStop2 = svgEl('stop', { offset: '75%', 'stop-color': '#f5e628', 'stop-opacity': '0.68' });
      this.accentRippleStop3 = svgEl('stop', { offset: '100%', 'stop-color': '#f5e628', 'stop-opacity': '0' });
      this.accentRippleGrad.appendChild(this.accentRippleStop1);
      this.accentRippleGrad.appendChild(this.accentRippleStop2);
      this.accentRippleGrad.appendChild(this.accentRippleStop3);
      defs.appendChild(this.accentRippleGrad);

      svg.appendChild(defs);

      // 1) 组合阶段单色矢量底板/主体/英文预览组
      this.gCompose = svgEl('g', { id: 'g-compose', opacity: '0' });
      this.pCompPlate = svgEl('path', { d: '', fill: 'rgba(130, 148, 172, 0.14)', stroke: 'rgba(190, 210, 232, 0.35)', 'stroke-width': '1.2', 'stroke-dasharray': '6 4' });
      this.pCompBgEn = svgEl('path', { d: '', fill: 'rgba(155, 175, 200, 0.14)' });
      this.pCompHero = svgEl('path', { d: '', fill: 'rgba(205, 222, 240, 0.44)', stroke: 'rgba(255,255,255,0.2)', 'stroke-width': '0.8' });
      this.pCompFine = svgEl('path', { d: '', fill: 'rgba(220, 235, 250, 0.72)' });
      this.pCompEn = svgEl('path', { d: '', fill: '#e6edf6' });
      this.pCompEnAcc = svgEl('path', { d: '', fill: '#f5e628' });
      this.gCompose.append(this.pCompPlate, this.pCompBgEn, this.pCompHero, this.pCompFine, this.pCompEn, this.pCompEnAcc);
      svg.appendChild(this.gCompose);

      // 2) 骨架与角度辅助线组
      this.gGuides = svgEl('g', { id: 'g-guides', opacity: '0' });
      svg.appendChild(this.gGuides);

      // 3) 字形矢量形变主体组（保留部 + 切削高亮部 + 新增生长部 + 高潮核心）
      this.gGlyphs = svgEl('g', { id: 'g-glyphs', opacity: '0' });
      this.pGlyphPrev = svgEl('path', { d: '', fill: '#8f9aa8' });
      this.pGlyphNext = svgEl('path', { d: '', fill: '#dde5f0' });
      this.pGlyphRemoved = svgEl('path', { d: '', fill: '#ff5d6c', mask: 'url(#mask-removed)', opacity: '0' });
      this.pGlyphAdded = svgEl('path', { d: '', fill: '#f5e628', mask: 'url(#mask-added)', filter: 'url(#vec-glow)', opacity: '0' });
      this.pGlyphCore = svgEl('path', { d: '', fill: '#f5e628', filter: 'url(#vec-glow)', opacity: '0' });
      this.gGlyphs.append(this.pGlyphPrev, this.pGlyphNext, this.pGlyphRemoved, this.pGlyphAdded, this.pGlyphCore);
      svg.appendChild(this.gGlyphs);

      // 4) 高潮准星、同类呼应引线与组合对齐线标注组
      this.gCallouts = svgEl('g', { id: 'g-callouts', opacity: '0' });
      svg.appendChild(this.gCallouts);

      // 5) 材质扫光与点缀色扩散波组（仅在字面轮廓内显现 + 柔和星芒脉冲）
      this.gFx = svgEl('g', { id: 'g-fx', opacity: '0' });
      this.gSweepWrap = svgEl('g', { 'clip-path': 'url(#clip-final-text)' });
      this.rectSweep = svgEl('rect', { x: -400, y: 0, width: 320, height: 600, fill: 'url(#spec-sweep-grad)', transform: 'skewX(-18)' });
      this.gSweepWrap.appendChild(this.rectSweep);
      this.circleRipple = svgEl('circle', { cx: 600, cy: 300, r: 0, fill: 'url(#accent-ripple-grad)', opacity: '0' });
      this.circleRippleRing = svgEl('circle', { cx: 600, cy: 300, r: 0, fill: 'none', stroke: '#f5e628', 'stroke-width': '2.4', opacity: '0' });
      this.gFx.append(this.gSweepWrap, this.circleRipple, this.circleRippleRing);
      svg.appendChild(this.gFx);
    }

    async preloadAllImages() {
      if (this.imagesReadyPromise) return this.imagesReadyPromise;
      const tasks = [];
      for (const id of Object.keys(this.logoNodes)) {
        const { monoImg, layerImgs } = this.logoNodes[id];
        const allImgs = [monoImg, ...layerImgs.map((x) => x.el)];
        for (const img of allImgs) {
          tasks.push(
            new Promise((resolve) => {
              const done = () => {
                if (typeof img.decode === 'function') {
                  img.decode().catch(() => {}).finally(resolve);
                } else {
                  resolve();
                }
              };
              if (img.complete && img.naturalWidth > 0) done();
              else {
                img.addEventListener('load', done, { once: true });
                img.addEventListener('error', resolve, { once: true });
              }
            })
          );
        }
      }
      this.imagesReadyPromise = Promise.all(tasks);
      return this.imagesReadyPromise;
    }

    _prepareLogoSvg(data) {
      if (this.activeLogoId === data.id) return;
      this.activeLogoId = data.id;

      // 切换显示对应 DOM 图层组
      for (const id of Object.keys(this.logoNodes)) {
        this.logoNodes[id].group.style.display = id === data.id ? 'block' : 'none';
      }

      // 预填静态矢量轮廓
      this.pCompPlate.setAttribute('d', data.vectors.plate || '');
      this.pCompBgEn.setAttribute('d', data.vectors.bg_en || '');
      this.pCompHero.setAttribute('d', data.vectors.hero || '');
      this.pCompFine.setAttribute('d', data.vectors.fine || '');
      this.pCompEn.setAttribute('d', data.vectors.en || '');
      this.pCompEnAcc.setAttribute('d', data.vectors.en_accent || '');
      this.pCompEnAcc.setAttribute('fill', data.accent);

      this.pGlyphCore.setAttribute('d', data.vectors.core || '');
      this.pGlyphCore.setAttribute('fill', data.accentGold || data.accent);
      this.pGlyphAdded.setAttribute('fill', data.accent);
      this.clipFinalTextPath.setAttribute('d', data.stages.s4_climax.all || '');

      const acc = data.accent;
      this.accentRippleStop1.setAttribute('stop-color', acc);
      this.accentRippleStop2.setAttribute('stop-color', acc);
      this.accentRippleStop3.setAttribute('stop-color', acc);
      this.circleRippleRing.setAttribute('stroke', acc);
      this.circleRipple.setAttribute('cx', data.corePoint[0]);
      this.circleRipple.setAttribute('cy', data.corePoint[1]);
      this.circleRippleRing.setAttribute('cx', data.corePoint[0]);
      this.circleRippleRing.setAttribute('cy', data.corePoint[1]);

      // 预构建本枚 Logo 的骨架辅助线 DOM
      this._buildGuidesSvg(data);
      // 预构建右侧 3D 分层展开引线列表
      this._buildLayerCallouts(data);
    }

    _buildGuidesSvg(data) {
      this.gGuides.innerHTML = '';
      const acc = data.accent;
      // 水平共享结构线
      for (const hl of data.guides.hLines) {
        const g = svgEl('g', { class: 'guide-hline' });
        g.appendChild(svgEl('line', {
          x1: 56, y1: hl.y, x2: 1144, y2: hl.y,
          stroke: 'rgba(195, 214, 238, 0.36)', 'stroke-width': '1', 'stroke-dasharray': '6 5'
        }));
        g.appendChild(svgEl('circle', { cx: 56, cy: hl.y, r: '2.5', fill: acc }));
        const txt = svgEl('text', {
          x: 64, y: hl.y - 5, fill: 'rgba(205, 222, 242, 0.72)',
          'font-size': '11.5', 'font-family': 'var(--font-zh)', 'letter-spacing': '0.08em'
        });
        txt.textContent = hl.label;
        g.appendChild(txt);
        this.gGuides.appendChild(g);
      }
      // 角度集参考斜线
      for (const ag of data.guides.angles) {
        const rad = (ag.deg * Math.PI) / 180;
        const len = 135;
        const x1 = ag.x - Math.sin(rad) * len;
        const y1 = ag.y + Math.cos(rad) * len;
        const x2 = ag.x + Math.sin(rad) * len;
        const y2 = ag.y - Math.cos(rad) * len;
        const g = svgEl('g', { class: 'guide-angle' });
        g.appendChild(svgEl('line', {
          x1: x1.toFixed(1), y1: y1.toFixed(1), x2: x2.toFixed(1), y2: y2.toFixed(1),
          stroke: acc, 'stroke-width': '1.2', 'stroke-dasharray': '4 4', opacity: '0.78'
        }));
        const lbl = svgEl('text', {
          x: (x2 + 8).toFixed(1), y: (y2 + 4).toFixed(1), fill: acc,
          'font-size': '12', 'font-family': 'var(--font-mono)', opacity: '0.92'
        });
        lbl.textContent = ag.label;
        g.appendChild(lbl);
        this.gGuides.appendChild(g);
      }
    }

    _buildLayerCallouts(data) {
      this.calloutsEl.innerHTML = '';
      const total = data.layers.length;
      data.layers.forEach((L, idx) => {
        const item = document.createElement('div');
        item.className = 'callout-item';
        item.style.setProperty('--c-accent', data.accent);
        // 从下到上均匀排布在右侧优雅安全区，清晰标注每一层是什么
        const topPct = 15 + ((total - 1 - idx) / Math.max(1, total - 1)) * 64;
        item.style.right = '4.2vw';
        item.style.top = `${topPct.toFixed(2)}%`;
        item.innerHTML = `<span class="c-dot"></span><span class="c-line"></span><span class="c-idx">Z${String(idx + 1).padStart(2, '0')}</span><span>${L.name}</span>`;
        this.calloutsEl.appendChild(item);
      });
    }

    _setSubtitle(badge, title, desc, alpha = 1) {
      this.subBadgeEl.textContent = badge;
      this.subTextEl.textContent = title;
      this.subDescEl.textContent = desc || '';
      this.subBadgeEl.parentElement.style.opacity = String(clamp(alpha));
    }

    /**
     * 核心确定性渲染函数：给定全局片中时刻 globalT ∈ [0, 90]，精准画出该帧一切视觉元素
     */
    renderAt(globalT) {
      const tClamped = clamp(globalT, 0, this.totalDuration - 0.0001);
      const logoIdx = Math.min(this.logos.length - 1, Math.floor(tClamped / DURATION_PER_LOGO));
      const localT = tClamped - logoIdx * DURATION_PER_LOGO;
      const data = this.logos[logoIdx];
      const node = this.logoNodes[data.id];

      this._prepareLogoSvg(data);

      // 段落衔接极简呼吸淡入/淡出（仅 0.35s 边缘，单枚内部 100% 连续无切卡）
      let chapterFade = 1.0;
      if (localT < 0.35) chapterFade = easeOutCubic(localT / 0.35);
      else if (logoIdx < this.logos.length - 1 && localT > 29.55) {
        chapterFade = 1 - easeInOutCubic((localT - 29.55) / 0.45);
      }

      // 默认状态重置
      let camScale = 1.0;
      let camTx = 0.0; // 版面百分比平移
      let camTy = 0.0;
      let rotY = 0.0;
      let rotX = 0.0;
      let bgIntensity = 1.0;

      // 默认隐藏所有图层和 SVG 分组，按段落精准开启
      node.monoImg.style.opacity = '0';
      for (const L of node.layerImgs) {
        L.el.style.opacity = '0';
        L.el.style.transform = 'none';
        L.el.style.filter = 'none';
        L.el.style.clipPath = 'none';
      }
      this.gCompose.setAttribute('opacity', '0');
      this.gGuides.setAttribute('opacity', '0');
      this.gGlyphs.setAttribute('opacity', '0');
      this.gCallouts.setAttribute('opacity', '0');
      this.gFx.setAttribute('opacity', '0');
      this.pGlyphRemoved.setAttribute('opacity', '0');
      this.pGlyphAdded.setAttribute('opacity', '0');
      this.pGlyphCore.setAttribute('opacity', '0');
      this.calloutsEl.style.opacity = '0';

      const stepNames = data.dialectSteps.map((s) => s.stage);
      const stRaw = (data.stages.s0_raw || data.stages.s0_base).all;
      const stSkel = (data.stages.s0_skel || data.stages.s0_base).all;
      const st1 = data.stages[stepNames[0]].all;
      const st2 = data.stages[stepNames[1]].all;
      const st3 = data.stages[stepNames[2]].all;
      const stPreClimax = (data.stages.s3_preclimax || data.stages[stepNames[2]]).all;
      const st4 = data.stages.s4_climax.all;

      // ================================================================
      // 段落 1 (0.0 – 4.5s)：成品入场 —— 各层按自身构造与母题顺序入场
      // ================================================================
      if (localT < 4.5) {
        bgIntensity = 1.0;
        const p = localT / 4.5;
        this._renderCraftedEntrance(data, node, localT);
        const descMap = {
          endfield: '装甲底板展铺 · 协议塔架竖起 · 钛银模块锁合 · 源石核心点亮',
          starrail: '星云舒展 · 浑天仪与列车跃迁 · 星轨落字 · 四芒星核绽放',
          wuthering: '玄墨晕散 · 声痕垂落与声波共振 · 鸣聚潮涌 · 曜金声痕震醒',
        };
        this._setSubtitle(
          `${String(logoIdx + 1).padStart(2, '0')} / 03  ·  ${data.name}`,
          '01 · 成品入场',
          descMap[data.id],
          p < 0.12 ? p / 0.12 : 1
        );
      }

      // ================================================================
      // 段落 2 (4.5 – 8.2s)：拆回底字 —— 褪色退装饰，形变回底字并绘骨架线与对齐骨架
      // ================================================================
      else if (localT < 8.2) {
        const pStrip = prog(localT, 4.5, 5.75);
        const pMorphBack = prog(localT, 5.65, 6.85);
        const pGuides = prog(localT, 6.75, 7.65);
        const pSkel = prog(localT, 7.45, 8.15);

        bgIntensity = lerp(1.0, 0.12, easeInOutCubic(pStrip));

        if (localT < 5.95) {
          const desat = easeInOutCubic(pStrip);
          const decFade = 1 - easeOutCubic(prog(localT, 4.5, 5.45));
          const textImgFade = 1 - easeInOutCubic(prog(localT, 5.25, 5.88));
          for (const L of node.layerImgs) {
            const isText = /系列名|主名|签名字|鸣字|潮字/.test(L.meta.name);
            if (isText) {
              L.el.style.opacity = String(textImgFade);
              L.el.style.filter = `saturate(${(1 - desat).toFixed(3)}) brightness(${lerp(1, 0.85, desat).toFixed(3)})`;
            } else {
              L.el.style.opacity = String(decFade);
              L.el.style.filter = `saturate(${(1 - desat).toFixed(3)})`;
              const drift = (1 - decFade) * (L.meta.z * 8);
              L.el.style.transform = `translate3d(0, ${drift.toFixed(1)}px, 0) scale(${(1 + (1 - decFade) * 0.03).toFixed(4)})`;
            }
          }
        }

        const vecIn = easeOutCubic(prog(localT, 5.25, 5.85));
        this.gGlyphs.setAttribute('opacity', String(vecIn));
        if (localT < 7.45) {
          // 逆向形变回纯原底字（灰色）
          this._renderMorphDiff(st4, stRaw, easeInOutCubic(pMorphBack), '#b8c3d0', '#86909e', '#758294', 'rgba(255,255,255,0.22)');
        } else {
          // 骨架基准线画好后，平滑微调宽窄与重心进入方言基准骨架 s0_skel
          this._renderMorphDiff(stRaw, stSkel, easeInOutCubic(pSkel), '#86909e', '#929dac', 'rgba(255,255,255,0.28)', 'rgba(130,150,175,0.28)');
        }

        this.gGuides.setAttribute('opacity', String(easeOutCubic(pGuides)));

        this._setSubtitle(
          `${data.name}  ·  DECONSTRUCTION`,
          '02 · 拆回底字与骨架基准',
          localT < 5.9 ? '褪去色彩、底板与装饰，剥离至纯中文骨架' : '还原为灰色底字原样，建立共享水平线、重心与统一角度集'
        );
      }

      // ================================================================
      // 段落 3 (8.2 – 14.8s)：方言逐条执行 —— 骨架纹丝不动，唯独同类笔画同时精准形变！
      // ================================================================
      else if (localT < 14.8) {
        bgIntensity = 0.12;
        this.gGuides.setAttribute('opacity', '0.70');
        this.gGlyphs.setAttribute('opacity', '1');

        const slantWindow = data.hasSlantStep ? 0.9 : 0.0;
        const dialectEnd = 14.8 - slantWindow;

        if (localT < dialectEnd) {
          const stepLen = (dialectEnd - 8.2) / 3.0;
          const stepIdx = Math.min(2, Math.floor((localT - 8.2) / stepLen));
          const u = clamp((localT - (8.2 + stepIdx * stepLen)) / stepLen);
          const prevD = [stSkel, st1, st2][stepIdx];
          const nextD = [st1, st2, st3][stepIdx];
          const stepMeta = data.dialectSteps[stepIdx];

          const baseCol = ['#95a1b0', '#b5c1d0', '#cfd9e6'][stepIdx];
          const targetCol = ['#b5c1d0', '#cfd9e6', '#e4ecf5'][stepIdx];
          this._renderMorphDiff(prevD, nextD, easeInOutCubic(u), baseCol, targetCol, data.accent, '#ff5f6d');

          this._setSubtitle(
            `${data.name}  ·  DIALECT 0${stepIdx + 1} / 03`,
            stepMeta.title,
            stepMeta.desc
          );
        } else {
          // 终末地专属：结构与方言全部在水平状态完成后，全组统一斜切 5.5°！
          const uSl = easeInOutCubic(prog(localT, dialectEnd, 14.8));
          this._renderMorphDiff(st3, stPreClimax, uSl, '#e4ecf5', '#e9f0f8', data.accent, 'rgba(255,95,109,0.45)');
          this._setSubtitle(
            `${data.name}  ·  SKELETON SLANT`,
            '方言定势 · 统一 5.5° 前推斜切',
            data.slantDesc || '结构完成后全组统一斜切，确立一致行进角度'
          );
        }
      }

      // ================================================================
      // 段落 4 (14.8 – 19.8s)：高潮推近与同类呼应拉回
      // ================================================================
      else if (localT < 19.8) {
        bgIntensity = 0.14;
        this.gGlyphs.setAttribute('opacity', '1');

        const cx = data.corePoint[0];
        const cy = data.corePoint[1];
        const targetTx = ((600 - cx) / 1200) * 100;
        const targetTy = ((300 - cy) / 600) * 100;

        if (localT < 17.3) {
          const pZoom = easeInOutCubic(prog(localT, 14.8, 15.72));
          const pMorph = easeInOutCubic(prog(localT, 15.2, 16.55));
          const pCore = easeOutQuint(prog(localT, 15.72, 16.95));

          camScale = lerp(1.0, 2.08, pZoom);
          camTx = lerp(0, targetTx, pZoom);
          camTy = lerp(0, targetTy, pZoom);
          this.gGuides.setAttribute('opacity', String(lerp(0.65, 0.2, pZoom)));

          // 严格从 stPreClimax -> st4 形变：字身不动，唯独高潮那一笔精准切削并生长出同构物件！
          this._renderMorphDiff(stPreClimax, st4, pMorph, '#e9f0f8', '#f4f8fc', data.accent, '#ff5f6d');

          this.pGlyphCore.setAttribute('opacity', String(pCore));
          const coreSc = lerp(0.18, 1.0, pCore);
          const coreRot = data.id === 'starrail' ? lerp(-45, 0, pCore) : 0;
          this.pGlyphCore.setAttribute(
            'transform',
            `translate(${cx} ${cy}) rotate(${coreRot.toFixed(2)}) scale(${coreSc.toFixed(4)}) translate(${-cx} ${-cy})`
          );

          this._renderClimaxReticle(cx, cy, data.accent, pZoom * 0.9, localT);
          this.gCallouts.setAttribute('opacity', String(pZoom));

          this._setSubtitle(
            `${data.name}  ·  CLIMAX ISOMORPHISM`,
            data.climaxTitle,
            data.climaxDesc
          );
        } else {
          const pPull = easeInOutCubic(prog(localT, 17.3, 18.25));
          camScale = lerp(2.08, 1.0, pPull);
          camTx = lerp(targetTx, 0, pPull);
          camTy = lerp(targetTy, 0, pPull);
          this.gGuides.setAttribute('opacity', String(lerp(0.2, 0.45, pPull)));

          this._setSolidGlyph(st4, '#eef3fa');
          this.pGlyphCore.setAttribute('opacity', '1');
          this.pGlyphCore.removeAttribute('transform');

          const pEcho = prog(localT, 17.8, 19.55);
          this._renderEchoCallouts(data, pEcho);
          this.gCallouts.setAttribute('opacity', '1');

          this._setSubtitle(
            `${data.name}  ·  MOTIF ECHO`,
            '04 · 同类笔画呼应',
            '高潮母题的弱化形态落在全组同类笔画与收笔上，引线标出落点'
          );
        }
      }

      // ================================================================
      // 段落 5 (19.8 – 23.6s)：组合 —— 底板、主体元素、英文滑入 + 对齐标注线
      // ================================================================
      else if (localT < 23.6) {
        bgIntensity = 0.16;
        this.gGlyphs.setAttribute('opacity', '1');
        this._setSolidGlyph(st4, '#eef3fa');
        this.pGlyphCore.setAttribute('opacity', '1');
        this.pGlyphCore.removeAttribute('transform');

        const pPlate = easeOutCubic(prog(localT, 19.8, 20.6));
        const pHero = easeOutCubic(prog(localT, 20.3, 21.3));
        const pEn = easeOutCubic(prog(localT, 21.0, 22.0));
        const pAlign = easeOutCubic(prog(localT, 21.5, 22.8));

        this.gCompose.setAttribute('opacity', '1');
        this.pCompPlate.setAttribute('opacity', String(pPlate));
        this.pCompPlate.setAttribute('transform', `translate(0 ${((1 - pPlate) * 18).toFixed(1)})`);
        this.pCompBgEn.setAttribute('opacity', String(pPlate * 0.9));

        this.pCompHero.setAttribute('opacity', String(pHero));
        this.pCompHero.setAttribute('transform', `translate(0 ${((1 - pHero) * -26).toFixed(1)})`);
        this.pCompFine.setAttribute('opacity', String(pHero));

        this.pCompEn.setAttribute('opacity', String(pEn));
        this.pCompEn.setAttribute('transform', `translate(0 ${((1 - pEn) * 20).toFixed(1)})`);
        this.pCompEnAcc.setAttribute('opacity', String(pEn));
        this.pCompEnAcc.setAttribute('transform', `translate(0 ${((1 - pEn) * 20).toFixed(1)})`);

        this._renderAlignCallouts(data, pAlign);
        this.gCallouts.setAttribute('opacity', String(pAlign));

        this._setSubtitle(
          `${data.name}  ·  COMPOSITION & ALIGNMENT`,
          '05 · 组合与结构对齐',
          '底板、主体元素与多层级英文滑入，虚线标示英文基线与中文结构线的对齐'
        );
      }

      // ================================================================
      // 段落 6 (23.6 – 27.0s)：黑白到上色 —— 无卡片无缝透明黑白稿 → 按颜色角色逐层上色与扫光扩散
      // ================================================================
      else if (localT < 27.0) {
        bgIntensity = lerp(0.16, 0.68, easeInOutCubic(prog(localT, 24.5, 27.0)));

        // 23.6–24.1s：从单色矢量架构无缝融入纯去色高反差黑白透明分层稿（零白框卡片切痕！）
        const pMonoIn = easeOutCubic(prog(localT, 23.6, 24.08));
        const vFade = 1 - pMonoIn;
        this.gGlyphs.setAttribute('opacity', String(vFade));
        this.gCompose.setAttribute('opacity', String(vFade));

        // 24.55–27.0s：按颜色角色逐层解除灰度恢复真实色彩与材质
        const cTheme = easeInOutCubic(prog(localT, 24.55, 25.30));  // 底板主题色、背景巨字、主体元素、投影
        const cFace = easeInOutCubic(prog(localT, 25.15, 25.95));   // 字面金属/釉面/玄石材质与英文
        const cAccent = easeOutQuint(prog(localT, 25.85, 26.65));   // 高潮点缀色与星芒高光

        for (const L of node.layerImgs) {
          const n = L.meta.name;
          L.el.style.opacity = String(pMonoIn.toFixed(3));
          let colorProg = 0;
          if (/底板|背景巨字|主体元素|细线|投影/.test(n)) {
            colorProg = cTheme;
          } else if (/高潮|星芒/.test(n)) {
            colorProg = cAccent;
            // 黑白阶段高潮核呈高亮度无色态，点缀扩散时随色相点亮
            L.el.style.opacity = String((pMonoIn * lerp(0.75, 1.0, cAccent)).toFixed(3));
          } else {
            colorProg = cFace;
          }
          const gray = (1 - colorProg).toFixed(3);
          const cont = lerp(1.16, 1.0, colorProg).toFixed(3);
          L.el.style.filter = colorProg < 0.999 ? `grayscale(${gray}) contrast(${cont})` : 'none';
        }

        // 材质扫光（25.25–26.45s）+ 点缀色从母题高潮处径向扩散波（25.85–26.95s）
        this.gFx.setAttribute('opacity', '1');
        const pSweep = prog(localT, 25.25, 26.45);
        const sweepX = lerp(-420, 1480, easeInOutCubic(pSweep));
        this.rectSweep.setAttribute('x', sweepX.toFixed(1));
        this.rectSweep.setAttribute('opacity', String(pSweep > 0 && pSweep < 1 ? Math.sin(pSweep * Math.PI) * 0.92 : 0));

        const pRip = prog(localT, 25.85, 26.95);
        const ripE = easeOutCubic(pRip);
        const ripR = ripE * 540;
        const ripA = pRip > 0 && pRip < 1 ? Math.sin(pRip * Math.PI) : 0;
        this.circleRipple.setAttribute('r', ripR.toFixed(1));
        this.circleRipple.setAttribute('opacity', String((ripA * 0.45).toFixed(3)));
        this.circleRippleRing.setAttribute('r', (ripR * 0.92).toFixed(1));
        this.circleRippleRing.setAttribute('opacity', String((ripA * 0.85).toFixed(3)));

        const phaseDesc = localT < 24.55
          ? '先停留在黑白明暗稿，验证体量、字怀与层级关系'
          : localT < 25.85
            ? '按颜色角色逐层上色：主题色底板 → 字面材质 → 扫光掠过'
            : '点缀色从母题高潮处向外扩散点亮，唤醒高光与星芒';
        this._setSubtitle(`${data.name}  ·  MONO TO COLOR`, '06 · 黑白到上色', phaseDesc);
      }

      // ================================================================
      // 段落 7 (27.0 – 30.0s)：分层展开、标注各层、合回并定格于专属主题背景
      // ================================================================
      else {
        const pOpen = easeInOutCubic(prog(localT, 27.0, 27.75));
        const pClose = easeInOutCubic(prog(localT, 28.65, 29.35));
        const explode = pOpen * (1 - pClose); // 0 → 1 (保持展开标注) → 0 (合回定格)

        bgIntensity = lerp(0.65, 1.0, easeInOutCubic(prog(localT, 27.0, 29.3)));

        // 3D 纵深视角倾斜展开，同时微微左移并逐层轻微错位以清晰展现每层独立图元
        rotY = -32 * explode;
        rotX = 14 * explode;
        camScale = lerp(1.0, 0.80, explode);
        camTx = -8.5 * explode;

        const nLayers = node.layerImgs.length;
        const midIdx = (nLayers - 1) * 0.5;
        node.layerImgs.forEach((L, idx) => {
          L.el.style.opacity = '1';
          const zPx = (idx - midIdx) * 46 * explode;
          const xPx = (idx - midIdx) * 9 * explode;
          const isSpark = /星芒|高潮/.test(L.meta.name);
          if (explode < 0.05 && isSpark) {
            const breathe = 0.86 + 0.14 * Math.sin((localT - 29.0) * 3.8);
            L.el.style.opacity = String(breathe.toFixed(3));
          }
          L.el.style.transform = explode > 0.002 ? `translate3d(${xPx.toFixed(1)}px, 0, ${zPx.toFixed(1)}px)` : 'none';
          if (explode > 0.05) {
            L.el.style.filter = 'drop-shadow(0 10px 22px rgba(0,0,0,0.52))';
          }
        });

        // 展开期间右侧有序亮出分层名称清单
        const calloutAlpha = clamp((explode - 0.35) / 0.5);
        this.calloutsEl.style.opacity = String(calloutAlpha);

        this._setSubtitle(
          `${data.name}  ·  ${explode > 0.2 ? 'EXPLODED LAYERS' : 'FINAL PRESENTATION'}`,
          explode > 0.2 ? '07 · 分层展开' : '07 · 主题定格',
          explode > 0.2 ? '十余层独立透明图元沿纵深展开，合回严丝合缝' : `${data.name}（${data.en}）— 定格于专属代码主题背景`,
          localT > 29.5 && logoIdx < this.logos.length - 1 ? chapterFade : 1
        );
      }

      // 应用镜头与 3D 场景变换 + 章节柔淡
      this.cameraEl.style.opacity = String(chapterFade.toFixed(4));
      this.cameraEl.style.transform = `scale(${camScale.toFixed(4)}) translate(${camTx.toFixed(3)}%, ${camTy.toFixed(3)}%)`;
      this.scene3dEl.style.transform = `rotateY(${rotY.toFixed(2)}deg) rotateX(${rotX.toFixed(2)}deg)`;

      // 同步绘制底层专属代码背景（确定性传入 globalT）
      this.bg.render(data.id, globalT, bgIntensity);
    }

    /* ---------------- 专属构造入场编排（第 1 步） ---------------- */
    _renderCraftedEntrance(data, node, t) {
      const L = node.layerImgs;
      const setLayer = (idx, t0, t1, fn) => {
        if (!L[idx]) return;
        const u = easeOutCubic(prog(t, t0, t1));
        if (u <= 0) {
          L[idx].el.style.opacity = '0';
          return;
        }
        L[idx].el.style.opacity = String(u.toFixed(3));
        if (fn) fn(L[idx].el, u);
      };

      if (data.id === 'endfield') {
        // 0:底板(斜向装甲展开) 1:背景巨字 2:协议塔架(拔地竖起) 3:细线导轨 4:投影描边(随字锁合浮现) 5:系列名 6:主名 7:协议核(点亮) 8:英文 9:高光
        setLayer(0, 0.0, 0.9, (el, u) => { el.style.clipPath = `inset(0 ${((1 - u) * 100).toFixed(1)}% 0 0)`; });
        setLayer(1, 0.4, 1.2, (el, u) => { el.style.transform = `translate3d(${((1 - u) * -24).toFixed(1)}px, 0, 0)`; });
        setLayer(2, 0.7, 1.8, (el, u) => { el.style.transform = `translate3d(0, ${((1 - u) * 54).toFixed(1)}px, 0)`; });
        setLayer(3, 1.1, 2.0, (el, u) => { el.style.clipPath = `inset(0 ${((1 - u) * 100).toFixed(1)}% 0 0)`; });
        setLayer(5, 1.35, 2.25, (el, u) => { el.style.transform = `translate3d(0, ${((1 - u) * -22).toFixed(1)}px, 0)`; });
        setLayer(6, 1.50, 2.45, (el, u) => { el.style.transform = `translate3d(${((1 - u) * 26).toFixed(1)}px, 0, 0) scale(${lerp(1.04, 1, u).toFixed(4)})`; });
        // 投影与描边在全部汉字落位后贴合显现，避免滑行途中露出空描边框
        setLayer(4, 2.28, 2.85);
        setLayer(7, 2.50, 3.25, (el, u) => { el.style.transform = `scale(${lerp(0.65, 1, u).toFixed(4)})`; });
        setLayer(8, 2.65, 3.45, (el, u) => { el.style.transform = `translate3d(0, ${((1 - u) * 18).toFixed(1)}px, 0)`; });
        setLayer(9, 2.95, 3.85, (el, u) => { el.style.opacity = String((u * (0.88 + 0.12 * Math.sin(t * 5))).toFixed(3)); });
      } else if (data.id === 'starrail') {
        // 0:星云底板 1:背景巨字 2:黄铜星环与列车(破空飞入) 3:细线星尘 4:投影镀边(落字后浮现) 5:崩坏 6:穹铁道 7:签名字星 8:四芒星核 9:英文 10:星芒
        setLayer(0, 0.0, 1.0, (el, u) => { el.style.transform = `scale(${lerp(0.92, 1, u).toFixed(4)})`; });
        setLayer(1, 0.4, 1.2);
        setLayer(2, 0.6, 1.85, (el, u) => { el.style.transform = `translate3d(${((1 - u) * -65).toFixed(1)}px, ${((1 - u) * 22).toFixed(1)}px, 0) rotate(${((1 - u) * -6).toFixed(2)}deg)`; });
        setLayer(3, 1.05, 1.95, (el, u) => { el.style.clipPath = `inset(0 ${((1 - u) * 100).toFixed(1)}% 0 0)`; });
        setLayer(5, 1.35, 2.20, (el, u) => { el.style.transform = `translate3d(0, ${((1 - u) * -20).toFixed(1)}px, 0)`; });
        setLayer(6, 1.48, 2.38, (el, u) => { el.style.transform = `translate3d(${((1 - u) * 30).toFixed(1)}px, ${((1 - u) * 8).toFixed(1)}px, 0)`; });
        setLayer(7, 1.62, 2.52, (el, u) => { el.style.transform = `translate3d(0, ${((1 - u) * -24).toFixed(1)}px, 0) scale(${lerp(1.05, 1, u).toFixed(4)})`; });
        // 投影与流金镀边在全组汉字稳落星轨后贴合点亮，绝不提前露出空框
        setLayer(4, 2.38, 2.95);
        setLayer(8, 2.60, 3.35, (el, u) => { el.style.transform = `scale(${lerp(0.4, 1, u).toFixed(4)})`; });
        setLayer(9, 2.70, 3.55, (el, u) => { el.style.clipPath = `inset(0 ${((1 - u) * 100).toFixed(1)}% 0 0)`; });
        setLayer(10, 3.00, 3.90, (el, u) => { el.style.opacity = String((u * (0.88 + 0.12 * Math.sin(t * 5))).toFixed(3)); });
      } else {
        // 鸣潮: 0:玄墨底板 1:背景巨字 2:声痕与声波雨丝 3:细线示波 4:投影光丝(双字落位后显现) 5:鸣字 6:潮字(逆涌抬升) 7:鸣口声痕核 8:英文 9:星芒
        setLayer(0, 0.0, 1.0, (el, u) => { el.style.transform = `scale(${lerp(1.08, 1, u).toFixed(4)})`; });
        setLayer(1, 0.4, 1.2);
        setLayer(2, 0.6, 1.85, (el, u) => { el.style.transform = `translate3d(0, ${((1 - u) * -38).toFixed(1)}px, 0)`; });
        setLayer(3, 1.05, 1.95, (el, u) => { el.style.clipPath = `inset(0 ${((1 - u) * 50).toFixed(1)}% 0 ${((1 - u) * 50).toFixed(1)}%)`; });
        setLayer(5, 1.40, 2.28, (el, u) => { el.style.transform = `translate3d(${((1 - u) * -28).toFixed(1)}px, ${((1 - u) * 16).toFixed(1)}px, 0)`; });
        setLayer(6, 1.62, 2.52, (el, u) => { el.style.transform = `translate3d(${((1 - u) * 28).toFixed(1)}px, ${((1 - u) * 32).toFixed(1)}px, 0)`; });
        // 投影与青碧外光丝在「鸣」「潮」双字落位合拍后贴合浮现
        setLayer(4, 2.38, 2.95);
        setLayer(7, 2.55, 3.30, (el, u) => { el.style.transform = `scale(${lerp(0.45, 1, u).toFixed(4)})`; });
        setLayer(8, 2.68, 3.55, (el, u) => { el.style.transform = `translate3d(0, ${((1 - u) * 16).toFixed(1)}px, 0)`; });
        setLayer(9, 2.98, 3.88, (el, u) => { el.style.opacity = String((u * (0.88 + 0.12 * Math.sin(t * 5))).toFixed(3)); });
      }
    }

    /* ---------------- 真实 SVG 布尔差集形变与物理方向差异高亮 ---------------- */
    _renderMorphDiff(prevD, nextD, u, prevCol, nextCol, addCol, remCol, opts = {}) {
      this.pGlyphPrev.setAttribute('d', prevD);
      this.pGlyphNext.setAttribute('d', nextD);
      this.pGlyphPrev.setAttribute('fill', prevCol);
      this.pGlyphNext.setAttribute('fill', nextCol);

      // 主轮廓从旧形平滑过渡至新形
      this.pGlyphPrev.setAttribute('opacity', String(clamp(1 - u * 1.15).toFixed(3)));
      this.pGlyphNext.setAttribute('opacity', String(clamp(u * 1.25).toFixed(3)));

      // 被切削掉的旧笔画碎屑 (Prev \ Next)：随 u 闪红并伴随微小向右上/外侧剥离滑移消散
      this.maskRemovedSub.setAttribute('d', nextD);
      this.pGlyphRemoved.setAttribute('d', prevD);
      this.pGlyphRemoved.setAttribute('fill', remCol);
      const remAlpha = u < 0.72 ? Math.sin((u / 0.72) * Math.PI) * 0.82 : 0;
      const driftPx = easeOutCubic(clamp(u / 0.72)) * (opts.drift || 5.5);
      this.pGlyphRemoved.setAttribute('opacity', String(remAlpha.toFixed(3)));
      this.pGlyphRemoved.setAttribute('transform', `translate(${(driftPx * 0.65).toFixed(2)} ${(-driftPx).toFixed(2)})`);

      // 新生长出的笔画变体 (Next \ Prev)：高亮主题色流光涌现 + 微弹扩张融入字身
      this.maskAddedSub.setAttribute('d', prevD);
      this.pGlyphAdded.setAttribute('d', nextD);
      this.pGlyphAdded.setAttribute('fill', addCol);
      const addAlpha = u > 0.06 && u < 0.96 ? Math.sin(((u - 0.06) / 0.90) * Math.PI) * 0.98 : 0;
      this.pGlyphAdded.setAttribute('opacity', String(addAlpha.toFixed(3)));
      this.pGlyphAdded.removeAttribute('transform');
    }

    _setSolidGlyph(d, col) {
      this.pGlyphPrev.setAttribute('opacity', '0');
      this.pGlyphNext.setAttribute('d', d);
      this.pGlyphNext.setAttribute('fill', col);
      this.pGlyphNext.setAttribute('opacity', '1');
      this.pGlyphRemoved.setAttribute('opacity', '0');
      this.pGlyphAdded.setAttribute('opacity', '0');
    }

    _renderClimaxReticle(cx, cy, accent, alpha, t) {
      this.gCallouts.innerHTML = '';
      if (alpha <= 0.01) return;
      const g = svgEl('g', { opacity: alpha.toFixed(3) });
      const r1 = 82 + Math.sin(t * 4) * 3;
      g.appendChild(svgEl('circle', { cx, cy, r: r1.toFixed(1), fill: 'none', stroke: accent, 'stroke-width': '1.2', 'stroke-dasharray': '8 6', opacity: '0.78' }));
      g.appendChild(svgEl('circle', { cx, cy, r: '104', fill: 'none', stroke: 'rgba(255,255,255,0.28)', 'stroke-width': '0.8' }));
      // 十字微瞄准刻度
      [[-122, 0, -94, 0], [94, 0, 122, 0], [0, -122, 0, -94], [0, 94, 0, 122]].forEach(([x1, y1, x2, y2]) => {
        g.appendChild(svgEl('line', { x1: cx + x1, y1: cy + y1, x2: cx + x2, y2: cy + y2, stroke: accent, 'stroke-width': '1.2' }));
      });
      this.gCallouts.appendChild(g);
    }

    _renderEchoCallouts(data, pEcho) {
      this.gCallouts.innerHTML = '';
      const pts = data.guides.echoPoints || [];
      const acc = data.accent;
      pts.forEach((pt, i) => {
        const u = easeOutCubic(clamp((pEcho - i * 0.13) / 0.35));
        if (u <= 0.01) return;
        const g = svgEl('g', { opacity: u.toFixed(3) });
        const pulseR = 14 + (1 - u) * 18;
        g.appendChild(svgEl('circle', { cx: pt.x, cy: pt.y, r: pulseR.toFixed(1), fill: 'none', stroke: acc, 'stroke-width': '1.6' }));
        g.appendChild(svgEl('circle', { cx: pt.x, cy: pt.y, r: '4.2', fill: acc }));
        const dirY = typeof pt.dy === 'number' ? pt.dy : (pt.y < 280 ? -42 : 42);
        const dirX = typeof pt.dx === 'number' ? pt.dx : (pt.x < 600 ? -28 : 28);
        const mx = pt.x + dirX;
        const my = pt.y + dirY;
        const ex = mx + (dirX < 0 ? -95 : 95);
        g.appendChild(svgEl('polyline', {
          points: `${pt.x},${pt.y} ${mx},${my} ${ex},${my}`,
          fill: 'none', stroke: acc, 'stroke-width': '1.2', opacity: '0.85'
        }));
        const tx = svgEl('text', {
          x: dirX < 0 ? ex : mx + 6,
          y: my - 6,
          fill: '#f4f8fd',
          stroke: '#070a10',
          'stroke-width': '4.5',
          'paint-order': 'stroke',
          'stroke-linejoin': 'round',
          'font-size': '13',
          'font-family': 'var(--font-zh)',
          'letter-spacing': '0.06em'
        });
        tx.textContent = pt.label;
        g.appendChild(tx);
        this.gCallouts.appendChild(g);
      });
    }

    _renderAlignCallouts(data, pAlign) {
      this.gCallouts.innerHTML = '';
      if (pAlign <= 0.01) return;
      const lines = data.guides.alignLines || [];
      const acc = data.accent;
      lines.forEach((ln, i) => {
        const u = easeOutCubic(clamp((pAlign - i * 0.16) / 0.55));
        if (u <= 0.01) return;
        const x2 = lerp(ln.x1, ln.x2, u);
        const y2 = lerp(ln.y1, ln.y2, u);
        const g = svgEl('g', { opacity: u.toFixed(3) });
        g.appendChild(svgEl('line', {
          x1: ln.x1, y1: ln.y1, x2: x2.toFixed(1), y2: y2.toFixed(1),
          stroke: acc, 'stroke-width': '1.6', 'stroke-dasharray': '5 4'
        }));
        g.appendChild(svgEl('circle', { cx: ln.x1, cy: ln.y1, r: '3.6', fill: acc }));
        g.appendChild(svgEl('circle', { cx: x2.toFixed(1), cy: y2.toFixed(1), r: '3.6', fill: acc }));
        const lx = (ln.x1 + ln.x2) * 0.5;
        // 避免水平线贴在顶部文字上：靠上的线把标签放在线下，其余放线上
        const isVertical = Math.abs(ln.x1 - ln.x2) < 12;
        const ly = isVertical ? Math.min(ln.y1, ln.y2) - 10 : (ln.y1 < 180 ? ln.y1 + 20 : Math.min(ln.y1, ln.y2) - 9);
        const tx = svgEl('text', {
          x: lx.toFixed(1), y: ly.toFixed(1), 'text-anchor': 'middle',
          fill: acc,
          stroke: '#070a10',
          'stroke-width': '4.5',
          'paint-order': 'stroke',
          'stroke-linejoin': 'round',
          'font-size': '13.5',
          'font-family': 'var(--font-zh)',
          'letter-spacing': '0.08em'
        });
        tx.textContent = ln.label;
        g.appendChild(tx);
        this.gCallouts.appendChild(g);
      });
    }
  }

  window.ShowEngine = ShowEngine;
})();
